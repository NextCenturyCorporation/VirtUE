(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error('Cannot find module "' + req + '".');
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _shared_models_breadcrumb_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./shared/models/breadcrumb.model */ "./src/app/shared/models/breadcrumb.model.ts");
/* harmony import */ var _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./dashboard/dashboard.component */ "./src/app/dashboard/dashboard.component.ts");
/* harmony import */ var _config_config_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./config/config.component */ "./src/app/config/config.component.ts");
/* harmony import */ var _users_users_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./users/users.component */ "./src/app/users/users.component.ts");
/* harmony import */ var _users_user_list_user_list_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./users/user-list/user-list.component */ "./src/app/users/user-list/user-list.component.ts");
/* harmony import */ var _users_add_user_add_user_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./users/add-user/add-user.component */ "./src/app/users/add-user/add-user.component.ts");
/* harmony import */ var _users_duplicate_user_duplicate_user_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./users/duplicate-user/duplicate-user.component */ "./src/app/users/duplicate-user/duplicate-user.component.ts");
/* harmony import */ var _users_edit_user_edit_user_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./users/edit-user/edit-user.component */ "./src/app/users/edit-user/edit-user.component.ts");
/* harmony import */ var _virtues_virtues_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./virtues/virtues.component */ "./src/app/virtues/virtues.component.ts");
/* harmony import */ var _virtues_virtue_list_virtue_list_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./virtues/virtue-list/virtue-list.component */ "./src/app/virtues/virtue-list/virtue-list.component.ts");
/* harmony import */ var _virtues_create_virtue_create_virtue_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./virtues/create-virtue/create-virtue.component */ "./src/app/virtues/create-virtue/create-virtue.component.ts");
/* harmony import */ var _virtues_edit_virtue_edit_virtue_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./virtues/edit-virtue/edit-virtue.component */ "./src/app/virtues/edit-virtue/edit-virtue.component.ts");
/* harmony import */ var _virtues_duplicate_virtue_duplicate_virtue_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./virtues/duplicate-virtue/duplicate-virtue.component */ "./src/app/virtues/duplicate-virtue/duplicate-virtue.component.ts");
/* harmony import */ var _virtues_virtue_settings_virtue_settings_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./virtues/virtue-settings/virtue-settings.component */ "./src/app/virtues/virtue-settings/virtue-settings.component.ts");
/* harmony import */ var _virtual_machines_virtual_machines_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./virtual-machines/virtual-machines.component */ "./src/app/virtual-machines/virtual-machines.component.ts");
/* harmony import */ var _virtual_machines_vm_list_vm_list_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./virtual-machines/vm-list/vm-list.component */ "./src/app/virtual-machines/vm-list/vm-list.component.ts");
/* harmony import */ var _virtual_machines_vm_build_vm_build_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./virtual-machines/vm-build/vm-build.component */ "./src/app/virtual-machines/vm-build/vm-build.component.ts");
/* harmony import */ var _virtual_machines_vm_edit_vm_edit_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./virtual-machines/vm-edit/vm-edit.component */ "./src/app/virtual-machines/vm-edit/vm-edit.component.ts");
/* harmony import */ var _virtual_machines_vm_duplicate_vm_duplicate_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./virtual-machines/vm-duplicate/vm-duplicate.component */ "./src/app/virtual-machines/vm-duplicate/vm-duplicate.component.ts");
/* harmony import */ var _page_not_found_page_not_found_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./page-not-found/page-not-found.component */ "./src/app/page-not-found/page-not-found.component.ts");
/* harmony import */ var _vm_apps_vm_apps_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./vm-apps/vm-apps.component */ "./src/app/vm-apps/vm-apps.component.ts");
/* harmony import */ var _vm_apps_vm_apps_list_vm_apps_list_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./vm-apps/vm-apps-list/vm-apps-list.component */ "./src/app/vm-apps/vm-apps-list/vm-apps-list.component.ts");
/* harmony import */ var _vm_apps_add_vm_app_add_vm_app_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./vm-apps/add-vm-app/add-vm-app.component */ "./src/app/vm-apps/add-vm-app/add-vm-app.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

























var routes = [
    {
        path: 'dashboard',
        component: _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_3__["DashboardComponent"],
        data: {
            breadcrumbs: [
                new _shared_models_breadcrumb_model__WEBPACK_IMPORTED_MODULE_2__["Breadcrumb"]('Dashboard', '/dashboard')
            ]
        }
    }, {
        path: 'settings',
        component: _config_config_component__WEBPACK_IMPORTED_MODULE_4__["ConfigComponent"],
        data: {
            breadcrumbs: [
                new _shared_models_breadcrumb_model__WEBPACK_IMPORTED_MODULE_2__["Breadcrumb"]('Settings', '/settings')
            ]
        }
    }, {
        path: 'users',
        component: _users_users_component__WEBPACK_IMPORTED_MODULE_5__["UsersComponent"],
        data: {
            breadcrumbs: [
                new _shared_models_breadcrumb_model__WEBPACK_IMPORTED_MODULE_2__["Breadcrumb"]('Users', '/user')
            ]
        },
        children: [
            {
                path: '',
                component: _users_user_list_user_list_component__WEBPACK_IMPORTED_MODULE_6__["UserListComponent"]
            }, {
                path: 'add',
                component: _users_add_user_add_user_component__WEBPACK_IMPORTED_MODULE_7__["AddUserComponent"],
                data: {
                    breadcrumbs: [
                        new _shared_models_breadcrumb_model__WEBPACK_IMPORTED_MODULE_2__["Breadcrumb"]('Add User Account', '/add-user')
                    ]
                }
            }, {
                path: 'edit/:id',
                component: _users_edit_user_edit_user_component__WEBPACK_IMPORTED_MODULE_9__["EditUserComponent"],
                data: {
                    breadcrumbs: [
                        new _shared_models_breadcrumb_model__WEBPACK_IMPORTED_MODULE_2__["Breadcrumb"]('Edit User Account', '/edit-user')
                    ]
                }
            }, {
                path: 'duplicate/:id',
                component: _users_duplicate_user_duplicate_user_component__WEBPACK_IMPORTED_MODULE_8__["DuplicateUserComponent"],
                data: {
                    breadcrumbs: [
                        new _shared_models_breadcrumb_model__WEBPACK_IMPORTED_MODULE_2__["Breadcrumb"]('Duplicate User Account', '/duplicate-user')
                    ]
                }
            }
        ]
    }, {
        path: 'applications',
        component: _vm_apps_vm_apps_component__WEBPACK_IMPORTED_MODULE_22__["VmAppsComponent"],
        data: {
            breadcrumbs: [
                new _shared_models_breadcrumb_model__WEBPACK_IMPORTED_MODULE_2__["Breadcrumb"]('Applications', '/applications')
            ]
        },
        children: [
            {
                path: '',
                component: _vm_apps_vm_apps_list_vm_apps_list_component__WEBPACK_IMPORTED_MODULE_23__["VmAppsListComponent"]
            }, {
                path: 'add-app',
                component: _vm_apps_add_vm_app_add_vm_app_component__WEBPACK_IMPORTED_MODULE_24__["AddVmAppComponent"],
                data: {
                    breadcrumbs: [
                        new _shared_models_breadcrumb_model__WEBPACK_IMPORTED_MODULE_2__["Breadcrumb"]('Install New App', '/add-application')
                    ]
                }
            }
        ]
    }, {
        path: 'virtues',
        component: _virtues_virtues_component__WEBPACK_IMPORTED_MODULE_10__["VirtuesComponent"],
        data: {
            breadcrumbs: [
                new _shared_models_breadcrumb_model__WEBPACK_IMPORTED_MODULE_2__["Breadcrumb"]('Virtues', '/virtues')
            ]
        },
        children: [
            {
                path: '',
                component: _virtues_virtue_list_virtue_list_component__WEBPACK_IMPORTED_MODULE_11__["VirtueListComponent"]
            }, {
                path: 'create-virtue',
                component: _virtues_create_virtue_create_virtue_component__WEBPACK_IMPORTED_MODULE_12__["CreateVirtueComponent"],
                data: {
                    breadcrumbs: [
                        new _shared_models_breadcrumb_model__WEBPACK_IMPORTED_MODULE_2__["Breadcrumb"]('Create Virtue', '/create-virtue')
                    ]
                }
            }, {
                path: 'edit/:id',
                component: _virtues_edit_virtue_edit_virtue_component__WEBPACK_IMPORTED_MODULE_13__["EditVirtueComponent"],
                data: {
                    breadcrumbs: [
                        new _shared_models_breadcrumb_model__WEBPACK_IMPORTED_MODULE_2__["Breadcrumb"]('Edit Virtue', '/edit')
                    ]
                }
            }, {
                path: 'duplicate/:id',
                component: _virtues_duplicate_virtue_duplicate_virtue_component__WEBPACK_IMPORTED_MODULE_14__["DuplicateVirtueComponent"],
                data: {
                    breadcrumbs: [
                        new _shared_models_breadcrumb_model__WEBPACK_IMPORTED_MODULE_2__["Breadcrumb"]('Duplicate Virtue', '/duplicate')
                    ]
                }
            }, {
                path: 'virtue-settings',
                component: _virtues_virtue_settings_virtue_settings_component__WEBPACK_IMPORTED_MODULE_15__["VirtueSettingsComponent"]
            }
        ]
    }, {
        path: 'virtual-machines',
        component: _virtual_machines_virtual_machines_component__WEBPACK_IMPORTED_MODULE_16__["VirtualMachinesComponent"],
        data: {
            breadcrumbs: [
                new _shared_models_breadcrumb_model__WEBPACK_IMPORTED_MODULE_2__["Breadcrumb"]('Virtual Machines', '/virtual-machines')
            ]
        },
        children: [
            {
                path: '',
                component: _virtual_machines_vm_list_vm_list_component__WEBPACK_IMPORTED_MODULE_17__["VmListComponent"]
            }, {
                path: 'vm-build',
                component: _virtual_machines_vm_build_vm_build_component__WEBPACK_IMPORTED_MODULE_18__["VmBuildComponent"],
                data: {
                    breadcrumbs: [
                        new _shared_models_breadcrumb_model__WEBPACK_IMPORTED_MODULE_2__["Breadcrumb"]('Build Virtual Machine', '/vm-build')
                    ]
                }
            }, {
                path: 'edit/:id',
                component: _virtual_machines_vm_edit_vm_edit_component__WEBPACK_IMPORTED_MODULE_19__["VmEditComponent"],
                data: {
                    breadcrumbs: [
                        new _shared_models_breadcrumb_model__WEBPACK_IMPORTED_MODULE_2__["Breadcrumb"]('Edit Virtual Machine', '/edit')
                    ]
                }
            }, {
                path: 'duplicate/:id',
                component: _virtual_machines_vm_duplicate_vm_duplicate_component__WEBPACK_IMPORTED_MODULE_20__["VmDuplicateComponent"],
                data: {
                    breadcrumbs: [
                        new _shared_models_breadcrumb_model__WEBPACK_IMPORTED_MODULE_2__["Breadcrumb"]('Duplicate Virtual Machine', '/duplicate')
                    ]
                }
            },
        ]
    },
    { path: '**', component: _page_not_found_page_not_found_component__WEBPACK_IMPORTED_MODULE_21__["PageNotFoundComponent"] }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)],
            // imports: [RouterModule.forRoot(routes, {
            //   useHash: true
            // })],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]],
            declarations: []
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!--The whole content below can be removed with the new code.-->\n<app-header></app-header>\n<app-breadcrumbs></app-breadcrumbs>\n<content>\n  <router-outlet></router-outlet>\n</content>\n<app-footer></app-footer>\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var AppComponent = /** @class */ (function () {
    function AppComponent() {
        this.title = 'Savior Adminstrator Workbench';
    }
    AppComponent.prototype.ngOnInit = function () { };
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html")
        }),
        __metadata("design:paramtypes", [])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/cdk/overlay */ "./node_modules/@angular/cdk/esm5/overlay.es5.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var ng2_split_pane_lib_ng2_split_pane__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ng2-split-pane/lib/ng2-split-pane */ "./node_modules/ng2-split-pane/lib/ng2-split-pane.js");
/* harmony import */ var ng2_split_pane_lib_ng2_split_pane__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(ng2_split_pane_lib_ng2_split_pane__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _header_header_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./header/header.component */ "./src/app/header/header.component.ts");
/* harmony import */ var _footer_footer_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./footer/footer.component */ "./src/app/footer/footer.component.ts");
/* harmony import */ var _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./dashboard/dashboard.component */ "./src/app/dashboard/dashboard.component.ts");
/* harmony import */ var _config_config_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./config/config.component */ "./src/app/config/config.component.ts");
/* harmony import */ var _config_config_active_dir_config_active_dir_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./config/config-active-dir/config-active-dir.component */ "./src/app/config/config-active-dir/config-active-dir.component.ts");
/* harmony import */ var _config_config_app_vm_config_app_vm_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./config/config-app-vm/config-app-vm.component */ "./src/app/config/config-app-vm/config-app-vm.component.ts");
/* harmony import */ var _config_config_resources_config_resources_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./config/config-resources/config-resources.component */ "./src/app/config/config-resources/config-resources.component.ts");
/* harmony import */ var _config_resource_modal_resource_modal_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./config/resource-modal/resource-modal.component */ "./src/app/config/resource-modal/resource-modal.component.ts");
/* harmony import */ var _config_resource_modal_file_share_file_share_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./config/resource-modal/file-share/file-share.component */ "./src/app/config/resource-modal/file-share/file-share.component.ts");
/* harmony import */ var _config_resource_modal_printers_printers_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./config/resource-modal/printers/printers.component */ "./src/app/config/resource-modal/printers/printers.component.ts");
/* harmony import */ var _config_config_sensors_config_sensors_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./config/config-sensors/config-sensors.component */ "./src/app/config/config-sensors/config-sensors.component.ts");
/* harmony import */ var _users_users_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./users/users.component */ "./src/app/users/users.component.ts");
/* harmony import */ var _users_user_list_user_list_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./users/user-list/user-list.component */ "./src/app/users/user-list/user-list.component.ts");
/* harmony import */ var _users_add_user_add_user_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./users/add-user/add-user.component */ "./src/app/users/add-user/add-user.component.ts");
/* harmony import */ var _users_edit_user_edit_user_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./users/edit-user/edit-user.component */ "./src/app/users/edit-user/edit-user.component.ts");
/* harmony import */ var _users_virtue_modal_virtue_modal_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./users/virtue-modal/virtue-modal.component */ "./src/app/users/virtue-modal/virtue-modal.component.ts");
/* harmony import */ var _virtues_virtues_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./virtues/virtues.component */ "./src/app/virtues/virtues.component.ts");
/* harmony import */ var _virtues_virtue_list_virtue_list_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./virtues/virtue-list/virtue-list.component */ "./src/app/virtues/virtue-list/virtue-list.component.ts");
/* harmony import */ var _virtues_create_virtue_create_virtue_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./virtues/create-virtue/create-virtue.component */ "./src/app/virtues/create-virtue/create-virtue.component.ts");
/* harmony import */ var _virtues_edit_virtue_edit_virtue_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./virtues/edit-virtue/edit-virtue.component */ "./src/app/virtues/edit-virtue/edit-virtue.component.ts");
/* harmony import */ var _virtues_duplicate_virtue_duplicate_virtue_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./virtues/duplicate-virtue/duplicate-virtue.component */ "./src/app/virtues/duplicate-virtue/duplicate-virtue.component.ts");
/* harmony import */ var _virtues_virtue_settings_virtue_settings_component__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./virtues/virtue-settings/virtue-settings.component */ "./src/app/virtues/virtue-settings/virtue-settings.component.ts");
/* harmony import */ var _virtues_vm_modal_vm_modal_component__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./virtues/vm-modal/vm-modal.component */ "./src/app/virtues/vm-modal/vm-modal.component.ts");
/* harmony import */ var _virtual_machines_vm_apps_modal_vm_apps_modal_component__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./virtual-machines/vm-apps-modal/vm-apps-modal.component */ "./src/app/virtual-machines/vm-apps-modal/vm-apps-modal.component.ts");
/* harmony import */ var _virtual_machines_virtual_machines_component__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./virtual-machines/virtual-machines.component */ "./src/app/virtual-machines/virtual-machines.component.ts");
/* harmony import */ var _virtual_machines_vm_list_vm_list_component__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ./virtual-machines/vm-list/vm-list.component */ "./src/app/virtual-machines/vm-list/vm-list.component.ts");
/* harmony import */ var _virtual_machines_vm_build_vm_build_component__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./virtual-machines/vm-build/vm-build.component */ "./src/app/virtual-machines/vm-build/vm-build.component.ts");
/* harmony import */ var _virtual_machines_vm_edit_vm_edit_component__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ./virtual-machines/vm-edit/vm-edit.component */ "./src/app/virtual-machines/vm-edit/vm-edit.component.ts");
/* harmony import */ var _virtual_machines_vm_duplicate_vm_duplicate_component__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! ./virtual-machines/vm-duplicate/vm-duplicate.component */ "./src/app/virtual-machines/vm-duplicate/vm-duplicate.component.ts");
/* harmony import */ var _vm_apps_vm_apps_component__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! ./vm-apps/vm-apps.component */ "./src/app/vm-apps/vm-apps.component.ts");
/* harmony import */ var _vm_apps_vm_apps_list_vm_apps_list_component__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! ./vm-apps/vm-apps-list/vm-apps-list.component */ "./src/app/vm-apps/vm-apps-list/vm-apps-list.component.ts");
/* harmony import */ var _vm_apps_add_vm_app_add_vm_app_component__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! ./vm-apps/add-vm-app/add-vm-app.component */ "./src/app/vm-apps/add-vm-app/add-vm-app.component.ts");
/* harmony import */ var _page_not_found_page_not_found_component__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! ./page-not-found/page-not-found.component */ "./src/app/page-not-found/page-not-found.component.ts");
/* harmony import */ var _shared_directives_active_class_directive__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! ./shared/directives/active-class.directive */ "./src/app/shared/directives/active-class.directive.ts");
/* harmony import */ var _dialogs_dialogs_component__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! ./dialogs/dialogs.component */ "./src/app/dialogs/dialogs.component.ts");
/* harmony import */ var _breadcrumbs_breadcrumbs_component__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! ./breadcrumbs/breadcrumbs.component */ "./src/app/breadcrumbs/breadcrumbs.component.ts");
/* harmony import */ var _shared_pipes_list_filter_pipe__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! ./shared/pipes/list-filter.pipe */ "./src/app/shared/pipes/list-filter.pipe.ts");
/* harmony import */ var _shared_pipes_json_filter_pipe__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! ./shared/pipes/json-filter.pipe */ "./src/app/shared/pipes/json-filter.pipe.ts");
/* harmony import */ var _shared_pipes_count_filter_pipe__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(/*! ./shared/pipes/count-filter.pipe */ "./src/app/shared/pipes/count-filter.pipe.ts");
/* harmony import */ var _shared_providers_breadcrumb__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(/*! ./shared/providers/breadcrumb */ "./src/app/shared/providers/breadcrumb.ts");
/* harmony import */ var _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(/*! ./shared/services/baseUrl.service */ "./src/app/shared/services/baseUrl.service.ts");
/* harmony import */ var _shared_services_message_service__WEBPACK_IMPORTED_MODULE_51__ = __webpack_require__(/*! ./shared/services/message.service */ "./src/app/shared/services/message.service.ts");
/* harmony import */ var _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_52__ = __webpack_require__(/*! ./shared/services/virtues.service */ "./src/app/shared/services/virtues.service.ts");
/* harmony import */ var _users_duplicate_user_duplicate_user_component__WEBPACK_IMPORTED_MODULE_53__ = __webpack_require__(/*! ./users/duplicate-user/duplicate-user.component */ "./src/app/users/duplicate-user/duplicate-user.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};























































var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_9__["AppComponent"],
                _breadcrumbs_breadcrumbs_component__WEBPACK_IMPORTED_MODULE_45__["BreadcrumbsComponent"],
                _config_config_active_dir_config_active_dir_component__WEBPACK_IMPORTED_MODULE_14__["ConfigActiveDirComponent"],
                _config_config_app_vm_config_app_vm_component__WEBPACK_IMPORTED_MODULE_15__["ConfigAppVmComponent"],
                _config_config_component__WEBPACK_IMPORTED_MODULE_13__["ConfigComponent"],
                _config_config_resources_config_resources_component__WEBPACK_IMPORTED_MODULE_16__["ConfigResourcesComponent"],
                _footer_footer_component__WEBPACK_IMPORTED_MODULE_11__["FooterComponent"],
                _header_header_component__WEBPACK_IMPORTED_MODULE_10__["HeaderComponent"],
                _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_12__["DashboardComponent"],
                _virtues_virtues_component__WEBPACK_IMPORTED_MODULE_26__["VirtuesComponent"],
                _users_users_component__WEBPACK_IMPORTED_MODULE_21__["UsersComponent"],
                _users_user_list_user_list_component__WEBPACK_IMPORTED_MODULE_22__["UserListComponent"],
                _users_add_user_add_user_component__WEBPACK_IMPORTED_MODULE_23__["AddUserComponent"],
                _users_edit_user_edit_user_component__WEBPACK_IMPORTED_MODULE_24__["EditUserComponent"],
                _virtues_virtues_component__WEBPACK_IMPORTED_MODULE_26__["VirtuesComponent"],
                _virtues_virtue_list_virtue_list_component__WEBPACK_IMPORTED_MODULE_27__["VirtueListComponent"],
                _virtues_virtue_settings_virtue_settings_component__WEBPACK_IMPORTED_MODULE_31__["VirtueSettingsComponent"],
                _virtues_create_virtue_create_virtue_component__WEBPACK_IMPORTED_MODULE_28__["CreateVirtueComponent"],
                _virtues_edit_virtue_edit_virtue_component__WEBPACK_IMPORTED_MODULE_29__["EditVirtueComponent"],
                _virtues_duplicate_virtue_duplicate_virtue_component__WEBPACK_IMPORTED_MODULE_30__["DuplicateVirtueComponent"],
                _dialogs_dialogs_component__WEBPACK_IMPORTED_MODULE_44__["DialogsComponent"],
                _users_virtue_modal_virtue_modal_component__WEBPACK_IMPORTED_MODULE_25__["VirtueModalComponent"],
                _virtues_vm_modal_vm_modal_component__WEBPACK_IMPORTED_MODULE_32__["VmModalComponent"],
                _config_resource_modal_resource_modal_component__WEBPACK_IMPORTED_MODULE_17__["ResourceModalComponent"],
                _config_resource_modal_file_share_file_share_component__WEBPACK_IMPORTED_MODULE_18__["FileShareComponent"],
                _config_resource_modal_printers_printers_component__WEBPACK_IMPORTED_MODULE_19__["PrintersComponent"],
                _config_config_sensors_config_sensors_component__WEBPACK_IMPORTED_MODULE_20__["ConfigSensorsComponent"],
                _shared_pipes_list_filter_pipe__WEBPACK_IMPORTED_MODULE_46__["ListFilterPipe"],
                _shared_pipes_json_filter_pipe__WEBPACK_IMPORTED_MODULE_47__["JsonFilterPipe"],
                _shared_pipes_count_filter_pipe__WEBPACK_IMPORTED_MODULE_48__["CountFilterPipe"],
                _page_not_found_page_not_found_component__WEBPACK_IMPORTED_MODULE_42__["PageNotFoundComponent"],
                _virtual_machines_virtual_machines_component__WEBPACK_IMPORTED_MODULE_34__["VirtualMachinesComponent"],
                _virtual_machines_vm_list_vm_list_component__WEBPACK_IMPORTED_MODULE_35__["VmListComponent"],
                _virtual_machines_vm_build_vm_build_component__WEBPACK_IMPORTED_MODULE_36__["VmBuildComponent"],
                _virtual_machines_vm_edit_vm_edit_component__WEBPACK_IMPORTED_MODULE_37__["VmEditComponent"],
                _virtual_machines_vm_duplicate_vm_duplicate_component__WEBPACK_IMPORTED_MODULE_38__["VmDuplicateComponent"],
                _shared_directives_active_class_directive__WEBPACK_IMPORTED_MODULE_43__["ActiveClassDirective"],
                _dialogs_dialogs_component__WEBPACK_IMPORTED_MODULE_44__["DialogsComponent"],
                _vm_apps_vm_apps_component__WEBPACK_IMPORTED_MODULE_39__["VmAppsComponent"],
                _vm_apps_vm_apps_list_vm_apps_list_component__WEBPACK_IMPORTED_MODULE_40__["VmAppsListComponent"],
                _vm_apps_add_vm_app_add_vm_app_component__WEBPACK_IMPORTED_MODULE_41__["AddVmAppComponent"],
                _virtual_machines_vm_apps_modal_vm_apps_modal_component__WEBPACK_IMPORTED_MODULE_33__["VmAppsModalComponent"],
                _users_duplicate_user_duplicate_user_component__WEBPACK_IMPORTED_MODULE_53__["DuplicateUserComponent"],
            ],
            imports: [
                _app_routing_module__WEBPACK_IMPORTED_MODULE_1__["AppRoutingModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_5__["BrowserAnimationsModule"],
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["BrowserModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClientModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatAutocompleteModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatDialogModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatFormFieldModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatCheckboxModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatInputModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatRadioModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatSelectModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatToolbarModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ReactiveFormsModule"],
                ng2_split_pane_lib_ng2_split_pane__WEBPACK_IMPORTED_MODULE_8__["SplitPaneModule"]
            ],
            exports: [
                _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_6__["OverlayModule"]
            ],
            providers: [
                _shared_providers_breadcrumb__WEBPACK_IMPORTED_MODULE_49__["BreadcrumbProvider"],
                _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_6__["OverlayContainer"],
                _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_50__["BaseUrlService"],
                _shared_services_message_service__WEBPACK_IMPORTED_MODULE_51__["MessageService"],
                _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_52__["VirtuesService"]
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_9__["AppComponent"]],
            entryComponents: [
                _dialogs_dialogs_component__WEBPACK_IMPORTED_MODULE_44__["DialogsComponent"],
                _config_resource_modal_resource_modal_component__WEBPACK_IMPORTED_MODULE_17__["ResourceModalComponent"],
                _virtual_machines_vm_apps_modal_vm_apps_modal_component__WEBPACK_IMPORTED_MODULE_33__["VmAppsModalComponent"],
                _virtues_vm_modal_vm_modal_component__WEBPACK_IMPORTED_MODULE_32__["VmModalComponent"],
                _users_virtue_modal_virtue_modal_component__WEBPACK_IMPORTED_MODULE_25__["VirtueModalComponent"]
            ]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/breadcrumbs/breadcrumbs.component.html":
/*!********************************************************!*\
  !*** ./src/app/breadcrumbs/breadcrumbs.component.html ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ol>\n  <li *ngFor=\"let bc of breadcrumbs; let last = last\">\n    <span *ngIf=\"breadcrumbs.length === 1\">{{ bc.label }}</span>\n    <span *ngIf=\"breadcrumbs.length > 1\">\n     <a [routerLink]=\"bc.href\">{{ bc.label }}</a>\n   </span>\n    <!--<span *ngIf=\"!last\" class=\"separator\">/</span>-->\n  </li>\n</ol>\n"

/***/ }),

/***/ "./src/app/breadcrumbs/breadcrumbs.component.ts":
/*!******************************************************!*\
  !*** ./src/app/breadcrumbs/breadcrumbs.component.ts ***!
  \******************************************************/
/*! exports provided: BreadcrumbsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BreadcrumbsComponent", function() { return BreadcrumbsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _shared_providers_breadcrumb__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../shared/providers/breadcrumb */ "./src/app/shared/providers/breadcrumb.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var BreadcrumbsComponent = /** @class */ (function () {
    function BreadcrumbsComponent(router, breadcrumbProvider) {
        var _this = this;
        this.router = router;
        this.breadcrumbProvider = breadcrumbProvider;
        this.breadcrumbs = [];
        this.router.events.subscribe(function (e) {
            if (e instanceof _angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivationEnd"]) {
                if (e.snapshot.data.breadcrumbs) {
                    _this.breadcrumbs = Object.assign([], e.snapshot.data.breadcrumbs);
                }
                else {
                    if (_this.breadcrumbs.length <= 0 && e.snapshot.data.defaultBreadcrumbs) {
                        _this.breadcrumbs = Object.assign([], e.snapshot.data.defaultBreadcrumbs);
                    }
                }
            }
        });
        this.breadcrumbProvider._addItem.subscribe(function (breadcrumb) {
            _this.breadcrumbs.push(breadcrumb);
            console.log(_this.breadcrumbs);
        });
    }
    BreadcrumbsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-breadcrumbs',
            template: __webpack_require__(/*! ./breadcrumbs.component.html */ "./src/app/breadcrumbs/breadcrumbs.component.html")
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"], _shared_providers_breadcrumb__WEBPACK_IMPORTED_MODULE_2__["BreadcrumbProvider"]])
    ], BreadcrumbsComponent);
    return BreadcrumbsComponent;
}());



/***/ }),

/***/ "./src/app/config/config-active-dir/config-active-dir.component.css":
/*!**************************************************************************!*\
  !*** ./src/app/config/config-active-dir/config-active-dir.component.css ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/deep/\n.mat-form-field-infix {\n  padding: 0;\n  border-top: none;\n}\n/deep/\n.mat-form-field-underline {\n display: none;\n}\n"

/***/ }),

/***/ "./src/app/config/config-active-dir/config-active-dir.component.html":
/*!***************************************************************************!*\
  !*** ./src/app/config/config-active-dir/config-active-dir.component.html ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"titlebar\">\n  <h2>Active Directories</h2>\n</div>\n<form id=\"config-active-directories\" method=\"post\">\n  <h3>Connection Details</h3>\n  <div class=\"mui-row form-item\">\n    <div class=\"mui-col-md-3 text-align-right\"><label for=\"directoryName\">Directory Name:</label></div>\n    <div class=\"mui-col-md-4\">\n      <mat-form-field>\n        <input matInput name=\"directoryName\" type=\"text\" value=\"\" />\n      </mat-form-field>\n    </div>\n    <div class=\"mui-col-md-4\">&nbsp;</div>\n  </div>\n  <div class=\"mui-row form-item\">\n    <div class=\"mui-col-md-3 text-align-right\"><label for=\"directoryType\">Select Directory Type:</label></div>\n    <div class=\"mui-col-md-4\">\n      <mat-form-field style=\"min-width: 200px;\">\n        <mat-select name=\"directoryType\">\n          <mat-option value=\"Active Directory\">Active Directory</mat-option>\n        </mat-select>\n      </mat-form-field>\n    </div>\n    <div class=\"mui-col-md-4\">&nbsp;</div>\n  </div>\n  <div class=\"mui-row form-item\">\n    <div class=\"mui-col-md-3 text-align-right\"><label for=\"domain\">Domain:</label></div>\n    <div class=\"mui-col-md-4\">\n      <mat-form-field>\n        <input matInput name=\"domain\" type=\"text\" value=\"\" />\n      </mat-form-field>\n    </div>\n    <div class=\"mui-col-md-4\">&nbsp;</div>\n  </div>\n  <div class=\"mui-row form-item\">\n    <div class=\"mui-col-md-3 text-align-right\"><label for=\"hostIPAddress\">Host/IP Address:</label></div>\n    <div class=\"mui-col-md-4\">\n      <mat-form-field>\n        <input matInput name=\"hostIPAddress\" type=\"text\" value=\"\" />\n      </mat-form-field>\n    </div>\n    <div class=\"mui-col-md-2 text-align-right\"><label for=\"port\">Port:</label></div>\n    <div class=\"mui-col-md-2\">\n      <mat-form-field>\n        <input matInput name=\"port\" type=\"text\" value=\"\" />\n      </mat-form-field>\n    </div>\n  </div>\n  <hr />\n  <h3>Log-in Information</h3>\n  <div class=\"mui-row form-item\">\n    <div class=\"mui-col-md-3 text-align-right\"><label for=\"username\">Administrator Username:</label></div>\n    <div class=\"mui-col-md-4\">\n      <mat-form-field>\n        <input matInput name=\"username\" type=\"text\" value=\"\" />\n      </mat-form-field>\n    </div>\n    <div class=\"mui-col-md-4\">&nbsp;</div>\n  </div>\n  <div class=\"mui-row form-item\">\n    <div class=\"mui-col-md-3 text-align-right\"><label for=\"password\">Password:</label></div>\n    <div class=\"mui-col-md-4\">\n      <mat-form-field>\n        <input matInput name=\"password\" type=\"password\" value=\"\" />\n      </mat-form-field>\n    </div>\n    <div class=\"mui-col-md-4\">&nbsp;</div>\n  </div>\n  <hr />\n  <div class=\"mui-row\">\n    <div class=\"mui-col-md-4\">&nbsp;</div>\n    <div class=\"mui-col-md-4 form-item text-align-center\">\n      <button mat-button class=\"button-submit\" type=\"submit\">Save</button>\n    </div>\n    <div class=\"mui-col-md-4\"></div>\n  </div>\n  <div class=\"mui-row form-item\">\n    <div class=\"mui-col-md-12\">\n      <p>&nbsp;</p>\n    </div>\n  </div>\n</form>\n"

/***/ }),

/***/ "./src/app/config/config-active-dir/config-active-dir.component.ts":
/*!*************************************************************************!*\
  !*** ./src/app/config/config-active-dir/config-active-dir.component.ts ***!
  \*************************************************************************/
/*! exports provided: ConfigActiveDirComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConfigActiveDirComponent", function() { return ConfigActiveDirComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var ConfigActiveDirComponent = /** @class */ (function () {
    function ConfigActiveDirComponent() {
    }
    ConfigActiveDirComponent.prototype.ngOnInit = function () {
    };
    ConfigActiveDirComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-config-active-dir',
            template: __webpack_require__(/*! ./config-active-dir.component.html */ "./src/app/config/config-active-dir/config-active-dir.component.html"),
            styles: [__webpack_require__(/*! ./config-active-dir.component.css */ "./src/app/config/config-active-dir/config-active-dir.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], ConfigActiveDirComponent);
    return ConfigActiveDirComponent;
}());



/***/ }),

/***/ "./src/app/config/config-app-vm/config-app-vm.component.css":
/*!******************************************************************!*\
  !*** ./src/app/config/config-app-vm/config-app-vm.component.css ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/config/config-app-vm/config-app-vm.component.html":
/*!*******************************************************************!*\
  !*** ./src/app/config/config-app-vm/config-app-vm.component.html ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"titlebar\">\n  <h2 class=\"title\">Applications Manager</h2>\n  <button class=\"float-right\" value=\"import\" disabled>Add New Application </button>\n</div>\n<form id=\"config-app-vms\" method=\"post\">\n  <div id=\"vm-list\" class=\"table-container padding-left-15\">\n    <div class=\"mui-row table-header-row\">\n      <div class=\"mui-col-md-4 table-header\">\n        <span><input type=\"checkbox\" name=\"all\" /></span>\n        <span>Virtual Machine</span>\n      </div>\n      <div class=\"mui-col-md-2 table-header\">Image Size</div>\n      <div class=\"mui-col-md-6 table-header\">Applications</div>\n    </div>\n    <div class=\"mui-row border-bottom\">\n      <div class=\"mui-col-md-4 table-data\">\n        <span><input type=\"checkbox\" name=\"all\" /></span>\n        <span>[ Virtual Machine Name ]</span>\n      </div>\n      <div class=\"mui-col-md-2 table-data\">[ Image Size ] MB</div>\n      <div class=\"mui-col-md-6 table-data\">[ App 1 ], [ App 2 ], [ App 3 ], [ App N ]...</div>\n    </div>\n  </div>\n  <div class=\"mui-row\">\n    <div class=\"mui-col-md-12\"><button name=\"delete\" value=\"delete\" disabled>Delete Selected</button></div>\n  </div>\n  <div class=\"mui-row\">\n    <div class=\"mui-col-md-4\">&nbsp;</div>\n    <div class=\"mui-col-md-4 form-item text-align-center\">\n      <button class=\"button-submit\" type=\"submit\">Save</button>\n    </div>\n    <div class=\"mui-col-md-4\"></div>\n  </div>\n  <div class=\"mui-row form-item\">\n    <div class=\"mui-col-md-12\">\n      <p>&nbsp;</p>\n    </div>\n  </div>\n</form>\n"

/***/ }),

/***/ "./src/app/config/config-app-vm/config-app-vm.component.ts":
/*!*****************************************************************!*\
  !*** ./src/app/config/config-app-vm/config-app-vm.component.ts ***!
  \*****************************************************************/
/*! exports provided: ConfigAppVmComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConfigAppVmComponent", function() { return ConfigAppVmComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var ConfigAppVmComponent = /** @class */ (function () {
    function ConfigAppVmComponent() {
    }
    ConfigAppVmComponent.prototype.ngOnInit = function () {
    };
    ConfigAppVmComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-config-app-vm',
            template: __webpack_require__(/*! ./config-app-vm.component.html */ "./src/app/config/config-app-vm/config-app-vm.component.html"),
            styles: [__webpack_require__(/*! ./config-app-vm.component.css */ "./src/app/config/config-app-vm/config-app-vm.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], ConfigAppVmComponent);
    return ConfigAppVmComponent;
}());



/***/ }),

/***/ "./src/app/config/config-resources/config-resources.component.css":
/*!************************************************************************!*\
  !*** ./src/app/config/config-resources/config-resources.component.css ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".table-header span:first-child {\n  text-align: left;\n  margin-left: 10px;\n  margin-right: 0;\n}\n"

/***/ }),

/***/ "./src/app/config/config-resources/config-resources.component.html":
/*!*************************************************************************!*\
  !*** ./src/app/config/config-resources/config-resources.component.html ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"titlebar\">\n  <h2 class=\"title\">Resources</h2>\n  <div class=\"float-right\"><button (click)=\"activateModal()\">Add Resource</button></div>\n</div>\n<form id=\"config-permissions\" method=\"post\">\n  <h3>File System Permissions</h3>\n  <div id=\"file-system-list\" class=\"table-container padding-left-15\">\n    <div class=\"mui-row table-header-row\">\n      <div class=\"mui-col-md-7 table-header\"><span>Description</span></div>\n      <div class=\"mui-col-md-1 table-header\"><span>Read</span></div>\n      <div class=\"mui-col-md-1 table-header\"><span>Write</span></div>\n      <div class=\"mui-col-md-1 table-header\"><span>Execute</span></div>\n      <div class=\"mui-col-md-1 table-header\"><span>Enable</span></div>\n      <div class=\"mui-col-md-1 table-header\"><span>Options</span></div>\n    </div>\n    <div class=\"mui-row table-row\">\n      <div class=\"mui-col-md-7 table-data\"><span>[ description ]</span></div>\n      <div class=\"mui-col-md-1 table-data text-align-center\"><span><input type=\"checkbox\" name=\"input-id\" value=\"read\" /></span></div>\n      <div class=\"mui-col-md-1 table-data text-align-center\"><span><input type=\"checkbox\" name=\"input-id\" value=\"write\" /></span></div>\n      <div class=\"mui-col-md-1 table-data text-align-center\"><span><input type=\"checkbox\" name=\"input-id\" value=\"execute\" /></span></div>\n      <div class=\"mui-col-md-1 table-data text-align-center\"><span><input type=\"checkbox\" name=\"input-id\" value=\"enable\" /></span></div>\n      <div class=\"mui-col-md-1 table-data text-align-center\"><button (click)=\"openDialog(1,'delete','Resource')\" class=\"button-trash\"><span class=\"fa fa-trash\"></span></button></div>\n    </div>\n  </div>\n  <h3>Printers</h3>\n  <div id=\"printer-list\" class=\"table-container padding-left-15\">\n    <div class=\"mui-row table-header-row\">\n      <div class=\"mui-col-md-6 table-header\"><span>Printer</span></div>\n      <div class=\"mui-col-md-2 table-header\"><span>Location</span></div>\n      <div class=\"mui-col-md-2 table-header\"><span>Status</span></div>\n      <div class=\"mui-col-md-1 table-header\"><span>Enable</span></div>\n      <div class=\"mui-col-md-1 table-header\"><span>Options</span></div>\n    </div>\n    <div class=\"mui-row table-row\">\n      <div class=\"mui-col-md-6 table-data\"><span>[ printer ]</span></div>\n      <div class=\"mui-col-md-2 table-data\"><span>[ location ]</span></div>\n      <div class=\"mui-col-md-2 table-data\"><span>[ status ]</span></div>\n      <div class=\"mui-col-md-1 table-data text-align-center\"><span><input type=\"checkbox\" name=\"input-id\" value=\"enable\" /></span></div>\n      <div class=\"mui-col-md-1 table-data text-align-center\">\n        <button mat-button (click)=\"openDialog(1,'delete','Printer')\" class=\"button-trash\">\n          <span class=\"fa fa-trash\"></span>\n        </button>\n      </div>\n    </div>\n  </div>\n  <div class=\"mui-row\">\n    <div class=\"mui-col-md-4\">&nbsp;</div>\n    <div class=\"mui-col-md-4 form-item text-align-center\">\n      <button mat-button class=\"button-submit\" type=\"submit\">Save</button>\n    </div>\n    <div class=\"mui-col-md-4\"></div>\n  </div>\n\n</form>\n"

/***/ }),

/***/ "./src/app/config/config-resources/config-resources.component.ts":
/*!***********************************************************************!*\
  !*** ./src/app/config/config-resources/config-resources.component.ts ***!
  \***********************************************************************/
/*! exports provided: ConfigResourcesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConfigResourcesComponent", function() { return ConfigResourcesComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _dialogs_dialogs_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../dialogs/dialogs.component */ "./src/app/dialogs/dialogs.component.ts");
/* harmony import */ var _resource_modal_resource_modal_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../resource-modal/resource-modal.component */ "./src/app/config/resource-modal/resource-modal.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var ConfigResourcesComponent = /** @class */ (function () {
    function ConfigResourcesComponent(dialog) {
        this.dialog = dialog;
    }
    ConfigResourcesComponent.prototype.openDialog = function (id, type, text) {
        this.dialogWidth = 450;
        var dialogRef = this.dialog.open(_dialogs_dialogs_component__WEBPACK_IMPORTED_MODULE_2__["DialogsComponent"], {
            width: this.dialogWidth + 'px',
            data: {
                dialogText: text,
                dialogType: type
            },
            hasBackdrop: false
        });
        this.screenWidth = (window.screen.width);
        this.leftPosition = ((window.screen.width) - this.dialogWidth) / 2;
        dialogRef.updatePosition({ top: '15%', left: this.leftPosition + 'px' });
    };
    ConfigResourcesComponent.prototype.activateModal = function () {
        this.dialogWidth = 600;
        this.screenWidth = (window.screen.width);
        this.leftPosition = ((window.screen.width) - this.dialogWidth) / 2;
        var dialogRef = this.dialog.open(_resource_modal_resource_modal_component__WEBPACK_IMPORTED_MODULE_3__["ResourceModalComponent"], {
            width: this.dialogWidth + 'px',
        });
        dialogRef.updatePosition({ top: '5%', left: this.leftPosition + 'px' });
    };
    ConfigResourcesComponent.prototype.ngOnInit = function () { };
    ConfigResourcesComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-config-resources',
            template: __webpack_require__(/*! ./config-resources.component.html */ "./src/app/config/config-resources/config-resources.component.html"),
            styles: [__webpack_require__(/*! ./config-resources.component.css */ "./src/app/config/config-resources/config-resources.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_material__WEBPACK_IMPORTED_MODULE_1__["MatDialog"]])
    ], ConfigResourcesComponent);
    return ConfigResourcesComponent;
}());



/***/ }),

/***/ "./src/app/config/config-sensors/config-sensors.component.css":
/*!********************************************************************!*\
  !*** ./src/app/config/config-sensors/config-sensors.component.css ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n"

/***/ }),

/***/ "./src/app/config/config-sensors/config-sensors.component.html":
/*!*********************************************************************!*\
  !*** ./src/app/config/config-sensors/config-sensors.component.html ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"titlebar\">\n  <h2>Sensors</h2>\n</div>\n<form id=\"config-sensors\" method=\"post\">\n  <div id=\"file-system-list\" class=\"table-container padding-left-15\">\n    <div class=\"mui-row table-header-row\">\n      <div class=\"mui-col-md-6 table-header\"><span>Sensor Context</span></div>\n      <div class=\"mui-col-md-1 table-header\"><span>Off</span></div>\n      <div class=\"mui-col-md-1 table-header\"><span>Default</span></div>\n      <div class=\"mui-col-md-1 table-header\"><span>Low</span></div>\n      <div class=\"mui-col-md-1 table-header\"><span>High</span></div>\n      <div class=\"mui-col-md-1 table-header\"><span>Adverserial</span></div>\n      <div class=\"mui-col-md-1 table-header\"><span>&nbsp;</span></div>\n    </div>\n\n    <div class=\"mui-row table-row\">\n      <div class=\"mui-col-md-6 table-data\"><span>In-resource (Unikernel)</span></div>\n      <mat-radio-group>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"off\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"default\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"low\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"high\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"adversarial\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1\"><span>&nbsp;</span></div>\n      </mat-radio-group>\n    </div>\n    <div class=\"mui-row table-row\">\n      <div class=\"mui-col-md-6 table-data\"><span>In-resource (Unikernel)</span></div>\n      <mat-radio-group>\n        <div class=\"mui-col-md-1 table-data text-align-center\">\n          <mat-radio-button name=\"input-id\" value=\"off\" ></mat-radio-button>\n        </div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"default\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"low\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"high\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"adversarial\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1\"><span>&nbsp;</span></div>\n      </mat-radio-group>\n    </div>\n    <div class=\"mui-row table-row\">\n      <div class=\"mui-col-md-6 table-data\"><span>In-Virtue Controller</span></div>\n      <mat-radio-group>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"off\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"default\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"low\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"high\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"adversarial\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1\"><span>&nbsp;</span></div>\n      </mat-radio-group>\n    </div>\n    <div class=\"mui-row table-row\">\n      <div class=\"mui-col-md-6 table-data\"><span>Logging</span></div>\n      <mat-radio-group>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"off\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"default\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"low\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"high\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"adversarial\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1\"><span>&nbsp;</span></div>\n      </mat-radio-group>\n    </div>\n    <div class=\"mui-row table-row\">\n      <div class=\"mui-col-md-6 table-data\">\n        <span class=\"fa fa-level-up fa-rotate-90 margin-right-10\"></span>\n        <span>Aggregator</span>\n      </div>\n      <mat-radio-group>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"off\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"default\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"low\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"high\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"adversarial\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1\"><span>&nbsp;</span></div>\n      </mat-radio-group>\n    </div>\n    <div class=\"mui-row table-row\">\n      <div class=\"mui-col-md-6 table-data\">\n        <span class=\"fa fa-level-up fa-rotate-90 margin-right-10\"></span>\n        <span>Archive</span>\n      </div>\n      <mat-radio-group>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"off\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"default\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"low\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"high\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"adversarial\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1\"><span>&nbsp;</span></div>\n      </mat-radio-group>\n    </div>\n    <div class=\"mui-row table-row\">\n      <div class=\"mui-col-md-6 table-data\"><span>Certificates Infrastructure</span></div>\n      <mat-radio-group>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"off\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"default\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"low\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"high\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1 table-data text-align-center\"><span><mat-radio-button name=\"input-id\" value=\"adversarial\" ></mat-radio-button></span></div>\n        <div class=\"mui-col-md-1\"><span>&nbsp;</span></div>\n      </mat-radio-group>\n    </div>\n  </div>\n  <div class=\"mui-row\">\n    <div class=\"mui-col-md-4\">&nbsp;</div>\n    <div class=\"mui-col-md-4 form-item text-align-center\">\n      <button mat-button class=\"button-submit\" type=\"submit\">Save</button>\n    </div>\n    <div class=\"mui-col-md-4\"></div>\n  </div>\n\n</form>\n"

/***/ }),

/***/ "./src/app/config/config-sensors/config-sensors.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/config/config-sensors/config-sensors.component.ts ***!
  \*******************************************************************/
/*! exports provided: ConfigSensorsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConfigSensorsComponent", function() { return ConfigSensorsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var ConfigSensorsComponent = /** @class */ (function () {
    function ConfigSensorsComponent() {
    }
    ConfigSensorsComponent.prototype.ngOnInit = function () {
    };
    ConfigSensorsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-config-sensors',
            template: __webpack_require__(/*! ./config-sensors.component.html */ "./src/app/config/config-sensors/config-sensors.component.html"),
            styles: [__webpack_require__(/*! ./config-sensors.component.css */ "./src/app/config/config-sensors/config-sensors.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], ConfigSensorsComponent);
    return ConfigSensorsComponent;
}());



/***/ }),

/***/ "./src/app/config/config.component.css":
/*!*********************************************!*\
  !*** ./src/app/config/config.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n::ng-deep  .config .cdk-overlay-pane {\n  max-width: 180px;\n  position: absolute;\n  left: 724px;\n  top: 170px;\n}\n::ng-deep .config .mat-select-pane {\n   border:1px solid #b2b2b2;\n   padding: 5px;\n   position: absolute;\n}\n.config-split-pane {\n  border-bottom: 1px solid #B2B2B2;\n  border-right: 1px solid #B2B2B2;\n  border-top: 1px solid #B2B2B2;\n  display: flex;\n  flex-direction: row;\n  align-items: stretch;\n  min-height: 748px;\n}\n.vertical-tabs {\n  background-color: #E9E3E6;\n  border-left: 1px solid #b2b2b2;\n  border-right: 1px solid #b2b2b2;\n  min-width: 236px;\n  padding: 0 1.5rem;\n}\n.vertical-tabs .mui-tabs__bar {\n  border: 1px solid #b2b2b2;\n  padding: 0;\n}\n.vertical-tabs .mui-tabs__bar li {\n  background-color: #f2f1f2;\n  border-bottom: 1px solid #b2b2b2;\n  display: block;\n  padding: 0;\n}\n.vertical-tabs .mui-tabs__bar li:last-child {\n  border-bottom: none;\n}\n.vertical-tabs .mui-tabs__bar li.mui--is-active {\n  background-color: #FFF;\n}\n.vertical-tabs .mui-tabs__bar li a {\n  color: #3E3F4E;\n  cursor: pointer;\n  line-height: 48px;\n  text-transform: none;\n}\n.vertical-tabs .mui-tabs__bar li a span.fa {\n  float: right;\n  font-size: 1.5rem;\n  font-weight: 700;\n  line-height: 48px;\n  color: #9A8F97;\n}\n.vertical-tabs .mui-tabs__bar li.mui--is-active a span.fa {\n  color:#40709A;\n}\n.vertical-tabs .mui-tabs__bar li a:hover {\n  background-color: rgba(255,255,255,0.65);\n}\n.vertical-tabs-content {\n  border-right: rgba(0,0,0,0.12);\n  height: 100%;\n}\n#vm-list {\n  border: 1px solid #B2B2B2;\n  overflow-y: scroll;\n}\n"

/***/ }),

/***/ "./src/app/config/config.component.html":
/*!**********************************************!*\
  !*** ./src/app/config/config.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"content-container\" class=\"config\">\n  <div id=\"content-header\">\n    <h1 class=\"title\">Global Settings</h1>\n  </div>\n\n  <div id=\"content-main\">\n    <div id=\"content\" class=\"mui-container-fluid\">\n        <div class=\"mui-row config-split-pane\">\n          <div class=\"mui-col-md-3 vertical-tabs\">\n            <div class=\"margin-top-20\">&nbsp;</div>\n            <ul class=\"mui-tabs__bar\">\n             <li class=\"mui--is-active\">\n               <a data-mui-toggle=\"tab\" data-mui-controls=\"activeDirectories\">\n                 <span class=\"float-left\">Active Directories</span>\n                 <span class=\"fa fa-angle-right\"></span>\n               </a>\n             </li>\n             <li>\n               <a data-mui-toggle=\"tab\" data-mui-controls=\"appVMs\">\n                 <span class=\"float-left\">Applications Manager</span>\n                 <span class=\"fa fa-angle-right\"></span>\n               </a>\n             </li>\n             <li>\n               <a data-mui-toggle=\"tab\" data-mui-controls=\"resources\">\n                 <span class=\"float-left\">Resources</span>\n                 <span class=\"fa fa-angle-right\"></span>\n               </a>\n             </li>\n             <li>\n               <a data-mui-toggle=\"tab\" data-mui-controls=\"sensors\">\n                 <span class=\"float-left\">Sensors</span>\n                 <span class=\"fa fa-angle-right\"></span>\n               </a>\n             </li>\n           </ul>\n         </div>\n        <div class=\"mui-col-md-9 vertical-tabs-content\">\n          <div class=\"mui-tabs__pane mui--is-active\" id=\"activeDirectories\">\n            <div class=\"tab-pane-content\">\n              <app-config-active-dir></app-config-active-dir>\n            </div>\n          </div>\n\n          <div class=\"mui-tabs__pane\" id=\"appVMs\">\n            <div class=\"tab-pane-content\">\n              <app-config-app-vm></app-config-app-vm>\n            </div>\n          </div>\n\n          <div class=\"mui-tabs__pane\" id=\"resources\">\n            <div class=\"tab-pane-content\">\n              <app-config-resources></app-config-resources>\n            </div>\n          </div>\n\n          <div class=\"mui-tabs__pane\" id=\"sensors\">\n            <div class=\"tab-pane-content\">\n              <app-config-sensors></app-config-sensors>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/config/config.component.ts":
/*!********************************************!*\
  !*** ./src/app/config/config.component.ts ***!
  \********************************************/
/*! exports provided: ConfigComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConfigComponent", function() { return ConfigComponent; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var ConfigComponent = /** @class */ (function () {
    function ConfigComponent(location) {
        this.location = location;
    }
    ConfigComponent.prototype.ngOnInit = function () {
    };
    ConfigComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-config',
            template: __webpack_require__(/*! ./config.component.html */ "./src/app/config/config.component.html"),
            styles: [__webpack_require__(/*! ./config.component.css */ "./src/app/config/config.component.css")],
            providers: [
                _angular_common__WEBPACK_IMPORTED_MODULE_0__["Location"],
                { provide: _angular_common__WEBPACK_IMPORTED_MODULE_0__["LocationStrategy"], useClass: _angular_common__WEBPACK_IMPORTED_MODULE_0__["HashLocationStrategy"] }
            ]
        }),
        __metadata("design:paramtypes", [_angular_common__WEBPACK_IMPORTED_MODULE_0__["Location"]])
    ], ConfigComponent);
    return ConfigComponent;
}());



/***/ }),

/***/ "./src/app/config/resource-modal/file-share/file-share.component.css":
/*!***************************************************************************!*\
  !*** ./src/app/config/resource-modal/file-share/file-share.component.css ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".mui-row {\n  margin-bottom: 10px;\n}\n"

/***/ }),

/***/ "./src/app/config/resource-modal/file-share/file-share.component.html":
/*!****************************************************************************!*\
  !*** ./src/app/config/resource-modal/file-share/file-share.component.html ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"mui-row margin-bottom-10\">\n  <div class=\"mui-col-md-4 text-align-right\">\n    <label>File Share Type:</label>\n  </div>\n  <div class=\"mui-col-md-4\">\n    <mat-form-field>\n      <mat-select [(ngModel)]=\"fsValue\" name=\"fileShareType\" [(value)]=\"selected\">\n        <mat-option *ngFor=\"let fsType of fileShareTypes\" [value]=\"fsType.value\">{{ fsType.viewValue }}</mat-option>\n      </mat-select>\n    </mat-form-field>\n  </div>\n  <div class=\"mui-col-md-4\">\n    &nbsp;\n  </div>\n</div>\n<!-- BEGIN if file share type is NFS //-->\n<div id=\"nfs\" *ngIf=\"selected == 'NFS'\">\n    <div class=\"mui-row margin-bottom-10\">\n      <div class=\"mui-col-md-4 text-align-right\">\n        <label>File Share Name:</label>\n      </div>\n      <div class=\"mui-col-md-4\">\n        <mat-form-field>\n           <input matInput name=\"fileShareName\" value=\"\">\n        </mat-form-field>\n      </div>\n      <div class=\"mui-col-md-4\">\n        &nbsp;\n      </div>\n    </div>\n\n    <div class=\"mui-row margin-bottom-10\">\n      <div class=\"mui-col-md-4 text-align-right\">\n        <label>Server Address:</label>\n      </div>\n      <div class=\"mui-col-md-4\">\n        <mat-form-field>\n           <input matInput name=\"serverAddress\" value=\"\">\n        </mat-form-field>\n      </div>\n      <div class=\"mui-col-md-4\">\n        &nbsp;\n      </div>\n    </div>\n\n    <div class=\"mui-row margin-bottom-10\">\n      <div class=\"mui-col-md-4 text-align-right\">\n        <label>Folder:</label>\n      </div>\n      <div class=\"mui-col-md-4\">\n        <mat-form-field>\n           <input matInput name=\"folder\" value=\"\">\n        </mat-form-field>\n      </div>\n      <div class=\"mui-col-md-4\">\n        &nbsp;\n      </div>\n    </div>\n\n    <div class=\"mui-row margin-bottom-10\">\n      <div class=\"mui-col-md-4 text-align-right\">\n        <label>Share Permissions:</label>\n      </div>\n      <div class=\"mui-col-md-4\">\n        <mat-checkbox name=\"sharePermission\" value=\"R\">Read</mat-checkbox>\n        <mat-checkbox name=\"sharePermission\" value=\"W\">Write</mat-checkbox>\n      </div>\n      <div class=\"mui-col-md-4\">\n        &nbsp;\n      </div>\n    </div>\n\n    <div class=\"mui-row margin-bottom-10\">\n      <div class=\"mui-col-md-4\">&nbsp;</div>\n      <div class=\"mui-col-md-4\">\n           <mat-checkbox name=\"adCredentials\" value=\"true\">Use Active Directory Credentials</mat-checkbox>\n      </div>\n      <div class=\"mui-col-md-4\">\n        &nbsp;\n      </div>\n    </div>\n  </div>\n<!-- END if file share type is NFS //-->\n<!-- BEGIN if file share type is CIFS //-->\n<div id=\"cifs\" *ngIf=\"selected == 'CIFS'\">\n    <div class=\"mui-row margin-bottom-10\">\n      <div class=\"mui-col-md-4 text-align-right\">\n        <label>File Share Name:</label>\n      </div>\n      <div class=\"mui-col-md-4\">\n        <mat-form-field>\n           <input matInput name=\"fileShareName\" value=\"\">\n        </mat-form-field>\n      </div>\n      <div class=\"mui-col-md-4\">\n        &nbsp;\n      </div>\n    </div>\n\n    <div class=\"mui-row margin-bottom-10\">\n      <div class=\"mui-col-md-4 text-align-right\">\n        <label>Drive:</label>\n      </div>\n      <div class=\"mui-col-md-4\">\n        <mat-form-field>\n           <input matInput name=\"serverAddress\" value=\"\">\n        </mat-form-field>\n      </div>\n      <div class=\"mui-col-md-4\">\n        &nbsp;\n      </div>\n    </div>\n\n    <div class=\"mui-row margin-bottom-10\">\n      <div class=\"mui-col-md-4 text-align-right\">\n        <label>Folder:</label>\n      </div>\n      <div class=\"mui-col-md-4\">\n        <mat-form-field>\n           <input matInput name=\"folder\" value=\"\">\n        </mat-form-field>\n      </div>\n      <div class=\"mui-col-md-4\">\n        &nbsp;\n      </div>\n    </div>\n\n    <div class=\"mui-row margin-bottom-10\">\n      <div class=\"mui-col-md-4 text-align-right\">\n        &nbsp;\n      </div>\n      <div class=\"mui-col-md-4\">\n        <mat-checkbox name=\"reconnect\" value=\"true\">Reconnect at sign-on</mat-checkbox>\n        <mat-checkbox name=\"diffCredentials\" value=\"true\">Connect using different credentials</mat-checkbox>\n      </div>\n      <div class=\"mui-col-md-4\">\n        &nbsp;\n      </div>\n    </div>\n\n    <div class=\"mui-row margin-bottom-10\">\n      <div class=\"mui-col-md-4\"><label>Share Permissions:</label></div>\n      <div class=\"mui-col-md-4\">\n        <mat-checkbox name=\"sharePermission\" value=\"R\">Read</mat-checkbox>\n        <mat-checkbox name=\"sharePermission\" value=\"W\">Write</mat-checkbox>\n      </div>\n      <div class=\"mui-col-md-4\">\n        &nbsp;\n      </div>\n    </div>\n  </div>\n<!-- END if file share type is CIFS //-->\n"

/***/ }),

/***/ "./src/app/config/resource-modal/file-share/file-share.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/config/resource-modal/file-share/file-share.component.ts ***!
  \**************************************************************************/
/*! exports provided: FileShareComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FileShareComponent", function() { return FileShareComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var FileShareComponent = /** @class */ (function () {
    function FileShareComponent() {
        this.fileShareTypes = [
            { value: 'NFS', viewValue: 'NFS' },
            { value: 'CIFS', viewValue: 'Windows (CIFS)' },
        ];
    }
    FileShareComponent.prototype.ngOnInit = function () {
    };
    FileShareComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-file-share',
            template: __webpack_require__(/*! ./file-share.component.html */ "./src/app/config/resource-modal/file-share/file-share.component.html"),
            styles: [__webpack_require__(/*! ./file-share.component.css */ "./src/app/config/resource-modal/file-share/file-share.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], FileShareComponent);
    return FileShareComponent;
}());



/***/ }),

/***/ "./src/app/config/resource-modal/printers/printers.component.css":
/*!***********************************************************************!*\
  !*** ./src/app/config/resource-modal/printers/printers.component.css ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "#printer-list {\n  border: 1px solid #b2b2b2;\n  display: block;\n  height: 280px;\n  margin-top: 10px;\n  overflow-x: hidden;\n  overflow-y: scroll;\n}\n\n#printer-list .printer-item {\n  border-bottom: 1px solid #b2b2b2;\n  display: block;\n  /*padding: 10px 5px;*/\n}\n\n#printer-list .printer-item .mat-checkbox {\n  box-sizing: border-box;\n  display: block;\n  margin: 0;\n  padding: 12px 10px;\n}\n\n#printer-list .printer-item .mat-checkbox-label {\n  width: inherit;\n}\n\n#printer-list .printer-item .mat-checkbox:hover {\n  background-color: rgba(63,153,192,0.25);\n}\n\n.printer-icon, .printer-name, .printer-loc {\n  display: block;\n  float: left;\n}\n\n.printer-icon {\n    background: url(/assets/images/networked-printer.png) no-repeat left top;\n    background-size: contain;\n    height: 23px;\n    margin: 0 5px;\n    width: 26px;\n}\n\n.printer-name {\n   width: 260px;\n }\n\n.printer-loc {\n  float: right;\n  width: auto%;\n}\n"

/***/ }),

/***/ "./src/app/config/resource-modal/printers/printers.component.html":
/*!************************************************************************!*\
  !*** ./src/app/config/resource-modal/printers/printers.component.html ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"mui-row margin-bottom-10\">\n  <div class=\"mui-col-md-12\">\n    <label [ngStyle]=\"{'padding-bottom': '10px'}\">File Shared Printer:</label>\n  </div>\n</div>\n<div id=\"printer-list\">\n  <div class=\"mui-row printer-item\" *ngFor=\"let p of printers\">\n    <div class=\"mui-col-md-12\">\n       <mat-checkbox name=\"printers\" value=\"{{ p.value }}\">\n        <span class=\"printer-icon\"></span>\n        <span class=\"printer-name\">{{ p.viewValue }}</span>\n        <span class=\"printer-loc\">{{ p.printerLoc }}</span>\n       </mat-checkbox>\n    </div>\n\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/config/resource-modal/printers/printers.component.ts":
/*!**********************************************************************!*\
  !*** ./src/app/config/resource-modal/printers/printers.component.ts ***!
  \**********************************************************************/
/*! exports provided: PrintersComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PrintersComponent", function() { return PrintersComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var PrintersComponent = /** @class */ (function () {
    function PrintersComponent() {
        this.printers = [
            { value: '1', viewValue: 'HP Color DeskJet CP5225dn', printerLoc: '29.50.123.7 on FCVA' },
            { value: '2', viewValue: 'HP OfficeJet Pro 8710', printerLoc: '29.50.244.236 on FCVA' },
            { value: '3', viewValue: 'Printer name here', printerLoc: '29.495.66.123 on FCVA' },
        ];
    }
    PrintersComponent.prototype.ngOnInit = function () {
    };
    PrintersComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-printers',
            template: __webpack_require__(/*! ./printers.component.html */ "./src/app/config/resource-modal/printers/printers.component.html"),
            styles: [__webpack_require__(/*! ./printers.component.css */ "./src/app/config/resource-modal/printers/printers.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], PrintersComponent);
    return PrintersComponent;
}());



/***/ }),

/***/ "./src/app/config/resource-modal/resource-modal.component.css":
/*!********************************************************************!*\
  !*** ./src/app/config/resource-modal/resource-modal.component.css ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "#resources .mui-row {\n  margin-bottom: 10px;\n}\n"

/***/ }),

/***/ "./src/app/config/resource-modal/resource-modal.component.html":
/*!*********************************************************************!*\
  !*** ./src/app/config/resource-modal/resource-modal.component.html ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<form id=\"resources\">\n<h2 mat-dialog-title>Add New Resource</h2>\n<div mat-dialog-content class=\"mui-row\">\n  <div class=\"mui-col-md-12\">\n    <div class=\"mui-row border-top margin-bottom-20\">\n      <div class=\"mui-col-md-4 text-align-right\">\n        <label>Resource Type:</label>\n      </div>\n      <div class=\"mui-col-md-4\">\n        <mat-form-field>\n          <mat-select [(ngModel)]=\"resourceValue\" name=\"resourceType\" [(value)]=\"selected\" disableRipple>\n            <mat-option *ngFor=\"let r of resources\" [value]=\"r.value\">{{ r.viewValue }}</mat-option>\n          </mat-select>\n        </mat-form-field>\n      </div>\n      <div class=\"mui-col-md-4\">\n        &nbsp;\n      </div>\n    </div>\n    <hr />\n\n    <app-file-share *ngIf=\"selected == 'File Share'\"></app-file-share>\n\n    <app-printers *ngIf=\"selected == 'Printers'\"></app-printers>\n\n  </div>\n</div>\n\n<div mat-dialog-actions>\n  <button mat-button class=\"button\" type=\"submit\" (click)=\"saveResource();\">\n  Add\n  </button>\n  <button mat-button type=\"button\" mat-dialog-close>\n    Cancel\n  </button>\n</div>\n</form>\n"

/***/ }),

/***/ "./src/app/config/resource-modal/resource-modal.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/config/resource-modal/resource-modal.component.ts ***!
  \*******************************************************************/
/*! exports provided: ResourceModalComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResourceModalComponent", function() { return ResourceModalComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var ResourceModalComponent = /** @class */ (function () {
    function ResourceModalComponent(dialogRef) {
        this.dialogRef = dialogRef;
        this.resources = [
            { value: 'File Share', viewValue: 'File Share' },
            { value: 'Printers', viewValue: 'Printers' }
        ];
    }
    ResourceModalComponent.prototype.saveResource = function () {
        this.dialogRef.close();
    };
    ResourceModalComponent.prototype.ngOnInit = function () {
    };
    ResourceModalComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-resource-modal',
            template: __webpack_require__(/*! ./resource-modal.component.html */ "./src/app/config/resource-modal/resource-modal.component.html"),
            styles: [__webpack_require__(/*! ./resource-modal.component.css */ "./src/app/config/resource-modal/resource-modal.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_material__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"]])
    ], ResourceModalComponent);
    return ResourceModalComponent;
}());



/***/ }),

/***/ "./src/app/dashboard/dashboard.component.css":
/*!***************************************************!*\
  !*** ./src/app/dashboard/dashboard.component.css ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "app-dashboard {\n  position: relative;\n}\n\n.table-container {\n  margin: 0 -15px 10px;\n  overflow-x: hidden;\n  overflow-y: scroll;\n}\n\n.table-container .mui-row {\n  margin-left: 0;\n  margin-right: 0;\n}\n\n/deep/ .mat-form-field-underline {\n  display: none;\n}\n"

/***/ }),

/***/ "./src/app/dashboard/dashboard.component.html":
/*!****************************************************!*\
  !*** ./src/app/dashboard/dashboard.component.html ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"content-container\" class=\"dashboard\">\n  <div id=\"content-header\" class=\"titlebar\">\n    <h1 class=\"title\">Dashboard</h1>\n  </div>\n\n  <div id=\"content-main\">\n    <div id=\"content\">\n      <div class=\"mui-container-fluid\">\n        <!-- if there are no virtues, show this message -->\n        <div class=\"mui-row margin-top-10\">\n          <div class=\"mui-col-md-12 padding-left-0\">\n            <div class=\"mui-container-fluid\">\n              <div class=\"mui-row\">\n                <div class=\"mui-col-md-3 table-header\">Sensor</div>\n                <div class=\"mui-col-md-3 table-header\">Virtue</div>\n                <div class=\"mui-col-md-3 table-header\">Kafka Topic</div>\n                <div class=\"mui-col-md-1 table-header\">Certificate</div>\n                <div class=\"mui-col-md-2 table-header\">Last Update</div>\n              </div>\n              <div *ngIf=\"sensorData.length < 1\" class=\"table-container\">\n                <div class=\"mui-row\">\n                  <div class=\"mui-col-md-12 table-data\">\n                    <p>No sensor information is available at this time.</p>\n                  </div>\n                </div>\n              </div>\n              <div *ngIf=\"sensorData.length > 0\" class=\"table-container\">\n                <div class=\"mui-row\" *ngFor=\"let d of sensorData\">\n                  <div class=\"mui-col-md-3 table-data\">{{ d.sensor_id }}</div>\n                  <div class=\"mui-col-md-3 table-data\">{{ getSensorInfo(d.virtue_id, 'virtue_id') }}</div>\n                  <div class=\"mui-col-md-3 table-data\">{{ d.kafka_topic }}</div>\n                  <div class=\"mui-col-md-1 table-data border-bottom\">{{ getSensorInfo(d.has_certificates, 'certs') }}</div>\n                  <div class=\"mui-col-md-2 table-data\">{{d.updated_at|date:\"MM/dd/yyyy, h:mm a\"}}</div>\n                </div>\n              </div>\n            </div>\n\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/dashboard/dashboard.component.ts":
/*!**************************************************!*\
  !*** ./src/app/dashboard/dashboard.component.ts ***!
  \**************************************************/
/*! exports provided: DashboardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardComponent", function() { return DashboardComponent; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../shared/services/baseUrl.service */ "./src/app/shared/services/baseUrl.service.ts");
/* harmony import */ var _shared_services_sensing_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../shared/services/sensing.service */ "./src/app/shared/services/sensing.service.ts");
/* harmony import */ var _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../shared/services/virtues.service */ "./src/app/shared/services/virtues.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var DashboardComponent = /** @class */ (function () {
    // constructor(){}
    function DashboardComponent(location, baseUrlService, sensingService, virtuesService) {
        this.baseUrlService = baseUrlService;
        this.sensingService = sensingService;
        this.virtuesService = virtuesService;
        this.columns = [
            { value: '', viewValue: 'Select Column' },
            { value: 'timestamp', viewValue: 'Timestamp' },
            { value: 'sensor_id', viewValue: 'ID' },
            { value: 'sensor', viewValue: 'Sensor Name' },
            { value: 'message', viewValue: 'Message' },
            { value: 'level', viewValue: 'level' }
        ];
        this.sensors = [
            { value: '', viewValue: 'Select One' },
            { value: ' 0000 ', viewValue: 'DEFAULT' },
            { value: 'chr', viewValue: 'CHR' },
            { value: 'dir', viewValue: 'DIR' },
            { value: 'fifo', viewValue: 'FIFO' },
            { value: 'ipv4', viewValue: 'IPv4' },
            { value: 'reg', viewValue: 'REG' },
            { value: 'unix', viewValue: 'Unix' },
        ];
        this.sensorData = [];
        this.virtues = [];
        this.location = location;
    }
    DashboardComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.baseUrlService.getBaseUrl().subscribe(function (res) {
            var awsServer = res[0].aws_server;
            _this.getVirtueInfo(awsServer);
            _this.getSensingData(awsServer);
        });
    };
    DashboardComponent.prototype.getSensingData = function (baseUrl) {
        var _this = this;
        this.sensingService.getSensingLog(baseUrl).subscribe(function (data) {
            if (data.length > 0) {
                _this.sensorData = data[0].sensors;
                console.log(_this.sensorData);
            }
            else {
                _this.getStaticData();
            }
        });
    };
    DashboardComponent.prototype.getStaticData = function () {
        var _this = this;
        this.sensingService.getStaticList().subscribe(function (data) {
            // console.log(data[0].sensors);
            _this.sensorData = data[0].sensors;
            // console.log('sensing data not found...');
        });
    };
    DashboardComponent.prototype.sensorlog = function (log) {
        // console.log('sensorlog ... ' + this.sensorData.error);
        this.sensorData = log;
    };
    DashboardComponent.prototype.getVirtueInfo = function (baseUrl) {
        var _this = this;
        this.virtuesService.getVirtues(baseUrl).subscribe(function (virtues) {
            _this.virtues = virtues;
        });
    };
    DashboardComponent.prototype.getSensorInfo = function (value, prop) {
        if (prop === 'virtue_id') {
            var sensorValue = this.getVirtueName(value);
            // return this.virtueName;
            return sensorValue;
        }
        else if (prop === 'certs') {
            if (value) {
                return 'Yes';
            }
            else {
                return 'No';
            }
        }
    };
    DashboardComponent.prototype.getVirtueName = function (id) {
        for (var _i = 0, _a = this.virtues; _i < _a.length; _i++) {
            var virtue = _a[_i];
            if (id === virtue.id) {
                // console.log(virtue.name);
                return virtue.name;
            }
            else {
                return id;
            }
        }
    };
    DashboardComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-dashboard',
            template: __webpack_require__(/*! ./dashboard.component.html */ "./src/app/dashboard/dashboard.component.html"),
            styles: [__webpack_require__(/*! ./dashboard.component.css */ "./src/app/dashboard/dashboard.component.css")],
            providers: [
                _angular_common__WEBPACK_IMPORTED_MODULE_0__["Location"],
                { provide: _angular_common__WEBPACK_IMPORTED_MODULE_0__["LocationStrategy"], useClass: _angular_common__WEBPACK_IMPORTED_MODULE_0__["HashLocationStrategy"] },
                _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_2__["BaseUrlService"], _shared_services_sensing_service__WEBPACK_IMPORTED_MODULE_3__["SensingService"], _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_4__["VirtuesService"]
            ]
        }),
        __metadata("design:paramtypes", [_angular_common__WEBPACK_IMPORTED_MODULE_0__["Location"],
            _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_2__["BaseUrlService"],
            _shared_services_sensing_service__WEBPACK_IMPORTED_MODULE_3__["SensingService"],
            _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_4__["VirtuesService"]])
    ], DashboardComponent);
    return DashboardComponent;
}());



/***/ }),

/***/ "./src/app/dialogs/dialogs.component.html":
/*!************************************************!*\
  !*** ./src/app/dialogs/dialogs.component.html ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<form>\n<h2 mat-dialog-title>{{data.dialogType}} {{data.dialogCategory}}</h2>\n<div mat-dialog-content>\n\n  <p>Are you sure you want to {{data.dialogType}} <strong>{{data.dialogDescription}}</strong>?</p>\n\n</div>\n\n<div mat-dialog-actions>\n  <button mat-button type=\"submit\" (click)=\"confirmSelection();\">\n  Yes\n  </button>\n  <button mat-button type=\"button\" mat-dialog-close>\n    No\n  </button>\n</div>\n</form>\n"

/***/ }),

/***/ "./src/app/dialogs/dialogs.component.ts":
/*!**********************************************!*\
  !*** ./src/app/dialogs/dialogs.component.ts ***!
  \**********************************************/
/*! exports provided: DialogsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DialogsComponent", function() { return DialogsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};


var DialogsComponent = /** @class */ (function () {
    function DialogsComponent(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.data = data;
        this.dialogEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        // console.log(this.data);
        this.dialogType = this.data['dialogType'];
        this.dialogCategory = this.data['dialogCategory'];
        this.dialogDescription = this.data['dialogDescription'];
        this.dialogId = this.data['dialogId'];
    }
    DialogsComponent.prototype.ngOnInit = function () {
    };
    DialogsComponent.prototype.confirmSelection = function () {
        if (this.dialogType === 'delete') {
            this.dialogEmitter.emit(this.dialogId);
        }
        this.dialogRef.close();
    };
    DialogsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-dialogs',
            template: __webpack_require__(/*! ./dialogs.component.html */ "./src/app/dialogs/dialogs.component.html")
        }),
        __param(1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(_angular_material__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"])),
        __metadata("design:paramtypes", [_angular_material__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"], Object])
    ], DialogsComponent);
    return DialogsComponent;
}());



/***/ }),

/***/ "./src/app/footer/footer.component.html":
/*!**********************************************!*\
  !*** ./src/app/footer/footer.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<footer>\n  <div id=\"footer-content\">\n    <div class=\"mui-col-md-6\">Savior&trade; VirUE Desktop. &copy; Copyright 2017.</div>\n    <div class=\"mui-col-md-6 text-align-right\">Next Century Corporation</div>\n  </div>\n</footer>\n"

/***/ }),

/***/ "./src/app/footer/footer.component.ts":
/*!********************************************!*\
  !*** ./src/app/footer/footer.component.ts ***!
  \********************************************/
/*! exports provided: FooterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FooterComponent", function() { return FooterComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var FooterComponent = /** @class */ (function () {
    function FooterComponent() {
    }
    FooterComponent.prototype.ngOnInit = function () {
    };
    FooterComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-footer',
            template: __webpack_require__(/*! ./footer.component.html */ "./src/app/footer/footer.component.html")
        }),
        __metadata("design:paramtypes", [])
    ], FooterComponent);
    return FooterComponent;
}());



/***/ }),

/***/ "./src/app/header/header.component.css":
/*!*********************************************!*\
  !*** ./src/app/header/header.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "mat-toolbar.mat-primary {\n  background: rgb(46,41,78)\n}\n.mat-toolbar {\n  clear: both;\n  display: block;\n  height: 34px;\n  width: 100%;\n  padding: 0;\n}\n.mat-toolbar-single-row {\n  padding: 0 16px;\n}\n.mat-toolbar span.navbar-brand {\n  color: rgb(255,255,255);\n  display: inline-block;\n  padding: 0 2.4rem 0 1.5rem;\n}\n.mat-toolbar ul {\n  display: inline-block;\n  margin: 0;\n  padding: 0;\n}\n.mat-toolbar li {\n  display: inline-block;\n  font-size: 1.1rem;\n  margin: 0;\n}\n.mat-toolbar li.active {\n  background-color: #540D6E\n}\n.mat-toolbar li a {\n  color: rgb(255,255,255);\n  display: block;\n  margin: 0;\n  /* padding: 0.47rem 2.4rem 0.47rem; */\n  padding: 0 2.4rem;\n}\n.mat-toolbar span.navbar-brand {\n  background: url(/assets/images/app-icon-white.png) no-repeat;\n  background-size: 15%;\n  background-position: center left;\n  display: inline-block;\n  font-size: 1.1rem;\n  padding-left: 30px;\n  width: auto;\n}\n"

/***/ }),

/***/ "./src/app/header/header.component.html":
/*!**********************************************!*\
  !*** ./src/app/header/header.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<header id=\"banner\">\n  <mat-toolbar color=\"primary\">\n    <span class=\"navbar-brand\">Savior VirtUE</span>\n    <ul class=\"nav navbar-nav\">\n        <li *ngFor=\"let n of navigation\" class=\"nav-item\" routerLinkActive=\"active\">\n          <a class=\"nav-link\" routerLink=\"{{ n.link }}\" title=\"{{ n.value }}\">{{ n.value }}</a>\n        </li>\n    </ul>\n  </mat-toolbar>\n\n</header>\n"

/***/ }),

/***/ "./src/app/header/header.component.ts":
/*!********************************************!*\
  !*** ./src/app/header/header.component.ts ***!
  \********************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var HeaderComponent = /** @class */ (function () {
    function HeaderComponent() {
        this.navigation = [
            { value: 'Dashboard', link: '/dashboard' },
            { value: 'Settings', link: '/settings' },
            { value: 'Users', link: '/users' },
            { value: 'Applications', link: '/applications' },
            { value: 'Virtual Machines', link: '/virtual-machines' },
            { value: 'Virtues', link: '/virtues' }
        ];
    }
    HeaderComponent.prototype.ngOnInit = function () { };
    HeaderComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-header',
            template: __webpack_require__(/*! ./header.component.html */ "./src/app/header/header.component.html"),
            styles: [__webpack_require__(/*! ./header.component.css */ "./src/app/header/header.component.css")]
        })
    ], HeaderComponent);
    return HeaderComponent;
}());



/***/ }),

/***/ "./src/app/page-not-found/page-not-found.component.html":
/*!**************************************************************!*\
  !*** ./src/app/page-not-found/page-not-found.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<p>\n  page-not-found works!\n</p>\n"

/***/ }),

/***/ "./src/app/page-not-found/page-not-found.component.ts":
/*!************************************************************!*\
  !*** ./src/app/page-not-found/page-not-found.component.ts ***!
  \************************************************************/
/*! exports provided: PageNotFoundComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageNotFoundComponent", function() { return PageNotFoundComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var PageNotFoundComponent = /** @class */ (function () {
    function PageNotFoundComponent() {
    }
    PageNotFoundComponent.prototype.ngOnInit = function () {
    };
    PageNotFoundComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-page-not-found',
            template: __webpack_require__(/*! ./page-not-found.component.html */ "./src/app/page-not-found/page-not-found.component.html")
        }),
        __metadata("design:paramtypes", [])
    ], PageNotFoundComponent);
    return PageNotFoundComponent;
}());



/***/ }),

/***/ "./src/app/shared/directives/active-class.directive.ts":
/*!*************************************************************!*\
  !*** ./src/app/shared/directives/active-class.directive.ts ***!
  \*************************************************************/
/*! exports provided: ActiveClassDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ActiveClassDirective", function() { return ActiveClassDirective; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var ActiveClassDirective = /** @class */ (function () {
    function ActiveClassDirective(el, renderer) {
        this.el = el;
        this.renderer = renderer;
    }
    ActiveClassDirective.prototype.ngOnInit = function () {
    };
    ActiveClassDirective.prototype.mouseover = function (eventData) {
        this.renderer.addClass(this.el.nativeElement, 'active');
    };
    ActiveClassDirective.prototype.mouseleave = function (eventData) {
        this.renderer.removeClass(this.el.nativeElement, 'active');
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"])('mouseenter'),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Event]),
        __metadata("design:returntype", void 0)
    ], ActiveClassDirective.prototype, "mouseover", null);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"])('mouseleave'),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Event]),
        __metadata("design:returntype", void 0)
    ], ActiveClassDirective.prototype, "mouseleave", null);
    ActiveClassDirective = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"])({
            selector: '[appActiveClass]'
        }),
        __metadata("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"],
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["Renderer2"]])
    ], ActiveClassDirective);
    return ActiveClassDirective;
}());



/***/ }),

/***/ "./src/app/shared/models/application.model.ts":
/*!****************************************************!*\
  !*** ./src/app/shared/models/application.model.ts ***!
  \****************************************************/
/*! exports provided: Application */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Application", function() { return Application; });
var Application = /** @class */ (function () {
    function Application() {
    }
    return Application;
}());



/***/ }),

/***/ "./src/app/shared/models/breadcrumb.model.ts":
/*!***************************************************!*\
  !*** ./src/app/shared/models/breadcrumb.model.ts ***!
  \***************************************************/
/*! exports provided: Breadcrumb */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Breadcrumb", function() { return Breadcrumb; });
var Breadcrumb = /** @class */ (function () {
    function Breadcrumb(label, href) {
        this.label = label;
        this.href = href;
    }
    return Breadcrumb;
}());



/***/ }),

/***/ "./src/app/shared/models/user.model.ts":
/*!*********************************************!*\
  !*** ./src/app/shared/models/user.model.ts ***!
  \*********************************************/
/*! exports provided: User */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "User", function() { return User; });
var User = /** @class */ (function () {
    function User() {
    }
    User.prototype.User = function (username, authorities, virtueTemplateIds) {
        this.username = username;
        this.authorities = authorities;
        this.virtueTemplateIds = virtueTemplateIds;
    };
    return User;
}());



/***/ }),

/***/ "./src/app/shared/models/virtue.model.ts":
/*!***********************************************!*\
  !*** ./src/app/shared/models/virtue.model.ts ***!
  \***********************************************/
/*! exports provided: Virtue */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Virtue", function() { return Virtue; });
var Virtue = /** @class */ (function () {
    function Virtue() {
    }
    Virtue.prototype.Virtue = function (id, name, version, virtualMachineTemplateIds, enabled, lastEditor, lastModification, awsTemplateName, applicationIds) {
        this.id = id;
        this.name = name;
        this.version = version;
        this.virtualMachineTemplateIds = virtualMachineTemplateIds;
        this.enabled = enabled;
        this.lastEditor = lastEditor;
        this.lastModification = lastModification;
        this.awsTemplateName = awsTemplateName;
        this.applicationIds = applicationIds;
    };
    return Virtue;
}());



/***/ }),

/***/ "./src/app/shared/models/vm.model.ts":
/*!*******************************************!*\
  !*** ./src/app/shared/models/vm.model.ts ***!
  \*******************************************/
/*! exports provided: VirtualMachine */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VirtualMachine", function() { return VirtualMachine; });
var VirtualMachine = /** @class */ (function () {
    function VirtualMachine() {
    }
    VirtualMachine.prototype.VirtualMachine = function (id, name, os, templatePath, loginUser, enabled, lastModification, lastEditor, applicationIds) {
        this.id = id;
        this.name = name;
        this.os = os;
        this.templatePath = templatePath;
        this.loginUser = loginUser;
        this.enabled = enabled;
        this.lastModification = lastModification;
        this.lastEditor = lastEditor;
        this.applicationIds = applicationIds;
    };
    return VirtualMachine;
}());



/***/ }),

/***/ "./src/app/shared/pipes/count-filter.pipe.ts":
/*!***************************************************!*\
  !*** ./src/app/shared/pipes/count-filter.pipe.ts ***!
  \***************************************************/
/*! exports provided: CountFilterPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CountFilterPipe", function() { return CountFilterPipe; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var CountFilterPipe = /** @class */ (function () {
    function CountFilterPipe() {
    }
    CountFilterPipe.prototype.transform = function (value, filterString, propName) {
        if (value.length === 0 || filterString === '') {
            return value.length;
        }
        var resultArray = [];
        for (var _i = 0, value_1 = value; _i < value_1.length; _i++) {
            var item = value_1[_i];
            if (item[propName].match(filterString)) {
                resultArray.push(item);
            }
        }
        return resultArray.length;
    };
    CountFilterPipe = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Pipe"])({
            name: 'count'
        })
    ], CountFilterPipe);
    return CountFilterPipe;
}());



/***/ }),

/***/ "./src/app/shared/pipes/json-filter.pipe.ts":
/*!**************************************************!*\
  !*** ./src/app/shared/pipes/json-filter.pipe.ts ***!
  \**************************************************/
/*! exports provided: JsonFilterPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JsonFilterPipe", function() { return JsonFilterPipe; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var JsonFilterPipe = /** @class */ (function () {
    function JsonFilterPipe() {
    }
    JsonFilterPipe.prototype.transform = function (value, filterString, propName) {
        if (value.length === 0 || filterString === '') {
            return value;
        }
        var resultArray = [];
        for (var _i = 0, value_1 = value; _i < value_1.length; _i++) {
            var item = value_1[_i];
            if (item[propName].toLowerCase().match(filterString)) {
                resultArray.push(item);
            }
        }
        return resultArray;
    };
    JsonFilterPipe = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Pipe"])({
            name: 'filter'
        })
    ], JsonFilterPipe);
    return JsonFilterPipe;
}());



/***/ }),

/***/ "./src/app/shared/pipes/list-filter.pipe.ts":
/*!**************************************************!*\
  !*** ./src/app/shared/pipes/list-filter.pipe.ts ***!
  \**************************************************/
/*! exports provided: ListFilterPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListFilterPipe", function() { return ListFilterPipe; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

/***
This filter can be used with virtue, virtual machine list pages
 */
var ListFilterPipe = /** @class */ (function () {
    function ListFilterPipe() {
    }
    ListFilterPipe.prototype.transform = function (value, filterColumn, filterType, filterValue, filterDirection) {
        if (value.length < 1) {
            return value;
        }
        var sortedList = value.slice(0);
        var resultArray = [];
        if (filterType === 'enabled' && filterValue === true) {
            sortedList = value.filter(function (result) { return result[filterType] === filterValue; });
        }
        else if (filterType === 'enabled' && filterValue === false) {
            sortedList = value.filter(function (result) { return result[filterType] === filterValue; });
        }
        else {
            sortedList = value;
        }
        resultArray = this.sortByColumn(sortedList, filterColumn, filterValue, filterDirection);
        return resultArray;
    };
    ListFilterPipe.prototype.sortByColumn = function (data, column, columnValue, filterDirection) {
        if (column === 'enabled') {
            var sortList = data.filter(function (results) { return results[column] === columnValue; });
            return this.sortData(sortList, column, filterDirection);
        }
        else {
            var sortList = this.sortData(data, column, filterDirection);
            return sortList;
        }
    };
    ListFilterPipe.prototype.sortData = function (data, propertyName, filterDirection) {
        if (propertyName === 'date') {
            propertyName = 'lastModification';
        }
        if (filterDirection === 'desc') {
            // console.log('sorting list by desc order');
            data.sort(function (leftSide, rightSide) {
                if (leftSide[propertyName] < rightSide[propertyName]) {
                    return 1;
                }
                if (leftSide[propertyName] > rightSide[propertyName]) {
                    return -1;
                }
                return 0;
            });
        }
        else {
            // console.log('sorting list by asc order');
            data.sort(function (leftSide, rightSide) {
                if (leftSide[propertyName] < rightSide[propertyName]) {
                    return -1;
                }
                if (leftSide[propertyName] > rightSide[propertyName]) {
                    return 1;
                }
                return 0;
            });
        }
        return data;
    };
    ListFilterPipe = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Pipe"])({
            name: 'listFilter'
        })
    ], ListFilterPipe);
    return ListFilterPipe;
}());



/***/ }),

/***/ "./src/app/shared/providers/breadcrumb.ts":
/*!************************************************!*\
  !*** ./src/app/shared/providers/breadcrumb.ts ***!
  \************************************************/
/*! exports provided: BreadcrumbProvider */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BreadcrumbProvider", function() { return BreadcrumbProvider; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _models_breadcrumb_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../models/breadcrumb.model */ "./src/app/shared/models/breadcrumb.model.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var BreadcrumbProvider = /** @class */ (function () {
    function BreadcrumbProvider(router) {
        this.router = router;
        this._addItem = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
    }
    BreadcrumbProvider.prototype.addItem = function (label, href) {
        if (href === void 0) { href = this.router.url; }
        this._addItem.next(new _models_breadcrumb_model__WEBPACK_IMPORTED_MODULE_3__["Breadcrumb"](label, href));
    };
    BreadcrumbProvider = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]])
    ], BreadcrumbProvider);
    return BreadcrumbProvider;
}());



/***/ }),

/***/ "./src/app/shared/services/applications.service.ts":
/*!*********************************************************!*\
  !*** ./src/app/shared/services/applications.service.ts ***!
  \*********************************************************/
/*! exports provided: ApplicationsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApplicationsService", function() { return ApplicationsService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_observable_of__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/observable/of */ "./node_modules/rxjs-compat/_esm5/observable/of.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var httpHeader = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
};
var ApplicationsService = /** @class */ (function () {
    function ApplicationsService(httpClient) {
        this.httpClient = httpClient;
        this.configUrl = 'admin/application/';
    }
    ApplicationsService.prototype.getAppsList = function (baseUrl) {
        var src = baseUrl + this.configUrl;
        return this.httpClient.get(src);
    };
    ApplicationsService.prototype.getApp = function (baseUrl, id) {
        var src = baseUrl + this.configUrl + id;
        // console.log(src);
        return this.httpClient.get(src);
    };
    /**
      public addApp(vm: Application) {
        return this.httpClient.post( this.restApi, vm );
      }
    
      public updateStatus(id: string): Observable<any> {
        const src = `${this.restApi}`;
        return this.httpClient.get<Application[]>(src);
        // return this.httpClient.put<Application[]>(src, JSON.stringify(app));
      }
    
    
      public updateStatus(id: string, app: Application): Observable<any> {
        return this.httpClient.put(`${this.restApi}?id=${id}`,app);
      }
    
      public deleteVirtue(virtue: Virtue): Observable<Virtue> {
        return this.httpClient.delete<Virtue>(`${this.restApi}/${virtue.id}`);
      }
      */
    /**
     * Handle Http operation that failed.
     * Let the app continue.
     * @ param operation - name of the operation that failed
     * @ param result - optional value to return as the observable result
     */
    ApplicationsService.prototype.handleError = function (operation, result) {
        if (operation === void 0) { operation = 'operation'; }
        return function (error) {
            // TODO: send the error to remote logging infrastructure
            console.error(error); // log to console instead
            // TODO: better job of transforming error for user consumption
            // this.log(`${operation} failed: ${error.message}`);
            // Let the app keep running by returning an empty result.
            return Object(rxjs_observable_of__WEBPACK_IMPORTED_MODULE_2__["of"])(result);
        };
    };
    ApplicationsService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], ApplicationsService);
    return ApplicationsService;
}());



/***/ }),

/***/ "./src/app/shared/services/baseUrl.service.ts":
/*!****************************************************!*\
  !*** ./src/app/shared/services/baseUrl.service.ts ***!
  \****************************************************/
/*! exports provided: BaseUrlService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BaseUrlService", function() { return BaseUrlService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var httpHeader = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
};
var BaseUrlService = /** @class */ (function () {
    function BaseUrlService(httpClient) {
        this.httpClient = httpClient;
        this.jsonfile = './assets/json/baseUrl.json';
    }
    BaseUrlService.prototype.getBaseUrl = function () {
        return this.httpClient.get(this.jsonfile);
    };
    BaseUrlService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], BaseUrlService);
    return BaseUrlService;
}());



/***/ }),

/***/ "./src/app/shared/services/message.service.ts":
/*!****************************************************!*\
  !*** ./src/app/shared/services/message.service.ts ***!
  \****************************************************/
/*! exports provided: MessageService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MessageService", function() { return MessageService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var MessageService = /** @class */ (function () {
    function MessageService() {
        this.messages = [];
    }
    MessageService.prototype.add = function (message) {
        this.messages.push(message);
    };
    MessageService.prototype.clear = function () {
        this.messages = [];
    };
    MessageService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])()
    ], MessageService);
    return MessageService;
}());



/***/ }),

/***/ "./src/app/shared/services/sensing.service.ts":
/*!****************************************************!*\
  !*** ./src/app/shared/services/sensing.service.ts ***!
  \****************************************************/
/*! exports provided: SensingService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SensingService", function() { return SensingService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var httpHeader = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
};
var SensingService = /** @class */ (function () {
    function SensingService(httpClient) {
        this.httpClient = httpClient;
        this.jsonfile = './assets/json/sensing.json';
        this.configUrl = 'admin/sensing';
    }
    SensingService.prototype.getSensingLog = function (baseUrl) {
        var src = baseUrl + this.configUrl;
        return this.httpClient.get(src);
    };
    SensingService.prototype.getStaticList = function () {
        // console.log('using static data');
        return this.httpClient.get(this.jsonfile);
    };
    SensingService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], SensingService);
    return SensingService;
}());



/***/ }),

/***/ "./src/app/shared/services/users.service.ts":
/*!**************************************************!*\
  !*** ./src/app/shared/services/users.service.ts ***!
  \**************************************************/
/*! exports provided: UsersService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsersService", function() { return UsersService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
};
var UsersService = /** @class */ (function () {
    function UsersService(httpClient) {
        this.httpClient = httpClient;
        this.configUrl = 'admin/user/';
    }
    // Get all users
    UsersService.prototype.getUsers = function (baseUrl) {
        var awsServer = baseUrl + this.configUrl;
        return this.httpClient.get(awsServer);
    };
    UsersService.prototype.getUser = function (baseUrl, id) {
        var src = baseUrl + this.configUrl + id;
        // console.log('getUser() --> ' + src);
        return this.httpClient.get(src);
    };
    UsersService.prototype.createUser = function (baseUrl, userData) {
        var awsServer = baseUrl + this.configUrl;
        var newUser = userData;
        if (userData) {
            // console.log('Posting user: ' + newUser);
            return this.httpClient.post(awsServer, newUser, httpOptions);
        }
        else {
            console.log('Sadness, there was a problem creating this user:');
            console.log(newUser);
        }
    };
    /*
    public update(user: User): Observable<any> {
      return this.http.put<User>(`${this.jsondata}/${user.id}`,user);
    }*/
    UsersService.prototype.assignVirtues = function (baseUrl, username, virtue) {
        console.log('assignVirtues => ');
        console.log(username);
        console.log(virtue);
        var userRecord = baseUrl + this.configUrl + username + '/assign/' + virtue;
        return this.httpClient.post(userRecord, virtue, httpOptions).toPromise().then(function (data) {
            return true;
        }, function (error) {
            console.log(error + ': users.service.ts (assignVirtues): looks like there\'s a problem posting virtue ' + virtue);
        });
    };
    UsersService.prototype.updateUser = function (baseUrl, username, userData) {
        var url = baseUrl + this.configUrl + username;
        console.log(url);
        return this.httpClient.put(url, userData, httpOptions);
    };
    UsersService.prototype.deleteUser = function (baseUrl, username) {
        var awsServer = baseUrl + this.configUrl;
        return this.httpClient.delete(awsServer + username).subscribe(function (data) {
            return true;
        }, function (error) {
            console.error('Error');
        });
    };
    UsersService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], UsersService);
    return UsersService;
}());



/***/ }),

/***/ "./src/app/shared/services/virtues.service.ts":
/*!****************************************************!*\
  !*** ./src/app/shared/services/virtues.service.ts ***!
  \****************************************************/
/*! exports provided: VirtuesService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VirtuesService", function() { return VirtuesService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_add_observable_throw__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/add/observable/throw */ "./node_modules/rxjs-compat/_esm5/add/observable/throw.js");
/* harmony import */ var rxjs_add_operator_catch__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/add/operator/catch */ "./node_modules/rxjs-compat/_esm5/add/operator/catch.js");
/* harmony import */ var rxjs_add_operator_toPromise__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/toPromise */ "./node_modules/rxjs-compat/_esm5/add/operator/toPromise.js");
/* harmony import */ var rxjs_add_operator_toPromise__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(rxjs_add_operator_toPromise__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/Observable */ "./node_modules/rxjs-compat/_esm5/Observable.js");
/* harmony import */ var rxjs_observable_of__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/observable/of */ "./node_modules/rxjs-compat/_esm5/observable/of.js");
/* harmony import */ var _message_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./message.service */ "./src/app/shared/services/message.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};








var httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
};
var VirtuesService = /** @class */ (function () {
    // private restApi = './assets/json/virtue_list.json';
    function VirtuesService(httpClient, messageService) {
        this.httpClient = httpClient;
        this.messageService = messageService;
        this.configUrl = 'admin/virtue/template/';
    }
    VirtuesService.prototype.getVirtues = function (baseUrl) {
        var src = baseUrl + this.configUrl;
        return this.httpClient.get(src);
        // .pipe(
        //   tap(virtues => this.log(`fetched virtues`)),
        //   catchError(this.handleError('getVirtues', []))
        // );
    };
    VirtuesService.prototype.getVirtue = function (baseUrl, id) {
        var url = baseUrl + this.configUrl + id;
        return this.httpClient.get(url);
    };
    VirtuesService.prototype.createVirtue = function (baseUrl, virtueData) {
        console.log('createVirtue() => ' + baseUrl);
        var url = baseUrl + this.configUrl;
        return this.httpClient.post(url, virtueData, httpOptions);
    };
    VirtuesService.prototype.deleteVirtue = function (baseUrl, id) {
        var url = baseUrl + this.configUrl + id;
        // console.log('Deleting... ' + url);
        return this.httpClient.delete(url).toPromise().then(function (data) {
            return true;
        }, function (error) {
            console.log(error.message);
        });
    };
    VirtuesService.prototype.updateVirtue = function (baseUrl, id, virtueData) {
        var url = baseUrl + this.configUrl + id;
        console.log(url);
        return this.httpClient.put(url, virtueData, httpOptions)
            .catch(this.errorHandler);
    };
    VirtuesService.prototype.toggleVirtueStatus = function (baseUrl, id) {
        var url = baseUrl + this.configUrl + id + '/toggle';
        // console.log(url);
        return this.httpClient.get(url);
    };
    /**
     * Handle Http operation that failed.
     * Let the app continue.
     * @ param operation - name of the operation that failed
     * @ param result - optional value to return as the observable result
     */
    VirtuesService.prototype.errorHandler = function (error) {
        return rxjs_Observable__WEBPACK_IMPORTED_MODULE_5__["Observable"].throw(error.message || 'Server Error');
    };
    VirtuesService.prototype.handleError = function (operation, result) {
        var _this = this;
        if (operation === void 0) { operation = 'operation'; }
        return function (error) {
            // send the error to remote logging infrastructure
            console.error(error); // log to console instead
            // better job of transforming error for user consumption
            _this.log('operation} failed: ${error.message');
            // Let the app keep running by returning an empty result.
            return Object(rxjs_observable_of__WEBPACK_IMPORTED_MODULE_6__["of"])(result);
        };
    };
    /** Log a HeroService message with the MessageService */
    VirtuesService.prototype.log = function (message) {
        this.messageService.add('VirtueService: ' + message);
    };
    VirtuesService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            _message_service__WEBPACK_IMPORTED_MODULE_7__["MessageService"]])
    ], VirtuesService);
    return VirtuesService;
}());



/***/ }),

/***/ "./src/app/shared/services/vm.service.ts":
/*!***********************************************!*\
  !*** ./src/app/shared/services/vm.service.ts ***!
  \***********************************************/
/*! exports provided: VirtualMachineService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VirtualMachineService", function() { return VirtualMachineService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_add_observable_throw__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/add/observable/throw */ "./node_modules/rxjs-compat/_esm5/add/observable/throw.js");
/* harmony import */ var rxjs_add_operator_catch__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/add/operator/catch */ "./node_modules/rxjs-compat/_esm5/add/operator/catch.js");
/* harmony import */ var rxjs_add_operator_toPromise__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/toPromise */ "./node_modules/rxjs-compat/_esm5/add/operator/toPromise.js");
/* harmony import */ var rxjs_add_operator_toPromise__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(rxjs_add_operator_toPromise__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var rxjs_observable_of__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/observable/of */ "./node_modules/rxjs-compat/_esm5/observable/of.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
};
var VirtualMachineService = /** @class */ (function () {
    function VirtualMachineService(httpClient) {
        this.httpClient = httpClient;
        this.configUrl = 'admin/virtualMachine/template/';
    }
    VirtualMachineService.prototype.getVmList = function (baseUrl) {
        var src = baseUrl + this.configUrl;
        return this.httpClient.get(src);
    };
    VirtualMachineService.prototype.getVM = function (baseUrl, id) {
        var src = baseUrl + this.configUrl + id;
        return this.httpClient.get(src);
    };
    VirtualMachineService.prototype.createVM = function (baseUrl, vmData) {
        var url = baseUrl + this.configUrl;
        // console.log('createVM() => ');
        //     // console.log(vmData);
        return this.httpClient.post(url, vmData, httpOptions)
            .toPromise().then(function (data) {
            return data;
        }, function (error) {
            console.log(error);
        });
    };
    VirtualMachineService.prototype.updateVM = function (baseUrl, id, vmData) {
        var url = baseUrl + this.configUrl + id;
        return this.httpClient.put(url, vmData, httpOptions)
            .toPromise().then(function (data) {
            return data;
        }, function (error) {
            console.log(error);
        });
    };
    VirtualMachineService.prototype.toggleVmStatus = function (baseUrl, id) {
        var url = baseUrl + this.configUrl + id + '/toggle';
        return this.httpClient.get(url);
    };
    VirtualMachineService.prototype.updateVmStatus = function (baseUrl, id) {
        var url = baseUrl + this.configUrl + id;
        return this.httpClient.get(url);
    };
    VirtualMachineService.prototype.deleteVM = function (baseUrl, id) {
        var url = baseUrl + this.configUrl + id;
        return this.httpClient.delete(url)
            .toPromise().then(function (data) {
            return data;
        }, function (error) {
            console.log(error);
        });
    };
    /**
     * Handle Http operation that failed.
     * Let the app continue.
     * @ param operation - name of the operation that failed
     * @ param result - optional value to return as the observable result
     */
    VirtualMachineService.prototype.handleError = function (operation, result) {
        if (operation === void 0) { operation = 'operation'; }
        return function (error) {
            // TODO: send the error to remote logging infrastructure
            console.error(error.message); // log to console instead
            // TODO: better job of transforming error for user consumption
            // this.log(`${operation} failed: ${error.message}`);
            // Let the app keep running by returning an empty result.
            return Object(rxjs_observable_of__WEBPACK_IMPORTED_MODULE_5__["of"])(result);
        };
    };
    VirtualMachineService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], VirtualMachineService);
    return VirtualMachineService;
}());



/***/ }),

/***/ "./src/app/users/add-user/add-user.component.html":
/*!********************************************************!*\
  !*** ./src/app/users/add-user/add-user.component.html ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"content-container\">\n  <div id=\"content-header\">\n    <h2 class=\"title\">Add User Account</h2>\n  </div>\n  <div id=\"content-main\">\n    <div id=\"content\" class=\"content\">\n      <div class=\"mui-container-fluid\">\n        <div class=\"mui-row\">\n          <div class=\"mui-col-md-9\">\n            <div class=\"mui-row\">\n              <div class=\"mui-col-md-12 form-item\">\n                <mat-form-field>\n                  <input type=\"text\" #userName placeholder=\"User Name\" aria-label=\"Username\" matInput>\n                </mat-form-field>\n              </div>\n              <div class=\"mui-col-md-12 form-item\">\n                <div class=\"mui-col-md-6 table-data\">\n                  <label>Select Role(s)</label><br />\n                  <mat-checkbox #roleUser value=\"ROLE_USER\"> User</mat-checkbox> <br />\n                  <mat-checkbox #roleAdmin value=\"ROLE_ADMIN\"> Administrator</mat-checkbox>\n                </div>\n              </div>\n            </div>\n            <hr />\n            <div class=\"mui-row\">\n              <div class=\"titlebar margin-top-20\">\n                <br />\n                <h3 class=\"titlebar-title\">Virtues</h3>\n                <button class=\"titlebar-button\" mat-button (click)=\"activateModal(0,'add')\">Add Virtue</button>\n              </div>\n            </div>\n\n            <div class=\"mui-row\">\n              <div class=\"mui-container-fluid data-list\">\n                <div class=\"mui-row table-header-group\">\n                  <div class=\"table-header mui-col-md-4\">\n                    <div class=\"text-align-left margin-left-20 margin-right-0\">\n                      <span>Virtue Name</span>\n                    </div>\n                  </div>\n                  <div class=\"table-header mui-col-md-8\">\n                    Applications\n                  </div>\n                </div>\n                <!-- if there are no virtues, show this message -->\n                <div class=\"mui-row\">\n                  <div class=\"mui-col-md-12\">\n                    <p class=\"no-data-message\" *ngIf=\"selVirtues.length < 1\">\n                      No virtues have been added at this time. To add a virtue, click on the button \"Add Virtue\" above.\n                    </p>\n                  </div>\n                </div>\n                <div *ngIf=\"selVirtues.length > 0\">\n                  <div class=\"mui-row table-row\" *ngFor=\"let virtue of selVirtues; let i = index;\" appActiveClass>\n                    <div class=\"table-data mui-col-md-4\">\n                      <a class=\"edit\" (click)=\"activateModal(1,'edit')\">{{ getVirtueName(virtue) }}</a>\n                      <!-- This should show if hovered over -->\n                      <span class=\"menu-options\"><a (click)=\"removeVirtue(virtue, i)\">Remove</a></span>\n                    </div>\n                    <div class=\"table-data mui-col-md-8\">\n                      <ul [innerHTML]=\"getVirtueAppIds(virtue)\"></ul>\n                    </div>\n                    <div class=\"clearfix\"></div>\n                  </div>\n                </div>\n              </div>\n              <div class=\"paging mui-row\">\n                <div class=\"page-number mui-col-md-4\">Page # of #</div>\n                <div class=\"page-controls mui-col-md-4\"><< First | < Previous | Next > | Last >></div>\n                <div class=\"page-item-total mui-col-md-4\"># User Accounts</div>\n                <div class=\"clearfix\"></div>\n              </div>\n              <div class=\"mui-row\">\n                <hr />\n                <div class=\"mui-col-md-4\">&nbsp;</div>\n                <div class=\"mui-col-md-4 form-item text-align-center\">\n                  <span class=\"margin-right-10\"><input name=\"create-another\" type=\"checkbox\" value=\"1\" /> Add Another User</span>\n                  <button class=\"button-submit\" type=\"submit\" (click)=\"addUser(userName.value, roleUser.checked, roleAdmin.checked); userName.value=''; roleUser.checked = false; roleAdmin.checked = false;\" >Add User</button>\n                  <button class=\"button-cancel\" type=\"cancel\">Cancel</button>\n                </div>\n                <div class=\"mui-col-md-4\"></div>\n              </div>\n            </div>\n          </div>\n        </div>\n\n        <div class=\"mui-col-md-3\">&nbsp;</div>\n      </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/users/add-user/add-user.component.ts":
/*!******************************************************!*\
  !*** ./src/app/users/add-user/add-user.component.ts ***!
  \******************************************************/
/*! exports provided: AddUserComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddUserComponent", function() { return AddUserComponent; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/services/applications.service */ "./src/app/shared/services/applications.service.ts");
/* harmony import */ var _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/services/baseUrl.service */ "./src/app/shared/services/baseUrl.service.ts");
/* harmony import */ var _shared_services_users_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../shared/services/users.service */ "./src/app/shared/services/users.service.ts");
/* harmony import */ var _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../shared/services/virtues.service */ "./src/app/shared/services/virtues.service.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _virtue_modal_virtue_modal_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../virtue-modal/virtue-modal.component */ "./src/app/users/virtue-modal/virtue-modal.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









var AddUserComponent = /** @class */ (function () {
    function AddUserComponent(dialog, appsService, baseUrlService, router, usersService, virtuesService) {
        this.dialog = dialog;
        this.appsService = appsService;
        this.baseUrlService = baseUrlService;
        this.router = router;
        this.usersService = usersService;
        this.virtuesService = virtuesService;
        this.appsList = [];
        this.selVirtues = [];
        this.storedVirtues = [];
        this.virtues = [];
        this.adUserCtrl = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]();
        // override the route reuse strategy
        this.router.routeReuseStrategy.shouldReuseRoute = function () {
            return false;
        };
    }
    AddUserComponent.prototype.intercept = function (req, next) {
        console.log(req);
        return next.handle(req);
    };
    AddUserComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.baseUrlService.getBaseUrl().subscribe(function (data) {
            var url = data[0].aws_server;
            _this.getBaseUrl(url);
            _this.getVirtues(url);
            _this.getApps(url);
        });
    };
    AddUserComponent.prototype.resetRouter = function () {
        var _this = this;
        setTimeout(function () {
            _this.router.navigated = false;
        }, 500);
    };
    AddUserComponent.prototype.getBaseUrl = function (url) {
        this.awsServer = url;
    };
    AddUserComponent.prototype.addUser = function (username, roleUser, roleAdmin) {
        username = username.trim().replace(' ', '').toLowerCase();
        var authorities = [];
        var virtueTemplateIds = [];
        if (roleUser) {
            authorities.push('ROLE_USER');
        }
        if (roleAdmin) {
            authorities.push('ROLE_ADMIN');
        }
        for (var _i = 0, _a = this.selVirtues; _i < _a.length; _i++) {
            var item = _a[_i];
            virtueTemplateIds.push(item);
        }
        var body = {
            'username': username,
            'authorities': authorities,
            'virtueTemplateIds': virtueTemplateIds
        };
        if (!body.username) {
            return;
        }
        var baseUrl = this.awsServer;
        this.usersService.createUser(baseUrl, JSON.stringify(body)).subscribe(function (data) {
            return true;
        }, function (error) {
            console.error('Error');
        });
        this.assignUserVirtues(baseUrl, username, virtueTemplateIds);
        this.resetRouter();
        this.router.navigate(['/users']);
    };
    AddUserComponent.prototype.assignUserVirtues = function (baseUrl, username, virtues) {
        for (var _i = 0, virtues_1 = virtues; _i < virtues_1.length; _i++) {
            var item = virtues_1[_i];
            this.usersService.assignVirtues(baseUrl, username, item);
        }
    };
    AddUserComponent.prototype.getVirtues = function (baseUrl) {
        var _this = this;
        var selectedVirtue = this.storedVirtues;
        this.virtuesService.getVirtues(baseUrl)
            .subscribe(function (data) {
            if (_this.selVirtues.length < 1) {
                for (var _i = 0, data_1 = data; _i < data_1.length; _i++) {
                    var virtue = data_1[_i];
                    for (var _a = 0, selectedVirtue_1 = selectedVirtue; _a < selectedVirtue_1.length; _a++) {
                        var sel = selectedVirtue_1[_a];
                        if (sel === virtue.id) {
                            _this.selVirtues = data;
                            break;
                        }
                    }
                }
            }
            else {
                _this.getUpdatedVirtueList(baseUrl);
            }
        });
    };
    AddUserComponent.prototype.getApps = function (baseUrl) {
        var _this = this;
        if (baseUrl !== null) {
            this.appsService.getAppsList(baseUrl).subscribe(function (data) {
                _this.appsList = data;
            });
        }
    };
    AddUserComponent.prototype.getVirtueName = function (id) {
        var userVirtue = [];
        if (id !== null) {
            userVirtue = this.virtues.filter(function (data) { return data.id === id; })
                .map(function (virtue) { return virtue.name; });
            return userVirtue;
        }
    };
    AddUserComponent.prototype.getVirtueAppIds = function (id) {
        var virtueApps;
        var virtueAppsList;
        if (this.baseUrl !== null) {
            virtueApps = this.virtues.filter(function (data) { return data.id === id; })
                .map(function (virtue) { return virtue.applicationIds; });
            virtueAppsList = virtueApps.toString();
            // console.log(virtueAppsList);
            return this.getVirtueApps(virtueAppsList);
        }
    };
    AddUserComponent.prototype.getVirtueApps = function (apps) {
        var appList;
        var appInfo;
        var appNames = '';
        var i = 0;
        appList = apps.split(',');
        var _loop_1 = function (id) {
            i++;
            appInfo = this_1.appsList.filter(function (data) { return data.id === id; })
                .map(function (app) { return app.name; });
            // console.log(appInfo.toString());
            appNames = appNames + ("<li>" + appInfo.toString() + "</li>");
        };
        var this_1 = this;
        for (var _i = 0, appList_1 = appList; _i < appList_1.length; _i++) {
            var id = appList_1[_i];
            _loop_1(id);
        }
        return appNames;
    };
    AddUserComponent.prototype.getUpdatedVirtueList = function (baseUrl) {
        var _this = this;
        this.virtues = [];
        this.virtuesService.getVirtues(baseUrl)
            .subscribe(function (data) {
            for (var _i = 0, _a = _this.selVirtues; _i < _a.length; _i++) {
                var sel = _a[_i];
                for (var _b = 0, data_2 = data; _b < data_2.length; _b++) {
                    var virtue = data_2[_b];
                    if (sel === virtue.id) {
                        _this.virtues.push(virtue);
                        break;
                    }
                }
            }
        });
    };
    AddUserComponent.prototype.removeVirtue = function (id, index) {
        this.virtues = this.virtues.filter(function (data) {
            return data.id !== id;
        });
        this.storedVirtues.splice(index, 1);
    };
    AddUserComponent.prototype.activateModal = function (id, mode) {
        var _this = this;
        var dialogWidth = 900;
        var dialogHeight = 748;
        this.fullImagePath = './assets/images/app-icon-white.png';
        if (mode === 'add') {
            this.submitBtn = 'Add Virtues';
        }
        else {
            this.submitBtn = 'Update List';
        }
        var dialogRef = this.dialog.open(_virtue_modal_virtue_modal_component__WEBPACK_IMPORTED_MODULE_8__["VirtueModalComponent"], {
            height: dialogHeight + 'px',
            width: dialogWidth + 'px',
            data: {
                id: id,
                dialogMode: mode,
                dialogButton: this.submitBtn,
                appIcon: this.fullImagePath,
                storedVirtues: this.storedVirtues
            },
            panelClass: 'virtue-modal-overlay'
        });
        var leftPosition = ((window.screen.width) - dialogWidth) / 2;
        dialogRef.updatePosition({ top: '5%', left: leftPosition + 'px' });
        // dialogRef.afterClosed().subscribe();
        var virtueList = dialogRef.componentInstance.addVirtues.subscribe(function (data) {
            _this.selVirtues = data;
            console.log('Received selected virtues: ');
            console.log(_this.selVirtues);
            if (_this.storedVirtues.length > 0) {
                _this.storedVirtues = [];
            }
            _this.storedVirtues = _this.selVirtues;
            _this.getVirtues(_this.awsServer);
        });
    };
    AddUserComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-add-user',
            template: __webpack_require__(/*! ./add-user.component.html */ "./src/app/users/add-user/add-user.component.html"),
            providers: [_shared_services_applications_service__WEBPACK_IMPORTED_MODULE_3__["ApplicationsService"], _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_4__["BaseUrlService"], _shared_services_users_service__WEBPACK_IMPORTED_MODULE_5__["UsersService"], _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_6__["VirtuesService"]]
        }),
        __metadata("design:paramtypes", [_angular_material__WEBPACK_IMPORTED_MODULE_7__["MatDialog"],
            _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_3__["ApplicationsService"],
            _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_4__["BaseUrlService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_0__["Router"],
            _shared_services_users_service__WEBPACK_IMPORTED_MODULE_5__["UsersService"],
            _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_6__["VirtuesService"]])
    ], AddUserComponent);
    return AddUserComponent;
}());



/***/ }),

/***/ "./src/app/users/duplicate-user/duplicate-user.component.html":
/*!********************************************************************!*\
  !*** ./src/app/users/duplicate-user/duplicate-user.component.html ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"content-container\">\n  <div id=\"content-header\">\n    <h2 class=\"title\">Duplicate User Account</h2>\n  </div>\n  <div id=\"content-main\">\n    <div id=\"content\" class=\"content\">\n      <div class=\"mui-container-fluid\">\n        <div class=\"mui-row\">\n          <div class=\"mui-col-md-9\">\n            <div class=\"mui-row\">\n              <div class=\"mui-col-md-12 form-item\">\n                <mat-form-field>\n                  <input type=\"text\" #userName value=\"{{ 'Copy of ' + userData.username }}\" aria-label=\"Username\" matInput>\n                </mat-form-field>\n              </div>\n              <div class=\"mui-col-md-12 form-item\">\n                <div class=\"mui-col-md-6 table-data\">\n                  <label>Select Role(s)</label><br />\n                  <mat-checkbox #roleUser value=\"ROLE_USER\"\n                                [checked]=\"selectedRole('ROLE_USER')\"> User</mat-checkbox> <br />\n                  <mat-checkbox #roleAdmin value=\"ROLE_ADMIN\"\n                                [checked]=\"selectedRole('ROLE_ADMIN')\"> Administrator</mat-checkbox>\n                </div>\n              </div>\n            </div>\n            <hr />\n            <div class=\"mui-row\">\n              <div class=\"titlebar margin-top-20\">\n                <br />\n                <h3 class=\"titlebar-title\">Virtues</h3>\n                <button class=\"titlebar-button\" mat-button (click)=\"activateModal(0,'add')\">Add Virtue</button>\n              </div>\n            </div>\n\n            <div class=\"mui-row\">\n              <div class=\"mui-container-fluid data-list\">\n                <div class=\"mui-row table-header-group\">\n                  <div class=\"table-header mui-col-md-4\">\n                    <div class=\"text-align-left margin-left-20 margin-right-0\">\n                      <span>Virtue Name</span>\n                    </div>\n                  </div>\n                  <div class=\"table-header mui-col-md-8\">\n                    Applications\n                  </div>\n                </div>\n                <div class=\"mui-row table-row\" *ngIf=\"selVirtues.length < 1\">\n                  <div class=\"table-data mui-col-md-12\">\n                    <p class=\"no-data-message\">\n                      No virtues have been added at this time. To add a virtue, click on the button \"Add Virtue\" above.\n                    </p>\n                  </div>\n                </div>\n                <div *ngIf=\"selVirtues.length > 0\">\n                  <div class=\"mui-row table-row\" *ngFor=\"let virtue of selVirtues; let i = index;\" appActiveClass>\n                    <div class=\"table-data mui-col-md-4\">\n                        <a class=\"edit\" (click)=\"activateModal(1,'edit')\">{{ getVirtueName(virtue) }}</a>\n                        <!-- This should show if hovered over -->\n                        <span class=\"menu-options\"><a (click)=\"removeVirtue(virtue, i)\">Remove</a></span>\n                    </div>\n                    <div class=\"table-data mui-col-md-8\">\n                      <ul [innerHTML]=\"getVirtueAppIds(virtue)\">\n                      </ul>\n                    </div>\n                    <div class=\"clearfix\"></div>\n                  </div>\n                </div>\n              </div>\n            </div>\n            <div class=\"mui-row paging\">\n              <div class=\"page-number mui-col-md-4\">Page # of #</div>\n              <div class=\"page-controls mui-col-md-4\"><< First | < Previous | Next > | Last >></div>\n              <div class=\"page-item-total mui-col-md-4\"># User Accounts</div>\n              <div class=\"clearfix\"></div>\n            </div>\n\n            <div class=\"mui-row\">\n              <hr />\n              <div class=\"mui-col-md-4\">&nbsp;</div>\n              <div class=\"mui-col-md-4 form-item text-align-center\">\n                <button class=\"button-submit\" type=\"submit\" (click)=\"addUser(userName.value, roleUser.checked, roleAdmin.checked);\" >Save</button>\n                <button class=\"button-cancel\" type=\"cancel\">Cancel</button>\n              </div>\n              <div class=\"mui-col-md-4\"></div>\n            </div>\n          </div>\n        </div>\n      </div>\n      <div class=\"mui-col-md-3\">&nbsp;</div>\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/users/duplicate-user/duplicate-user.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/users/duplicate-user/duplicate-user.component.ts ***!
  \******************************************************************/
/*! exports provided: DuplicateUserComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DuplicateUserComponent", function() { return DuplicateUserComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _shared_models_user_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../shared/models/user.model */ "./src/app/shared/models/user.model.ts");
/* harmony import */ var _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/services/applications.service */ "./src/app/shared/services/applications.service.ts");
/* harmony import */ var _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/services/baseUrl.service */ "./src/app/shared/services/baseUrl.service.ts");
/* harmony import */ var _shared_services_users_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../shared/services/users.service */ "./src/app/shared/services/users.service.ts");
/* harmony import */ var _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../shared/services/virtues.service */ "./src/app/shared/services/virtues.service.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _virtue_modal_virtue_modal_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../virtue-modal/virtue-modal.component */ "./src/app/users/virtue-modal/virtue-modal.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









var DuplicateUserComponent = /** @class */ (function () {
    function DuplicateUserComponent(activatedRoute, router, appsService, baseUrlService, usersService, virtuesService, dialog) {
        this.activatedRoute = activatedRoute;
        this.router = router;
        this.appsService = appsService;
        this.baseUrlService = baseUrlService;
        this.usersService = usersService;
        this.virtuesService = virtuesService;
        this.dialog = dialog;
        this.userRoles = [];
        this.userData = [];
        this.storedVirtues = [];
        this.selVirtues = [];
        this.virtues = [];
        this.appsList = [];
    }
    DuplicateUserComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.userToEdit = {
            id: this.activatedRoute.snapshot.params['id']
        };
        this.baseUrlService.getBaseUrl().subscribe(function (data) {
            var url = data[0].aws_server;
            _this.getBaseUrl(url);
            _this.getUserToEdit(url, _this.userToEdit.id);
            _this.getVirtues(url);
            _this.getApps(url);
        });
    };
    DuplicateUserComponent.prototype.resetRouter = function () {
        var _this = this;
        setTimeout(function () {
            _this.router.navigated = false;
        }, 1000);
    };
    DuplicateUserComponent.prototype.getBaseUrl = function (url) {
        this.baseUrl = url;
    };
    DuplicateUserComponent.prototype.getUserToEdit = function (baseUrl, username) {
        var _this = this;
        this.usersService.getUser(baseUrl, username).subscribe(function (data) {
            _this.userData = data;
            _this.userRoles = data.authorities;
            _this.selVirtues = data.virtueTemplateIds;
            _this.storedVirtues = data.virtueTemplateIds;
        });
    };
    DuplicateUserComponent.prototype.selectedRole = function (role) {
        if (this.userRoles.length > 0) {
            for (var _i = 0, _a = this.userRoles; _i < _a.length; _i++) {
                var sel = _a[_i];
                if (sel === role) {
                    return true;
                }
            }
        }
        else {
            return false;
        }
    };
    DuplicateUserComponent.prototype.getVirtues = function (baseUrl) {
        var _this = this;
        if (baseUrl !== null) {
            this.virtuesService.getVirtues(baseUrl).subscribe(function (data) {
                _this.virtues = data;
            });
        }
    };
    DuplicateUserComponent.prototype.getApps = function (baseUrl) {
        var _this = this;
        if (baseUrl !== null) {
            this.appsService.getAppsList(baseUrl).subscribe(function (data) {
                _this.appsList = data;
            });
        }
    };
    DuplicateUserComponent.prototype.getVirtueName = function (id) {
        var userVirtue = [];
        if (id !== null) {
            userVirtue = this.virtues.filter(function (data) { return data.id === id; })
                .map(function (virtue) { return virtue.name; });
            return userVirtue;
        }
    };
    DuplicateUserComponent.prototype.getVirtueAppIds = function (id) {
        var virtueApps;
        var virtueAppsList;
        if (this.baseUrl !== null) {
            virtueApps = this.virtues.filter(function (data) { return data.id === id; })
                .map(function (virtue) { return virtue.applicationIds; });
            virtueAppsList = virtueApps.toString();
            // console.log(virtueAppsList);
            return this.getVirtueApps(virtueAppsList);
        }
    };
    DuplicateUserComponent.prototype.getVirtueApps = function (apps) {
        var appList;
        var appInfo;
        var appNames = '';
        var i = 0;
        appList = apps.split(',');
        var _loop_1 = function (id) {
            i++;
            appInfo = this_1.appsList.filter(function (data) { return data.id === id; })
                .map(function (app) { return app.name; });
            appNames = appNames + ("<li>" + appInfo.toString() + "</li>");
        };
        var this_1 = this;
        for (var _i = 0, appList_1 = appList; _i < appList_1.length; _i++) {
            var id = appList_1[_i];
            _loop_1(id);
        }
        return appNames;
    };
    DuplicateUserComponent.prototype.getUpdatedVirtueList = function (virtues) {
        var _this = this;
        this.virtues = [];
        this.virtuesService.getVirtues(this.baseUrl)
            .subscribe(function (data) {
            for (var _i = 0, _a = _this.selVirtues; _i < _a.length; _i++) {
                var sel = _a[_i];
                for (var _b = 0, data_1 = data; _b < data_1.length; _b++) {
                    var virtue = data_1[_b];
                    if (sel === virtue.id) {
                        _this.virtues.push(virtue);
                        break;
                    }
                }
            }
        });
    };
    DuplicateUserComponent.prototype.removeVirtue = function (id, index) {
        this.virtues = this.virtues.filter(function (data) {
            return data.id !== id;
        });
        this.selVirtues.splice(index, 1);
    };
    DuplicateUserComponent.prototype.addUser = function (username, roleUser, roleAdmin) {
        username = username.trim().replace(' ', '').toLowerCase();
        var authorities = [];
        var virtueTemplateIds = [];
        if (roleUser) {
            authorities.push('ROLE_USER');
        }
        if (roleAdmin) {
            authorities.push('ROLE_ADMIN');
        }
        for (var _i = 0, _a = this.selVirtues; _i < _a.length; _i++) {
            var item = _a[_i];
            virtueTemplateIds.push(item);
        }
        var body = {
            'username': username,
            'authorities': authorities,
            'virtueTemplateIds': virtueTemplateIds
        };
        if (!body.username) {
            return;
        }
        this.usersService.createUser(this.baseUrl, JSON.stringify(body)).subscribe(function (success) {
            console.log(success);
        }, function (err) {
            console.log(err);
        });
        this.resetRouter();
        this.router.navigate(['/users']);
    };
    DuplicateUserComponent.prototype.activateModal = function (id, mode) {
        var _this = this;
        var dialogHeight = 600;
        var dialogWidth = 800;
        // let fullImagePath = './assets/images/app-icon-white.png';
        if (mode === 'add') {
            this.submitBtn = 'Add Virtues';
        }
        else {
            this.submitBtn = 'Update List';
        }
        var dialogRef = this.dialog.open(_virtue_modal_virtue_modal_component__WEBPACK_IMPORTED_MODULE_8__["VirtueModalComponent"], {
            height: dialogHeight + 'px',
            width: dialogWidth + 'px',
            data: {
                id: id,
                dialogMode: mode,
                dialogButton: this.submitBtn,
                appIcon: this.fullImagePath,
                storedVirtues: this.selVirtues
            },
            panelClass: 'virtue-modal-overlay'
        });
        var virtueList = dialogRef.componentInstance.addVirtues.subscribe(function (data) {
            _this.selVirtues = data;
            if (_this.storedVirtues.length > 0) {
                _this.storedVirtues = [];
            }
            _this.storedVirtues = _this.selVirtues;
            _this.getUpdatedVirtueList(_this.storedVirtues);
        });
        var leftPosition = ((window.screen.width) - dialogWidth) / 2;
        dialogRef.updatePosition({ top: '5%', left: leftPosition + 'px' });
        // dialogRef.afterClosed().subscribe();
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", _shared_models_user_model__WEBPACK_IMPORTED_MODULE_2__["User"])
    ], DuplicateUserComponent.prototype, "user", void 0);
    DuplicateUserComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-duplicate-user',
            template: __webpack_require__(/*! ./duplicate-user.component.html */ "./src/app/users/duplicate-user/duplicate-user.component.html"),
            providers: [_shared_services_applications_service__WEBPACK_IMPORTED_MODULE_3__["ApplicationsService"], _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_4__["BaseUrlService"], _shared_services_users_service__WEBPACK_IMPORTED_MODULE_5__["UsersService"], _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_6__["VirtuesService"]]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_3__["ApplicationsService"],
            _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_4__["BaseUrlService"],
            _shared_services_users_service__WEBPACK_IMPORTED_MODULE_5__["UsersService"],
            _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_6__["VirtuesService"],
            _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatDialog"]])
    ], DuplicateUserComponent);
    return DuplicateUserComponent;
}());



/***/ }),

/***/ "./src/app/users/edit-user/edit-user.component.html":
/*!**********************************************************!*\
  !*** ./src/app/users/edit-user/edit-user.component.html ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"content-container\">\n  <div id=\"content-header\">\n    <h2 class=\"title\">Edit User Account</h2>\n  </div>\n  <div id=\"content-main\">\n    <div id=\"content\" class=\"content\">\n      <div class=\"mui-container-fluid\">\n        <div class=\"mui-row\">\n          <div class=\"mui-col-md-9\">\n            <div class=\"mui-row\">\n              <div class=\"mui-col-md-12 form-item\">\n                <mat-form-field>\n                  <input type=\"text\" #userName value=\"{{ userData.username }}\" aria-label=\"Username\" matInput>\n                </mat-form-field>\n              </div>\n              <div class=\"mui-col-md-12 form-item\">\n                <div class=\"mui-col-md-6 table-data\">\n                  <label>Select Role(s)</label><br />\n                  <mat-checkbox #roleUser value=\"ROLE_USER\"\n                                [checked]=\"selectedRole('ROLE_USER')\"> User</mat-checkbox> <br />\n                  <mat-checkbox #roleAdmin value=\"ROLE_ADMIN\"\n                                [checked]=\"selectedRole('ROLE_ADMIN')\"> Administrator</mat-checkbox>\n                </div>\n              </div>\n            </div>\n            <hr />\n            <div class=\"mui-row\">\n              <div class=\"titlebar margin-top-20\">\n                <br />\n                <h3 class=\"titlebar-title\">Virtues</h3>\n                <button class=\"titlebar-button\" mat-button (click)=\"activateModal(0,'add')\">Add Virtue</button>\n              </div>\n            </div>\n\n            <div class=\"mui-row\">\n              <div class=\"mui-container-fluid data-list\">\n                <div class=\"mui-row table-header-group\">\n                  <div class=\"table-header mui-col-md-4\">\n                    <div class=\"text-align-left margin-left-20 margin-right-0\">\n                      <span>Virtue Name</span>\n                    </div>\n                  </div>\n                  <div class=\"table-header mui-col-md-8\">\n                    Applications\n                  </div>\n                </div>\n                <div class=\"mui-row table-row\" *ngIf=\"selVirtues.length < 1\">\n                  <div class=\"table-data mui-col-md-12\">\n                    <p class=\"no-data-message\">\n                      No virtues have been added at this time. To add a virtue, click on the button \"Add Virtue\" above.\n                    </p>\n                  </div>\n                </div>\n                <div *ngIf=\"selVirtues.length > 0\">\n                  <div class=\"mui-row table-row\" *ngFor=\"let virtue of selVirtues; let i = index;\" appActiveClass>\n                    <div class=\"table-data mui-col-md-4\">\n                        <a class=\"edit\" (click)=\"activateModal(1,'edit')\">{{ getVirtueName(virtue) }}</a>\n                        <!-- This should show if hovered over -->\n                        <span class=\"menu-options\"><a (click)=\"removeVirtue(virtue, i)\">Remove</a></span>\n                    </div>\n                    <div class=\"table-data mui-col-md-8\">\n                      <ul [innerHTML]=\"getVirtueAppIds(virtue)\">\n                      </ul>\n                    </div>\n                    <div class=\"clearfix\"></div>\n                  </div>\n                </div>\n              </div>\n            </div>\n            <div class=\"mui-row paging\">\n              <div class=\"page-number mui-col-md-4\">Page # of #</div>\n              <div class=\"page-controls mui-col-md-4\"><< First | < Previous | Next > | Last >></div>\n              <div class=\"page-item-total mui-col-md-4\"># User Accounts</div>\n              <div class=\"clearfix\"></div>\n            </div>\n\n            <div class=\"mui-row\">\n              <hr />\n              <div class=\"mui-col-md-4\">&nbsp;</div>\n              <div class=\"mui-col-md-4 form-item text-align-center\">\n                <button class=\"button-submit\" type=\"submit\" (click)=\"updateThisUser(userName.value, roleUser.checked, roleAdmin.checked);\" >Save</button>\n                <button class=\"button-cancel\" type=\"cancel\">Cancel</button>\n              </div>\n              <div class=\"mui-col-md-4\"></div>\n            </div>\n          </div>\n        </div>\n      </div>\n      <div class=\"mui-col-md-3\">&nbsp;</div>\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/users/edit-user/edit-user.component.ts":
/*!********************************************************!*\
  !*** ./src/app/users/edit-user/edit-user.component.ts ***!
  \********************************************************/
/*! exports provided: EditUserComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditUserComponent", function() { return EditUserComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _shared_models_user_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../shared/models/user.model */ "./src/app/shared/models/user.model.ts");
/* harmony import */ var _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/services/applications.service */ "./src/app/shared/services/applications.service.ts");
/* harmony import */ var _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/services/baseUrl.service */ "./src/app/shared/services/baseUrl.service.ts");
/* harmony import */ var _shared_services_users_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../shared/services/users.service */ "./src/app/shared/services/users.service.ts");
/* harmony import */ var _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../shared/services/virtues.service */ "./src/app/shared/services/virtues.service.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _virtue_modal_virtue_modal_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../virtue-modal/virtue-modal.component */ "./src/app/users/virtue-modal/virtue-modal.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









var EditUserComponent = /** @class */ (function () {
    function EditUserComponent(activatedRoute, router, appsService, baseUrlService, usersService, virtuesService, dialog) {
        this.activatedRoute = activatedRoute;
        this.router = router;
        this.appsService = appsService;
        this.baseUrlService = baseUrlService;
        this.usersService = usersService;
        this.virtuesService = virtuesService;
        this.dialog = dialog;
        this.userRoles = [];
        this.userData = [];
        this.storedVirtues = [];
        this.selVirtues = [];
        this.virtues = [];
        this.appsList = [];
    }
    EditUserComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.userToEdit = {
            id: this.activatedRoute.snapshot.params['id']
        };
        this.baseUrlService.getBaseUrl().subscribe(function (data) {
            var url = data[0].aws_server;
            _this.getBaseUrl(url);
            _this.getUserToEdit(url, _this.userToEdit.id);
            _this.getVirtues(url);
            _this.getApps(url);
        });
    };
    EditUserComponent.prototype.resetRouter = function () {
        var _this = this;
        setTimeout(function () {
            _this.router.navigated = false;
        }, 1000);
    };
    EditUserComponent.prototype.getBaseUrl = function (url) {
        this.baseUrl = url;
    };
    EditUserComponent.prototype.getUserToEdit = function (baseUrl, username) {
        var _this = this;
        this.usersService.getUser(baseUrl, username).subscribe(function (data) {
            _this.userData = data;
            _this.userRoles = data.authorities;
            _this.selVirtues = data.virtueTemplateIds;
            _this.storedVirtues = data.virtueTemplateIds;
        });
    };
    EditUserComponent.prototype.selectedRole = function (role) {
        if (this.userRoles.length > 0) {
            for (var _i = 0, _a = this.userRoles; _i < _a.length; _i++) {
                var sel = _a[_i];
                if (sel === role) {
                    return true;
                }
            }
        }
        else {
            return false;
        }
    };
    EditUserComponent.prototype.getVirtues = function (baseUrl) {
        var _this = this;
        if (baseUrl !== null) {
            this.virtuesService.getVirtues(baseUrl).subscribe(function (data) {
                _this.virtues = data;
            });
        }
    };
    EditUserComponent.prototype.getApps = function (baseUrl) {
        var _this = this;
        if (baseUrl !== null) {
            this.appsService.getAppsList(baseUrl).subscribe(function (data) {
                _this.appsList = data;
            });
        }
    };
    EditUserComponent.prototype.getVirtueName = function (id) {
        var userVirtue = [];
        if (id !== null) {
            userVirtue = this.virtues.filter(function (data) { return data.id === id; })
                .map(function (virtue) { return virtue.name; });
            return userVirtue;
        }
    };
    EditUserComponent.prototype.getVirtueAppIds = function (id) {
        var virtueApps;
        var virtueAppsList;
        if (this.baseUrl !== null) {
            virtueApps = this.virtues.filter(function (data) { return data.id === id; })
                .map(function (virtue) { return virtue.applicationIds; });
            virtueAppsList = virtueApps.toString();
            // console.log(virtueAppsList);
            return this.getVirtueApps(virtueAppsList);
        }
    };
    EditUserComponent.prototype.getVirtueApps = function (apps) {
        var appList;
        var appInfo;
        var appNames = '';
        var i = 0;
        appList = apps.split(',');
        var _loop_1 = function (id) {
            i++;
            appInfo = this_1.appsList.filter(function (data) { return data.id === id; })
                .map(function (app) { return app.name; });
            // console.log(appInfo.toString());
            appNames = appNames + ("<li>" + appInfo.toString() + "</li>");
        };
        var this_1 = this;
        for (var _i = 0, appList_1 = appList; _i < appList_1.length; _i++) {
            var id = appList_1[_i];
            _loop_1(id);
        }
        return appNames;
    };
    EditUserComponent.prototype.getUpdatedVirtueList = function (virtues) {
        var _this = this;
        this.virtues = [];
        this.virtuesService.getVirtues(this.baseUrl)
            .subscribe(function (data) {
            for (var _i = 0, _a = _this.selVirtues; _i < _a.length; _i++) {
                var sel = _a[_i];
                for (var _b = 0, data_1 = data; _b < data_1.length; _b++) {
                    var virtue = data_1[_b];
                    if (sel === virtue.id) {
                        _this.virtues.push(virtue);
                        break;
                    }
                }
            }
        });
    };
    EditUserComponent.prototype.removeVirtue = function (id, index) {
        this.virtues = this.virtues.filter(function (data) {
            return data.id !== id;
        });
        this.selVirtues.splice(index, 1);
    };
    EditUserComponent.prototype.activateModal = function (id, mode) {
        var _this = this;
        var dialogHeight = 600;
        var dialogWidth = 800;
        // let fullImagePath = './assets/images/app-icon-white.png';
        if (mode === 'add') {
            this.submitBtn = 'Add Virtues';
        }
        else {
            this.submitBtn = 'Update List';
        }
        var dialogRef = this.dialog.open(_virtue_modal_virtue_modal_component__WEBPACK_IMPORTED_MODULE_8__["VirtueModalComponent"], {
            height: dialogHeight + 'px',
            width: dialogWidth + 'px',
            data: {
                id: id,
                dialogMode: mode,
                dialogButton: this.submitBtn,
                appIcon: this.fullImagePath,
                storedVirtues: this.selVirtues
            },
            panelClass: 'virtue-modal-overlay'
        });
        var virtueList = dialogRef.componentInstance.addVirtues.subscribe(function (data) {
            _this.selVirtues = data;
            if (_this.storedVirtues.length > 0) {
                _this.storedVirtues = [];
            }
            _this.storedVirtues = _this.selVirtues;
            _this.getUpdatedVirtueList(_this.storedVirtues);
        });
        var leftPosition = ((window.screen.width) - dialogWidth) / 2;
        dialogRef.updatePosition({ top: '5%', left: leftPosition + 'px' });
        // dialogRef.afterClosed().subscribe();
    };
    EditUserComponent.prototype.updateThisUser = function (username, roleUser, roleAdmin) {
        var authorities = [];
        if (roleUser) {
            authorities.push('ROLE_USER');
        }
        if (roleAdmin) {
            authorities.push('ROLE_ADMIN');
        }
        var body = {
            'username': username,
            'authorities': authorities,
            'virtueTemplateIds': this.selVirtues
        };
        console.log(body);
        this.usersService.updateUser(this.baseUrl, username, JSON.stringify(body)).subscribe(function (error) {
            console.log(error);
        });
        this.resetRouter();
        this.router.navigate(['/users']);
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", _shared_models_user_model__WEBPACK_IMPORTED_MODULE_2__["User"])
    ], EditUserComponent.prototype, "user", void 0);
    EditUserComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-edit-user',
            template: __webpack_require__(/*! ./edit-user.component.html */ "./src/app/users/edit-user/edit-user.component.html"),
            providers: [_shared_services_applications_service__WEBPACK_IMPORTED_MODULE_3__["ApplicationsService"], _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_4__["BaseUrlService"], _shared_services_users_service__WEBPACK_IMPORTED_MODULE_5__["UsersService"], _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_6__["VirtuesService"]]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_3__["ApplicationsService"],
            _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_4__["BaseUrlService"],
            _shared_services_users_service__WEBPACK_IMPORTED_MODULE_5__["UsersService"],
            _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_6__["VirtuesService"],
            _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatDialog"]])
    ], EditUserComponent);
    return EditUserComponent;
}());



/***/ }),

/***/ "./src/app/users/user-list/user-list.component.css":
/*!*********************************************************!*\
  !*** ./src/app/users/user-list/user-list.component.css ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".account-filter {\n  padding: 0 0 0.75rem;\n}\n\n.account-options {\n  display: block;\n  font-family: 'Raleway-medium', Arial, sans-serif;\n  font-size: 0.88rem;\n  clear: both;\n}\n\n.account-message {\n  display: block;\n  border-top: 1px solid #b2b2b2;\n  border-bottom: 1px solid #b2b2b2;\n}\n"

/***/ }),

/***/ "./src/app/users/user-list/user-list.component.html":
/*!**********************************************************!*\
  !*** ./src/app/users/user-list/user-list.component.html ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"content-container\">\n  <div id=\"content-header\" class=\"titlebar\">\n    <h1 class=\"titlebar-title\">Users</h1>\n    <button class=\"titlebar-button\" routerLink=\"/users/add\">Add User</button>\n  </div>\n\n  <div id=\"content-main\">\n    <div id=\"content\">\n      <div class=\"mui-container-fluid\">\n        <!-- if there are no virtues, show this message -->\n        <div *ngIf=\"users.length < 1\" class=\"mui-row margin-top-10\">\n          <div class=\"mui-col-md-12 padding-left-0\">\n            <p class=\"no-data-message\">\n              No users have been added at this time. To add a user, click on the button \"Add User\" above.\n            </p>\n          </div>\n        </div>\n      </div>\n      <!-- if there are virtues, show this list -->\n      <div class=\"mui-container-fluid\">\n        <div class=\"mui-row virtues-filters\">\n          <div class=\"virtues-filter mui-col-md-12 padding-left-0\">All User Accounts | <a href=\"#\">Active Accounts</a> | <a>Disabled Accounts</a></div>\n        </div>\n      </div>\n      <div class=\"mui-container-fluid data-list\">\n        <div class=\"mui-row table-header-group\">\n          <div class=\"table-header mui-col-md-2\">Userame</div>\n          <div class=\"table-header mui-col-md-3\">Authorities</div>\n          <div class=\"table-header mui-col-md-7\">Virtues</div>\n        </div>\n\n        <div class=\"mui-row table-row\" *ngFor=\"let su of users\" appActiveClass>\n          <div class=\"table-data mui-col-md-2\">\n            <a class=\"edit\" routerLink=\"/users/edit/{{su.username}}\">{{ su.username }}</a>\n\n            <!-- if this user is enabled show this menu -->\n            <span class=\"menu-options\">\n              <a routerLink=\"/users/duplicate/{{su.username}}\">Duplicate</a> | <a class=\"edit\" (click)=\"deleteUser(su.username)\">Delete</a>\n            </span>\n          </div>\n          <div class=\"table-data mui-col-md-3\">{{ su.authorities }}\n          </div>\n          <div class=\"table-data mui-col-md-7\">\n            <ul>\n              <li *ngFor=\"let virtue of su.virtueTemplateIds\">{{ getVirtueName(virtue) }}</li>\n            </ul>\n          </div>\n          <div class=\"clearfix\"></div>\n        </div>\n      </div>\n      <div class=\"paging\">\n        <div class=\"page-number mui-col-md-4\">Page # of #</div>\n        <div class=\"page-controls mui-col-md-4\">\n          << First | < Previous | Next> | Last >></div>\n        <div class=\"page-item-total mui-col-md-4\"># User Accounts</div>\n        <div class=\"clearfix\"></div>\n      </div>\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/users/user-list/user-list.component.ts":
/*!********************************************************!*\
  !*** ./src/app/users/user-list/user-list.component.ts ***!
  \********************************************************/
/*! exports provided: UserListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserListComponent", function() { return UserListComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/services/baseUrl.service */ "./src/app/shared/services/baseUrl.service.ts");
/* harmony import */ var _shared_services_users_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/services/users.service */ "./src/app/shared/services/users.service.ts");
/* harmony import */ var _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../shared/services/virtues.service */ "./src/app/shared/services/virtues.service.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _dialogs_dialogs_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../dialogs/dialogs.component */ "./src/app/dialogs/dialogs.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



// import { User } from '../../shared/models/user.model';





var UserListComponent = /** @class */ (function () {
    function UserListComponent(router, location, baseUrlService, usersService, virtuesService, dialog) {
        this.router = router;
        this.location = location;
        this.baseUrlService = baseUrlService;
        this.usersService = usersService;
        this.virtuesService = virtuesService;
        this.dialog = dialog;
        this.users = [];
        this.virtues = [];
        // override the route reuse strategy
        this.router.routeReuseStrategy.shouldReuseRoute = function () {
            return false;
        };
    }
    UserListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.baseUrlService.getBaseUrl().subscribe(function (_url) {
            var awsServer = _url[0].aws_server;
            _this.getBaseUrl(awsServer);
            _this.getUsers(awsServer);
            _this.getVirtues(awsServer);
        });
        this.refreshData();
    };
    UserListComponent.prototype.getBaseUrl = function (url) {
        this.baseUrl = url;
    };
    UserListComponent.prototype.refreshData = function () {
        var _this = this;
        setTimeout(function () {
            _this.router.navigated = false;
            _this.getUsers(_this.baseUrl);
        }, 1000);
    };
    UserListComponent.prototype.getUsers = function (baseUrl) {
        var _this = this;
        this.usersService.getUsers(baseUrl).subscribe(function (data) {
            _this.users = data;
        });
    };
    UserListComponent.prototype.deleteUser = function (username) {
        // console.log(username);
        this.usersService.deleteUser(this.baseUrl, username);
        this.refreshData();
    };
    UserListComponent.prototype.getVirtues = function (baseUrl) {
        var _this = this;
        this.virtuesService.getVirtues(baseUrl).subscribe(function (virtues) {
            _this.virtues = virtues;
        });
    };
    UserListComponent.prototype.getVirtueName = function (id) {
        for (var _i = 0, _a = this.virtues; _i < _a.length; _i++) {
            var virtue = _a[_i];
            if (id === virtue.id) {
                return virtue.name;
            }
        }
    };
    UserListComponent.prototype.openDialog = function (id, type, text) {
        var dialogRef = this.dialog.open(_dialogs_dialogs_component__WEBPACK_IMPORTED_MODULE_7__["DialogsComponent"], {
            width: '450px',
            data: {
                dialogText: text,
                dialogType: type
            }
        });
        dialogRef.updatePosition({ top: '15%', left: '36%' });
        dialogRef.afterClosed().subscribe(function (result) {
            console.log('The dialog to delete {{data.dialogText}} was closed');
        });
    };
    UserListComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-user-list',
            template: __webpack_require__(/*! ./user-list.component.html */ "./src/app/users/user-list/user-list.component.html"),
            styles: [__webpack_require__(/*! ./user-list.component.css */ "./src/app/users/user-list/user-list.component.css")],
            providers: [_shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_3__["BaseUrlService"], _shared_services_users_service__WEBPACK_IMPORTED_MODULE_4__["UsersService"]]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["Location"],
            _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_3__["BaseUrlService"],
            _shared_services_users_service__WEBPACK_IMPORTED_MODULE_4__["UsersService"],
            _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_5__["VirtuesService"],
            _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatDialog"]])
    ], UserListComponent);
    return UserListComponent;
}());



/***/ }),

/***/ "./src/app/users/users.component.html":
/*!********************************************!*\
  !*** ./src/app/users/users.component.html ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<router-outlet></router-outlet>\n"

/***/ }),

/***/ "./src/app/users/users.component.ts":
/*!******************************************!*\
  !*** ./src/app/users/users.component.ts ***!
  \******************************************/
/*! exports provided: UsersComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsersComponent", function() { return UsersComponent; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var UsersComponent = /** @class */ (function () {
    function UsersComponent(location) {
        this.location = location;
    }
    UsersComponent.prototype.ngOnInit = function () { };
    UsersComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-users',
            template: __webpack_require__(/*! ./users.component.html */ "./src/app/users/users.component.html"),
            providers: [
                _angular_common__WEBPACK_IMPORTED_MODULE_0__["Location"],
                { provide: _angular_common__WEBPACK_IMPORTED_MODULE_0__["LocationStrategy"], useClass: _angular_common__WEBPACK_IMPORTED_MODULE_0__["HashLocationStrategy"] }
            ]
        }),
        __metadata("design:paramtypes", [_angular_common__WEBPACK_IMPORTED_MODULE_0__["Location"]])
    ], UsersComponent);
    return UsersComponent;
}());



/***/ }),

/***/ "./src/app/users/virtue-modal/virtue-modal.component.html":
/*!****************************************************************!*\
  !*** ./src/app/users/virtue-modal/virtue-modal.component.html ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<form name=\"virtueList\">\n<h2 mat-dialog-title>{{data.dialogMode}} Virtues</h2>\n<div mat-dialog-content>\n  <p>Select virtues to attach to user role.</p>\n  <div class=\"mui-container-fluid mui-col-md-12 table-container\">\n    <div class=\"mui-row table-header-group\">\n      <div class=\"mui-col-md-2 table-header\">\n        <span class=\"float-left\">\n          <mat-checkbox\n          name=\"selectAll\"\n          (change)=\"selectAll($event.checked)\"\n          [disabled]=\"disabled\"></mat-checkbox>\n        </span>\n      </div>\n      <div class=\"table-header mui-col-md-3\">Virtue</div>\n      <div class=\"table-header mui-col-md-7\">Applications</div>\n    </div>\n    <div class=\"mui-row table-row\" *ngFor=\"let virtue of virtues\">\n      <div class=\"mui-col-md-2 table-data\">\n        <span class=\"float-left\">\n          <mat-checkbox\n            name=\"cbVirtue\"\n            [checked]=\"selectedVirtues(virtue.id)\"\n            (change)=\"cbVirtueList($event.checked, virtue.id, i)\"\n            value=\"{{virtue.id}}\" ></mat-checkbox>\n        </span>\n      </div>\n      <div class=\"table-data mui-col-md-3\">{{ virtue.name }}</div>\n      <div class=\"table-data mui-col-md-7\">\n        <ul>\n          <li *ngFor=\"let app of virtue.applicationIds\">{{ getAppName(app) }}</li>\n        </ul>\n      </div>\n    </div>\n  </div>\n</div>\n\n<div mat-dialog-actions>\n  <button mat-button type=\"submit\" (click)=\"onAddVirtues();\">\n  {{data.dialogButton}}\n  </button>\n  <button mat-button type=\"button\" mat-dialog-close (click)=\"cancelModal();\">\n    Cancel\n  </button>\n</div>\n</form>\n"

/***/ }),

/***/ "./src/app/users/virtue-modal/virtue-modal.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/users/virtue-modal/virtue-modal.component.ts ***!
  \**************************************************************/
/*! exports provided: VirtueModalComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VirtueModalComponent", function() { return VirtueModalComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _shared_models_virtue_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../shared/models/virtue.model */ "./src/app/shared/models/virtue.model.ts");
/* harmony import */ var _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../shared/services/applications.service */ "./src/app/shared/services/applications.service.ts");
/* harmony import */ var _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/services/baseUrl.service */ "./src/app/shared/services/baseUrl.service.ts");
/* harmony import */ var _shared_services_users_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/services/users.service */ "./src/app/shared/services/users.service.ts");
/* harmony import */ var _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../shared/services/virtues.service */ "./src/app/shared/services/virtues.service.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};







var VirtueModalComponent = /** @class */ (function () {
    function VirtueModalComponent(appService, baseUrlService, usersService, virtuesService, dialogRef, data) {
        this.appService = appService;
        this.baseUrlService = baseUrlService;
        this.usersService = usersService;
        this.virtuesService = virtuesService;
        this.dialogRef = dialogRef;
        this.data = data;
        this.addVirtues = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.appsList = [];
        this.virtues = [];
        this.selVirtues = [];
        this.storedVirtues = [];
        this.storedVirtues = data['storedVirtues'];
    }
    VirtueModalComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.baseUrlService.getBaseUrl().subscribe(function (res) {
            var awsServer = res[0].aws_server;
            _this.getBaseUrl(awsServer);
            _this.getVirtues(awsServer);
            _this.getApps(awsServer);
        });
        if (this.storedVirtues.length > 0) {
            this.selVirtues = this.storedVirtues;
        }
    };
    VirtueModalComponent.prototype.getBaseUrl = function (url) {
        this.baseUrl = url;
    };
    VirtueModalComponent.prototype.getVirtues = function (baseUrl) {
        var _this = this;
        this.virtuesService.getVirtues(baseUrl)
            .subscribe(function (virtues) {
            _this.virtues = virtues;
        });
    };
    VirtueModalComponent.prototype.getApps = function (baseUrl) {
        var _this = this;
        this.appService.getAppsList(baseUrl).subscribe(function (data) { return _this.appsList = data; });
    };
    VirtueModalComponent.prototype.getAppName = function (id) {
        var app = this.appsList.filter(function (data) { return data.id === id; });
        return app[0].name;
    };
    VirtueModalComponent.prototype.selectedVirtues = function (id) {
        if (this.storedVirtues.length > 0) {
            for (var _i = 0, _a = this.storedVirtues; _i < _a.length; _i++) {
                var sel = _a[_i];
                if (sel === id) {
                    return true;
                }
            }
        }
        else {
            return false;
        }
    };
    VirtueModalComponent.prototype.cbVirtueList = function (event, id) {
        if (event === true) {
            this.selVirtues.push(id);
            console.log('Added ' + id);
        }
        else {
            this.removeVm(id);
            console.log('removed ' + id);
        }
    };
    VirtueModalComponent.prototype.removeVm = function (id) {
        this.selVirtues.splice(this.selVirtues.indexOf(id), 1);
    };
    VirtueModalComponent.prototype.clearList = function () {
        this.selVirtues = [];
        this.storedVirtues = [];
    };
    VirtueModalComponent.prototype.onAddVirtues = function () {
        this.addVirtues.emit(this.selVirtues);
        // console.log('Selected Virtues: ');
        // console.log(this.selVirtues);
        this.clearList();
        this.dialogRef.close();
    };
    VirtueModalComponent.prototype.cancelModal = function () {
        this.clearList();
        this.dialogRef.close();
    };
    VirtueModalComponent.prototype.save = function () {
        this.dialogRef.close();
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", _shared_models_virtue_model__WEBPACK_IMPORTED_MODULE_1__["Virtue"])
    ], VirtueModalComponent.prototype, "virtueInput", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('userVirtue'),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"])
    ], VirtueModalComponent.prototype, "userVirtueRef", void 0);
    VirtueModalComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-virtue-modal',
            template: __webpack_require__(/*! ./virtue-modal.component.html */ "./src/app/users/virtue-modal/virtue-modal.component.html"),
            providers: [_shared_services_applications_service__WEBPACK_IMPORTED_MODULE_2__["ApplicationsService"], _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_3__["BaseUrlService"], _shared_services_users_service__WEBPACK_IMPORTED_MODULE_4__["UsersService"], _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_5__["VirtuesService"]]
        }),
        __param(5, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(_angular_material__WEBPACK_IMPORTED_MODULE_6__["MAT_DIALOG_DATA"])),
        __metadata("design:paramtypes", [_shared_services_applications_service__WEBPACK_IMPORTED_MODULE_2__["ApplicationsService"],
            _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_3__["BaseUrlService"],
            _shared_services_users_service__WEBPACK_IMPORTED_MODULE_4__["UsersService"],
            _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_5__["VirtuesService"],
            _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatDialogRef"], Object])
    ], VirtueModalComponent);
    return VirtueModalComponent;
}());



/***/ }),

/***/ "./src/app/virtual-machines/virtual-machines.component.html":
/*!******************************************************************!*\
  !*** ./src/app/virtual-machines/virtual-machines.component.html ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<router-outlet></router-outlet>\n"

/***/ }),

/***/ "./src/app/virtual-machines/virtual-machines.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/virtual-machines/virtual-machines.component.ts ***!
  \****************************************************************/
/*! exports provided: VirtualMachinesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VirtualMachinesComponent", function() { return VirtualMachinesComponent; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var VirtualMachinesComponent = /** @class */ (function () {
    function VirtualMachinesComponent(location) {
        this.location = location;
    }
    VirtualMachinesComponent.prototype.ngOnInit = function () {
    };
    VirtualMachinesComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-virtual-machines',
            template: __webpack_require__(/*! ./virtual-machines.component.html */ "./src/app/virtual-machines/virtual-machines.component.html"),
            providers: [
                _angular_common__WEBPACK_IMPORTED_MODULE_0__["Location"],
                { provide: _angular_common__WEBPACK_IMPORTED_MODULE_0__["LocationStrategy"], useClass: _angular_common__WEBPACK_IMPORTED_MODULE_0__["HashLocationStrategy"] }
            ]
        }),
        __metadata("design:paramtypes", [_angular_common__WEBPACK_IMPORTED_MODULE_0__["Location"]])
    ], VirtualMachinesComponent);
    return VirtualMachinesComponent;
}());



/***/ }),

/***/ "./src/app/virtual-machines/vm-apps-modal/vm-apps-modal.component.html":
/*!*****************************************************************************!*\
  !*** ./src/app/virtual-machines/vm-apps-modal/vm-apps-modal.component.html ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<form name=\"vm-list\">\n<h2 mat-dialog-title>Add Application Packages</h2>\n<div mat-dialog-content>\n  <p>Select applications to include in the VM.</p>\n  <div class=\"mui-container-fluid mui-col-md-12 table-container\">\n    <div class=\"mui-row table-header-group\">\n      <div class=\"mui-col-md-5 table-header\">\n        <span class=\"float-left\">\n          <mat-checkbox\n            name=\"selectAll\"\n            (change)=\"selectAll($event.checked)\"\n            [disabled]=\"disabled\" ></mat-checkbox>\n        </span>\n        <span class=\"float-left text-align-left\">Applications</span>\n      </div>\n      <div class=\"mui-col-md-2 table-header\">\n        Version\n      </div>\n      <div class=\"mui-col-md-5 table-header\">\n        OS\n      </div>\n    </div>\n    <div class=\"scrolling-list\">\n      <div *ngFor=\"let app of appList; let i = index \" class=\"mui-row table-row\">\n        <div class=\"mui-col-md-5 table-data\">\n          <span class=\"float-left\">\n            <mat-checkbox\n              name=\"cbApp\"\n              [checked]=\"selectApp(app.id)\"\n              (change)=\"cbAppList($event.checked, app.id, i)\"\n              value=\"{{app.id}}\" ></mat-checkbox>\n          </span>\n          <span class=\"float-left\">{{ app.name }}</span>\n        </div>\n        <div class=\"mui-col-md-2 table-data\">\n          {{ app.version }}\n        </div>\n        <div class=\"mui-col-md-5 table-data\">\n          {{ app.os }}\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n\n<div mat-dialog-actions>\n  <button mat-button class=\"button\" type=\"submit\" (click)=\"onAddApps();\">\n  Add Selected Apps\n  </button>\n  <button mat-button type=\"button\" (click)=\"cancelModal();\" mat-dialog-close>\n    Cancel\n  </button>\n</div>\n</form>\n"

/***/ }),

/***/ "./src/app/virtual-machines/vm-apps-modal/vm-apps-modal.component.ts":
/*!***************************************************************************!*\
  !*** ./src/app/virtual-machines/vm-apps-modal/vm-apps-modal.component.ts ***!
  \***************************************************************************/
/*! exports provided: VmAppsModalComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VmAppsModalComponent", function() { return VmAppsModalComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../shared/services/applications.service */ "./src/app/shared/services/applications.service.ts");
/* harmony import */ var _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/services/baseUrl.service */ "./src/app/shared/services/baseUrl.service.ts");
/* harmony import */ var _shared_models_application_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/models/application.model */ "./src/app/shared/models/application.model.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};






var VmAppsModalComponent = /** @class */ (function () {
    function VmAppsModalComponent(route, appsService, baseUrlService, dialogRef, data) {
        this.route = route;
        this.appsService = appsService;
        this.baseUrlService = baseUrlService;
        this.dialogRef = dialogRef;
        this.data = data;
        this.checked = false;
        this.addApps = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.appList = [];
        this.selAppList = [];
        this.pageAppList = [];
        this.pageAppList = data['selectedApps'];
    }
    VmAppsModalComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.baseUrlService.getBaseUrl().subscribe(function (res) {
            var awsServer = res[0].aws_server;
            _this.getAppsList(awsServer);
        });
        if (this.pageAppList.length > 0) {
            this.selAppList = this.pageAppList;
        }
    };
    VmAppsModalComponent.prototype.getAppsList = function (baseUrl) {
        var _this = this;
        this.appsService.getAppsList(baseUrl)
            .subscribe(function (apps) {
            _this.appList = apps;
        });
    };
    VmAppsModalComponent.prototype.selectApp = function (id) {
        if (this.pageAppList.length > 0) {
            for (var _i = 0, _a = this.pageAppList; _i < _a.length; _i++) {
                var sel = _a[_i];
                if (sel === id) {
                    return true;
                }
            }
        }
        else {
            return false;
        }
    };
    VmAppsModalComponent.prototype.selectAll = function (event) {
        if (event) {
            this.checked = true;
            for (var _i = 0, _a = this.appList; _i < _a.length; _i++) {
                var vm = _a[_i];
                this.selAppList.push(vm.id);
            }
        }
        else {
            this.checked = false;
            this.clearAppsList();
        }
    };
    VmAppsModalComponent.prototype.cbAppList = function (event, id, index) {
        if (event === true) {
            this.selAppList.push(id);
        }
        else {
            this.removeApp(id, index);
        }
    };
    VmAppsModalComponent.prototype.removeApp = function (id, index) {
        console.log(index);
        this.selAppList.splice(this.selAppList.indexOf(id), 1);
    };
    VmAppsModalComponent.prototype.clearAppsList = function () {
        this.selAppList = [];
        this.pageAppList = [];
    };
    VmAppsModalComponent.prototype.onAddApps = function () {
        // if (this.pageAppList.length > 0) {
        //   this.selAppList = this.pageAppList;
        // }
        this.addApps.emit(this.selAppList);
        this.clearAppsList();
        this.dialogRef.close();
    };
    VmAppsModalComponent.prototype.cancelModal = function () {
        this.clearAppsList();
        this.dialogRef.close();
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", _shared_models_application_model__WEBPACK_IMPORTED_MODULE_4__["Application"])
    ], VmAppsModalComponent.prototype, "appInput", void 0);
    VmAppsModalComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-vm-modal',
            template: __webpack_require__(/*! ./vm-apps-modal.component.html */ "./src/app/virtual-machines/vm-apps-modal/vm-apps-modal.component.html"),
            providers: [_shared_services_applications_service__WEBPACK_IMPORTED_MODULE_2__["ApplicationsService"], _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_3__["BaseUrlService"]]
        }),
        __param(4, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(_angular_material__WEBPACK_IMPORTED_MODULE_5__["MAT_DIALOG_DATA"])),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"],
            _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_2__["ApplicationsService"],
            _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_3__["BaseUrlService"],
            _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatDialogRef"], Object])
    ], VmAppsModalComponent);
    return VmAppsModalComponent;
}());



/***/ }),

/***/ "./src/app/virtual-machines/vm-build/vm-build.component.html":
/*!*******************************************************************!*\
  !*** ./src/app/virtual-machines/vm-build/vm-build.component.html ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"content-container\">\n  <div id=\"content-header\" class=\"titlebar\">\n    <h2 class=\"title\">Build Virtual Machine</h2>\n  </div>\n\n  <div id=\"content-main\" class=\"border-top\">\n    <div id=\"content\">\n      <div class=\"mui-container-fluid\">\n        <div class=\"mui-row\">\n          <div class=\"mui-col-md-6\">\n            <mat-form-field>\n              <input matInput #vmName placeholder=\"Virtual Machine Template Name\"  />\n            </mat-form-field>\n          </div>\n        </div>\n        <div class=\"mui-row\">\n          <div class=\"mui-col-md-2\">\n            <label for=\"operatingSystem\">Select Operating System:</label>\n          </div>\n          <div class=\"mui-col-md-4\">\n            <mat-form-field class=\"form-field\">\n              <mat-select [(ngModel)]=\"osValue\" #vmOS [ngModelOptions]=\"{standalone: true}\" placeholder=\"Select One\" [(value)]=\"selectedOS\" disableRipple>\n                <mat-option *ngFor=\"let item of osList\" [value]=\"item.os\">{{ item.name }} </mat-option>\n              </mat-select>\n            </mat-form-field>\n          </div>\n        </div>\n        <div class=\"mui-row\">\n          <div class=\"mui-col-md-2\">\n            <label for=\"templatePath\">Permissions:</label>\n          </div>\n          <div class=\"mui-col-md-4\">\n            <mat-form-field class=\"form-field\">\n              <mat-select [(ngModel)]=\"securityTag\" #vmSecurityTag [ngModelOptions]=\"{standalone: true}\" placeholder=\"Select One\" [(value)]=\"securityLevel\" disableRipple>\n                <mat-option *ngFor=\"let item of securityOptions\" [value]=\"item.level\">{{ item.name }} </mat-option>\n              </mat-select>\n            </mat-form-field>\n          </div>\n        </div>\n        <div class=\"mui-row titlebar\">\n          <div class=\"mui-col-md-6\">\n            <h3 class=\"titlebar-title\">Application Packages</h3>\n            <button mat-button class=\"titlebar-button\" (click)=\"activateModal()\">Add Application Packages</button>\n          </div>\n        </div>\n\n        <div class=\"mui-row\">\n          <div class=\"mui-col-md-6\">\n            <div class=\"mui-container-fluid data-list\">\n            <div class=\"mui-row table-header-group\">\n              <div class=\"table-header mui-col-md-6\">Application</div>\n              <div class=\"table-header mui-col-md-3\">Version</div>\n              <div class=\"table-header mui-col-md-3\">OS</div>\n            </div>\n            <!-- if there are no apps, show this message -->\n            <div class=\"mui-row margin-top-10\" *ngIf=\"appList.length < 1\">\n              <p class=\"no-data-message\">\n                No applications are attached to this VM. To add application(s), click on the button \"Add Application Packages\".\n              </p>\n            </div>\n            <div *ngFor=\"let app of appList; let i = index\" class=\"mui-row table-row\" appActiveClass>\n              <div class=\"table-data mui-col-md-6\">\n                <a class=\"edit\" (click)=\"activateModal(app.id)\">{{ app.name }}</a>\n                <span class=\"menu-options\">\n                  <button mat-button (click)=\"removeApp(app.id, i)\">Remove</button>\n                </span>\n              </div>\n              <div class=\"table-data mui-col-md-3\">{{ app.version }}</div>\n              <div class=\"table-data mui-col-md-3\">{{ app.os }}</div>\n              <div class=\"clearfix\"></div>\n            </div>\n          </div>\n          </div>\n        </div>\n      </div>\n      <hr />\n      <div class=\"mui-row\">\n        <div class=\"mui-col-md-4\">&nbsp;</div>\n        <div class=\"mui-col-md-4 form-item text-align-center\">\n          <span class=\"margin-right-10\"><input name=\"create-another\" type=\"checkbox\" value=\"1\" /> Build Another VM</span>\n          <button class=\"button-submit\" type=\"submit\" (click)=\"buildVirtualMachine(vmName.value,selectedOS,securityLevel)\">Build VM</button>\n          <button class=\"button-cancel\" type=\"cancel\">Cancel</button>\n        </div>\n        <div class=\"mui-col-md-4\"></div>\n      </div>\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/virtual-machines/vm-build/vm-build.component.ts":
/*!*****************************************************************!*\
  !*** ./src/app/virtual-machines/vm-build/vm-build.component.ts ***!
  \*****************************************************************/
/*! exports provided: VmBuildComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VmBuildComponent", function() { return VmBuildComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _vm_apps_modal_vm_apps_modal_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../vm-apps-modal/vm-apps-modal.component */ "./src/app/virtual-machines/vm-apps-modal/vm-apps-modal.component.ts");
/* harmony import */ var _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../shared/services/applications.service */ "./src/app/shared/services/applications.service.ts");
/* harmony import */ var _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../shared/services/baseUrl.service */ "./src/app/shared/services/baseUrl.service.ts");
/* harmony import */ var _shared_services_vm_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../shared/services/vm.service */ "./src/app/shared/services/vm.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};








var VmBuildComponent = /** @class */ (function () {
    function VmBuildComponent(vmService, appsService, baseUrlService, router, dialog) {
        this.vmService = vmService;
        this.appsService = appsService;
        this.baseUrlService = baseUrlService;
        this.router = router;
        this.dialog = dialog;
        this.appList = [];
        this.selAppList = [];
        this.pageAppList = [];
        this.osList = [
            { 'name': 'Debian', 'os': 'LINUX' },
            { 'name': 'Windows', 'os': 'WINDOWS' }
        ];
        this.securityOptions = [
            { 'level': 'default', 'name': 'Default' },
            { 'level': 'email', 'name': 'Email' },
            { 'level': 'power', 'name': 'Power User' },
            { 'level': 'admin', 'name': 'Administrator' }
        ];
        this.vmForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]();
    }
    VmBuildComponent.prototype.intercept = function (req, next) {
        console.log(req);
        return next.handle(req);
    };
    VmBuildComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.baseUrlService.getBaseUrl().subscribe(function (res) {
            var awsServer = res[0].aws_server;
            _this.getBaseUrl(awsServer);
            _this.getAppList(awsServer);
        });
    };
    VmBuildComponent.prototype.ngOnDestroy = function () {
    };
    VmBuildComponent.prototype.getBaseUrl = function (url) {
        this.baseUrl = url;
    };
    VmBuildComponent.prototype.getAppList = function (baseUrl) {
        var _this = this;
        this.baseUrl = baseUrl;
        // loop through the selected VM list
        var selectedApps = this.pageAppList;
        // console.log('page Apps list @ getAppList(): ' + this.pageAppList);
        this.appsService.getAppsList(baseUrl)
            .subscribe(function (apps) {
            if (_this.appList.length < 1) {
                for (var _i = 0, selectedApps_1 = selectedApps; _i < selectedApps_1.length; _i++) {
                    var sel = selectedApps_1[_i];
                    for (var _a = 0, apps_1 = apps; _a < apps_1.length; _a++) {
                        var app = apps_1[_a];
                        if (sel === app.id) {
                            _this.appList.push(app);
                            break;
                        }
                    }
                }
            }
            else {
                _this.getUpdatedAppList(baseUrl);
            }
        });
    };
    VmBuildComponent.prototype.getUpdatedAppList = function (baseUrl) {
        var _this = this;
        this.appList = [];
        this.appsService.getAppsList(baseUrl)
            .subscribe(function (apps) {
            for (var _i = 0, _a = _this.pageAppList; _i < _a.length; _i++) {
                var sel = _a[_i];
                for (var _b = 0, apps_2 = apps; _b < apps_2.length; _b++) {
                    var app = apps_2[_b];
                    if (sel === app.id) {
                        _this.appList.push(app);
                        break;
                    }
                }
            }
        });
    };
    VmBuildComponent.prototype.removeApp = function (id, index) {
        this.appList = this.appList.filter(function (data) {
            return data.id !== id;
        });
        this.pageAppList.splice(index, 1);
    };
    VmBuildComponent.prototype.activateModal = function () {
        var _this = this;
        var dialogRef = this.dialog.open(_vm_apps_modal_vm_apps_modal_component__WEBPACK_IMPORTED_MODULE_4__["VmAppsModalComponent"], {
            width: '750px',
            data: {
                selectedApps: this.pageAppList
            }
        });
        console.log('Apps sent to dialog: ' + this.pageAppList);
        dialogRef.updatePosition({ top: '5%', left: '20%' });
        var apps = dialogRef.componentInstance.addApps.subscribe(function (data) {
            _this.selAppList = data;
            console.log('Apps from dialog: ' + _this.selAppList);
            if (_this.pageAppList.length > 0) {
                _this.pageAppList = [];
            }
            _this.pageAppList = _this.selAppList;
            _this.getAppList(_this.baseUrl);
        });
        dialogRef.afterClosed().subscribe(function () {
            apps.unsubscribe();
        });
    };
    VmBuildComponent.prototype.buildVirtualMachine = function (vmName, vmOs, vmSecurityTag) {
        var body = {
            'name': vmName,
            'os': vmOs,
            'loginUser': 'system',
            'enabled': true,
            'applicationIds': this.pageAppList,
            'securityTag': vmSecurityTag
        };
        console.log(body);
        this.vmService.createVM(this.baseUrl, JSON.stringify(body));
        this.router.navigate(['/vm']);
    };
    VmBuildComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-vm-build',
            template: __webpack_require__(/*! ./vm-build.component.html */ "./src/app/virtual-machines/vm-build/vm-build.component.html"),
            providers: [_shared_services_applications_service__WEBPACK_IMPORTED_MODULE_5__["ApplicationsService"], _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_6__["BaseUrlService"], _shared_services_vm_service__WEBPACK_IMPORTED_MODULE_7__["VirtualMachineService"]]
        }),
        __metadata("design:paramtypes", [_shared_services_vm_service__WEBPACK_IMPORTED_MODULE_7__["VirtualMachineService"],
            _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_5__["ApplicationsService"],
            _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_6__["BaseUrlService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatDialog"]])
    ], VmBuildComponent);
    return VmBuildComponent;
}());



/***/ }),

/***/ "./src/app/virtual-machines/vm-duplicate/vm-duplicate.component.html":
/*!***************************************************************************!*\
  !*** ./src/app/virtual-machines/vm-duplicate/vm-duplicate.component.html ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"content-container\">\n  <div id=\"content-header\" class=\"titlebar\">\n    <h2 class=\"title\">Duplicate Virtual Machine</h2>\n  </div>\n\n  <div id=\"content-main\" class=\"border-top\">\n    <div id=\"content\">\n      <div class=\"mui-container-fluid\">\n        <div class=\"mui-row\">\n          <div class=\"mui-col-md-6\">\n            <mat-form-field>\n              <input matInput #vmName placeholder=\"Virtual Machine Template Name\" value=\"{{ vmData.name }}\"  />\n            </mat-form-field>\n          </div>\n        </div>\n        <div class=\"mui-row\">\n          <div class=\"mui-col-md-2\">\n            <label for=\"operatingSystem\">Select Operating System:</label>\n          </div>\n          <div class=\"mui-col-md-4\">\n            <mat-form-field class=\"form-field\">\n              <mat-select [(ngModel)]=\"osValue\" #vmOs [ngModelOptions]=\"{standalone: true}\" placeholder=\"Select One\" [(value)]=\"selectedOS\" disableRipple>\n                <mat-option *ngFor=\"let item of osList\" [value]=\"item.os\">{{ item.name }} </mat-option>\n              </mat-select>\n            </mat-form-field>\n          </div>\n        </div>\n        <div class=\"mui-row\">\n          <div class=\"mui-col-md-2\">\n            <label for=\"templatePath\">Permissions:</label>\n          </div>\n          <div class=\"mui-col-md-4\">\n            <mat-form-field class=\"form-field\">\n              <mat-select [(ngModel)]=\"securityTag\" #vmSecurityTag [ngModelOptions]=\"{standalone: true}\" placeholder=\"Select One\" [(value)]=\"securityLevel\" disableRipple>\n                <mat-option *ngFor=\"let item of securityOptions\" [value]=\"item.level\">{{ item.name }} </mat-option>\n              </mat-select>\n            </mat-form-field>\n          </div>\n        </div>\n        <div class=\"mui-row titlebar\">\n          <div class=\"mui-col-md-6\">\n            <h3 class=\"titlebar-title\">Application Packages</h3>\n            <button mat-button class=\"titlebar-button\" (click)=\"activateModal()\">Add Application Packages</button>\n          </div>\n        </div>\n        <!-- if there are no apps, show this message -->\n        <div class=\"mui-row\">\n          <div class=\"mui-col-md-6\">\n            <div *ngIf=\"appList.length < 1\" class=\"mui-row margin-top-10\">\n              <div class=\"mui-col-md-12\">\n                <p class=\"no-data-message\">\n                  No applications are attached to this VM. To add application(s), click on the button \"Add Application Packages\".\n                </p>\n              </div>\n            </div>\n          </div>\n        </div>\n        <div class=\"mui-row\">\n          <div class=\"mui-col-md-6\">\n            <div *ngIf=\"appList.length > 0\" class=\"mui-container-fluid data-list\">\n              <div class=\"mui-row table-header-group\">\n                <div class=\"table-header mui-col-md-6\">Application</div>\n                <div class=\"table-header mui-col-md-3\">Version</div>\n                <div class=\"table-header mui-col-md-3\">OS</div>\n              </div>\n              <div *ngFor=\"let app of appList; let i = index\" class=\"mui-row table-row\" appActiveClass>\n                <div class=\"table-data mui-col-md-6\">\n                  <a class=\"edit\" (click)=\"activateModal(app.id)\">{{ app.name }}</a>\n                  <span class=\"menu-options\">\n                  <button mat-button (click)=\"removeApp(app.id, i)\">Remove</button>\n                </span>\n                </div>\n                <div class=\"table-data mui-col-md-3\">{{ app.version }}</div>\n                <div class=\"table-data mui-col-md-3\">{{ app.os }}</div>\n                <div class=\"clearfix\"></div>\n              </div>\n            </div>\n          </div>\n        </div>\n      </div>\n      <hr />\n      <div class=\"mui-row\">\n        <div class=\"mui-col-md-4\">&nbsp;</div>\n        <div class=\"mui-col-md-4 form-item text-align-center\">\n          <button class=\"button-submit\" type=\"submit\" (click)=\"duplicateVirtualMachine(vmName.value,selectedOS,securityLevel)\">Duplicate VM Template</button>\n          <button class=\"button-cancel\" type=\"cancel\" (click)=\"cancel()\">Cancel</button>\n        </div>\n        <div class=\"mui-col-md-4\"></div>\n      </div>\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/virtual-machines/vm-duplicate/vm-duplicate.component.ts":
/*!*************************************************************************!*\
  !*** ./src/app/virtual-machines/vm-duplicate/vm-duplicate.component.ts ***!
  \*************************************************************************/
/*! exports provided: VmDuplicateComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VmDuplicateComponent", function() { return VmDuplicateComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _vm_apps_modal_vm_apps_modal_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../vm-apps-modal/vm-apps-modal.component */ "./src/app/virtual-machines/vm-apps-modal/vm-apps-modal.component.ts");
/* harmony import */ var _shared_models_vm_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/models/vm.model */ "./src/app/shared/models/vm.model.ts");
/* harmony import */ var _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../shared/services/applications.service */ "./src/app/shared/services/applications.service.ts");
/* harmony import */ var _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../shared/services/baseUrl.service */ "./src/app/shared/services/baseUrl.service.ts");
/* harmony import */ var _shared_services_vm_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../shared/services/vm.service */ "./src/app/shared/services/vm.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};








var VmDuplicateComponent = /** @class */ (function () {
    function VmDuplicateComponent(activatedRoute, appsService, baseUrlService, router, vmService, dialog) {
        this.activatedRoute = activatedRoute;
        this.appsService = appsService;
        this.baseUrlService = baseUrlService;
        this.router = router;
        this.vmService = vmService;
        this.dialog = dialog;
        this.vmData = [];
        this.appList = [];
        this.selectedApps = [];
        this.selAppList = [];
        this.pageAppList = [];
        this.osList = [
            { 'name': 'Debian', 'os': 'LINUX' },
            { 'name': 'Windows', 'os': 'WINDOWS' }
        ];
        this.securityOptions = [
            { 'level': 'default', 'name': 'Default' },
            { 'level': 'email', 'name': 'Email' },
            { 'level': 'power', 'name': 'Power User' },
            { 'level': 'admin', 'name': 'Administrator' }
        ];
    }
    VmDuplicateComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.vmId = {
            id: this.activatedRoute.snapshot.params['id']
        };
        this.baseUrlService.getBaseUrl().subscribe(function (res) {
            var awsServer = res[0].aws_server;
            _this.getBaseUrl(awsServer);
            _this.getThisVm(awsServer, _this.vmId.id);
        });
    };
    VmDuplicateComponent.prototype.getBaseUrl = function (url) {
        this.baseUrl = url;
    };
    VmDuplicateComponent.prototype.getThisVm = function (baseUrl, id) {
        var _this = this;
        this.baseUrl = baseUrl;
        this.vmService.getVM(baseUrl, id).subscribe(function (data) {
            _this.vmData = data;
            _this.vmData['name'] = 'Copy of ' + _this.vmData['name'];
            _this.selectedOS = data.os;
            _this.pageAppList = data.applicationIds;
            // this.getAppList(data.applicationIds);
            _this.getAppList();
            _this.securityLevel = data.securityTag;
        });
    };
    VmDuplicateComponent.prototype.getAppList = function () {
        var _this = this;
        var selectedApps = this.pageAppList;
        this.appsService.getAppsList(this.baseUrl)
            .subscribe(function (apps) {
            if (selectedApps.length < 1) {
                for (var _i = 0, selectedApps_1 = selectedApps; _i < selectedApps_1.length; _i++) {
                    var sel = selectedApps_1[_i];
                    for (var _a = 0, apps_1 = apps; _a < apps_1.length; _a++) {
                        var app = apps_1[_a];
                        if (sel === app.id) {
                            _this.appList.push(app);
                            break;
                        }
                    }
                }
            }
            else {
                _this.getUpdatedAppList(_this.baseUrl);
            }
        });
    };
    VmDuplicateComponent.prototype.getUpdatedAppList = function (baseUrl) {
        var _this = this;
        this.appList = [];
        this.appsService.getAppsList(baseUrl)
            .subscribe(function (apps) {
            for (var _i = 0, _a = _this.pageAppList; _i < _a.length; _i++) {
                var sel = _a[_i];
                for (var _b = 0, apps_2 = apps; _b < apps_2.length; _b++) {
                    var app = apps_2[_b];
                    if (sel === app.id) {
                        _this.appList.push(app);
                        break;
                    }
                }
            }
        });
    };
    VmDuplicateComponent.prototype.removeApp = function (id, index) {
        this.appList = this.appList.filter(function (data) {
            return data.id !== id;
        });
        this.pageAppList.splice(index, 1);
    };
    VmDuplicateComponent.prototype.activateModal = function () {
        var _this = this;
        var dialogRef = this.dialog.open(_vm_apps_modal_vm_apps_modal_component__WEBPACK_IMPORTED_MODULE_3__["VmAppsModalComponent"], {
            width: '750px',
            data: {
                selectedApps: this.pageAppList
            }
        });
        dialogRef.updatePosition({ top: '5%', left: '20%' });
        var apps = dialogRef.componentInstance.addApps.subscribe(function (data) {
            _this.selAppList = data;
            if (_this.pageAppList.length > 0) {
                _this.pageAppList = [];
            }
            _this.pageAppList = _this.selAppList;
            _this.getAppList();
            // this.getAppList(this.pageAppList);
        });
        dialogRef.afterClosed().subscribe(function () {
            apps.unsubscribe();
        });
    };
    VmDuplicateComponent.prototype.duplicateVirtualMachine = function (vmName, vmOs, vmSecurityTag) {
        var body = {
            'name': vmName,
            'os': vmOs,
            'loginUser': 'system',
            'enabled': true,
            'applicationIds': this.pageAppList,
            'securityTag': vmSecurityTag
        };
        this.vmService.createVM(this.baseUrl, JSON.stringify(body));
        this.router.navigate(['/vm']);
    };
    VmDuplicateComponent.prototype.cancel = function () {
        this.router.navigate(['/vm']);
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", _shared_models_vm_model__WEBPACK_IMPORTED_MODULE_4__["VirtualMachine"])
    ], VmDuplicateComponent.prototype, "vm", void 0);
    VmDuplicateComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-vm-duplicate',
            template: __webpack_require__(/*! ./vm-duplicate.component.html */ "./src/app/virtual-machines/vm-duplicate/vm-duplicate.component.html"),
            providers: [_shared_services_applications_service__WEBPACK_IMPORTED_MODULE_5__["ApplicationsService"], _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_6__["BaseUrlService"], _shared_services_vm_service__WEBPACK_IMPORTED_MODULE_7__["VirtualMachineService"]]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"],
            _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_5__["ApplicationsService"],
            _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_6__["BaseUrlService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _shared_services_vm_service__WEBPACK_IMPORTED_MODULE_7__["VirtualMachineService"],
            _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatDialog"]])
    ], VmDuplicateComponent);
    return VmDuplicateComponent;
}());



/***/ }),

/***/ "./src/app/virtual-machines/vm-edit/vm-edit.component.html":
/*!*****************************************************************!*\
  !*** ./src/app/virtual-machines/vm-edit/vm-edit.component.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"content-container\">\n  <div id=\"content-header\" class=\"titlebar\">\n    <h2 class=\"titlebar-title\">Build Virtual Machine</h2>\n    <button (click)=\"vmStatus(vmEnabled)\" class=\"titlebar-button\">{{ vmEnabled ? 'Disable VM' : 'Enable VM' }}</button>\n  </div>\n\n  <div id=\"content-main\" class=\"border-top\">\n    <div id=\"content\">\n      <div class=\"mui-container-fluid\">\n        <div class=\"mui-row\">\n          <div class=\"mui-col-md-6\">\n            <mat-form-field>\n              <input matInput #vmName placeholder=\"Virtual Machine Template Name\" value=\"{{ vmData.name }}\"  />\n            </mat-form-field>\n          </div>\n        </div>\n        <div class=\"mui-row\">\n          <div class=\"mui-col-md-2\">\n            <label>Select Operating System:</label>\n          </div>\n          <div class=\"mui-col-md-4\">\n            <mat-form-field class=\"form-field\">\n              <mat-select [(ngModel)]=\"osValue\" #vmOs [ngModelOptions]=\"{standalone: true}\" placeholder=\"Select One\" [(value)]=\"selectedOS\" disableRipple>\n                <mat-option *ngFor=\"let item of osList\" [value]=\"item.os\">{{ item.name }} </mat-option>\n              </mat-select>\n            </mat-form-field>\n          </div>\n        </div>\n        <div class=\"mui-row\">\n          <div class=\"mui-col-md-2\">\n            <label>Permissions:</label>\n          </div>\n          <div class=\"mui-col-md-4\">\n            <mat-form-field class=\"form-field\">\n              <mat-select [(ngModel)]=\"securityTag\" #vmSecurityTag [ngModelOptions]=\"{standalone: true}\" placeholder=\"Select One\" [(value)]=\"securityLevel\" disableRipple>\n                <mat-option *ngFor=\"let item of securityOptions\" [value]=\"item.level\">{{ item.name }} </mat-option>\n              </mat-select>\n            </mat-form-field>\n          </div>\n        </div>\n        <div class=\"mui-row titlebar\">\n          <div class=\"mui-col-md-6\">\n            <h3 class=\"titlebar-title\">Application Packages</h3>\n            <button mat-button class=\"titlebar-button\" (click)=\"activateModal()\">Add Application Packages</button>\n          </div>\n        </div>\n        <!-- if there are no apps, show this message -->\n        <div class=\"mui-row\">\n          <div class=\"mui-col-md-6\">\n            <div *ngIf=\"appList.length < 1\" class=\"mui-row margin-top-10\">\n              <div class=\"mui-col-md-12\">\n                <p class=\"no-data-message\">\n                  No applications are attached to this VM. To add application(s), click on the button \"Add Application Packages\".\n                </p>\n              </div>\n            </div>\n          </div>\n        </div>\n        <div class=\"mui-row\">\n          <div class=\"mui-col-md-6\">\n            <div *ngIf=\"appList.length > 0\" class=\"mui-container-fluid data-list\">\n            <div class=\"mui-row table-header-group\">\n              <div class=\"table-header mui-col-md-6\">Application</div>\n              <div class=\"table-header mui-col-md-3\">Version</div>\n              <div class=\"table-header mui-col-md-3\">OS</div>\n            </div>\n            <div *ngFor=\"let app of appList; let i = index\" class=\"mui-row table-row\" appActiveClass>\n              <div class=\"table-data mui-col-md-6\">\n                <a class=\"edit\" (click)=\"activateModal(app.id)\">{{ app.name }}</a>\n                <span class=\"menu-options\">\n                  <button mat-button (click)=\"removeApp(app.id, i)\">Remove</button>\n                </span>\n              </div>\n              <div class=\"table-data mui-col-md-3\">{{ app.version }}</div>\n              <div class=\"table-data mui-col-md-3\">{{ app.os }}</div>\n              <div class=\"clearfix\"></div>\n            </div>\n          </div>\n          </div>\n        </div>\n      </div>\n      <hr />\n      <div class=\"mui-row\">\n        <div class=\"mui-col-md-4\">&nbsp;</div>\n        <div class=\"mui-col-md-4 form-item text-align-center\">\n          <button class=\"button-submit\" type=\"submit\" (click)=\"buildVirtualMachine(vmData.id,vmName.value,selectedOS,securityLevel)\">Update Template</button>\n          <button class=\"button-cancel\" type=\"cancel\" (click)=\"cancel()\">Cancel</button>\n        </div>\n        <div class=\"mui-col-md-4\"></div>\n      </div>\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/virtual-machines/vm-edit/vm-edit.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/virtual-machines/vm-edit/vm-edit.component.ts ***!
  \***************************************************************/
/*! exports provided: VmEditComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VmEditComponent", function() { return VmEditComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _shared_models_vm_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/models/vm.model */ "./src/app/shared/models/vm.model.ts");
/* harmony import */ var _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/services/baseUrl.service */ "./src/app/shared/services/baseUrl.service.ts");
/* harmony import */ var _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../shared/services/applications.service */ "./src/app/shared/services/applications.service.ts");
/* harmony import */ var _shared_services_vm_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../shared/services/vm.service */ "./src/app/shared/services/vm.service.ts");
/* harmony import */ var _vm_apps_modal_vm_apps_modal_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../vm-apps-modal/vm-apps-modal.component */ "./src/app/virtual-machines/vm-apps-modal/vm-apps-modal.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};








var VmEditComponent = /** @class */ (function () {
    function VmEditComponent(activatedRoute, appsService, baseUrlService, router, vmService, dialog) {
        this.activatedRoute = activatedRoute;
        this.appsService = appsService;
        this.baseUrlService = baseUrlService;
        this.router = router;
        this.vmService = vmService;
        this.dialog = dialog;
        this.vmData = [];
        this.appList = [];
        this.selectedApps = [];
        this.selAppList = [];
        this.pageAppList = [];
        this.osList = [
            { 'name': 'Debian', 'os': 'LINUX' },
            { 'name': 'Windows', 'os': 'WINDOWS' }
        ];
        this.securityOptions = [
            { 'level': 'default', 'name': 'Default' },
            { 'level': 'email', 'name': 'Email' },
            { 'level': 'power', 'name': 'Power User' },
            { 'level': 'admin', 'name': 'Administrator' }
        ];
    }
    VmEditComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.vmId = {
            id: this.activatedRoute.snapshot.params['id']
        };
        this.baseUrlService.getBaseUrl().subscribe(function (res) {
            var awsServer = res[0].aws_server;
            _this.getBaseUrl(awsServer);
            _this.getThisVm(awsServer, _this.vmId.id);
        });
    };
    VmEditComponent.prototype.resetRouter = function () {
        var _this = this;
        setTimeout(function () {
            _this.router.navigated = false;
            _this.getThisVm(_this.baseUrl, _this.vmId.id);
        }, 1000);
    };
    VmEditComponent.prototype.getBaseUrl = function (url) {
        this.baseUrl = url;
    };
    VmEditComponent.prototype.getThisVm = function (baseUrl, id) {
        var _this = this;
        this.baseUrl = baseUrl;
        this.vmService.getVM(baseUrl, id).subscribe(function (data) {
            _this.vmData = data;
            _this.selectedOS = data.os;
            _this.pageAppList = data.applicationIds;
            _this.getAppList(data.applicationIds);
            _this.securityLevel = data.securityTag;
            _this.vmEnabled = data.enabled;
        });
    };
    VmEditComponent.prototype.getAppList = function (vmApps) {
        var _this = this;
        var selectedApps = this.pageAppList;
        this.appsService.getAppsList(this.baseUrl)
            .subscribe(function (apps) {
            if (selectedApps.length < 1) {
                for (var _i = 0, selectedApps_1 = selectedApps; _i < selectedApps_1.length; _i++) {
                    var sel = selectedApps_1[_i];
                    for (var _a = 0, apps_1 = apps; _a < apps_1.length; _a++) {
                        var app = apps_1[_a];
                        if (sel === app.id) {
                            _this.appList.push(app);
                            break;
                        }
                    }
                }
            }
            else {
                _this.getUpdatedAppList(_this.baseUrl);
            }
        });
    };
    VmEditComponent.prototype.getUpdatedAppList = function (baseUrl) {
        var _this = this;
        this.appList = [];
        this.appsService.getAppsList(baseUrl)
            .subscribe(function (apps) {
            for (var _i = 0, _a = _this.pageAppList; _i < _a.length; _i++) {
                var sel = _a[_i];
                for (var _b = 0, apps_2 = apps; _b < apps_2.length; _b++) {
                    var app = apps_2[_b];
                    if (sel === app.id) {
                        _this.appList.push(app);
                        break;
                    }
                }
            }
        });
    };
    VmEditComponent.prototype.vmStatus = function (isEnabled) {
        if (isEnabled) {
            this.vmEnabled = false;
        }
        else {
            this.vmEnabled = true;
        }
    };
    VmEditComponent.prototype.removeApp = function (id, index) {
        this.appList = this.appList.filter(function (data) {
            return data.id !== id;
        });
        this.pageAppList.splice(index, 1);
    };
    VmEditComponent.prototype.activateModal = function () {
        var _this = this;
        var dialogRef = this.dialog.open(_vm_apps_modal_vm_apps_modal_component__WEBPACK_IMPORTED_MODULE_7__["VmAppsModalComponent"], {
            width: '750px',
            data: {
                selectedApps: this.pageAppList
            }
        });
        dialogRef.updatePosition({ top: '5%', left: '20%' });
        var apps = dialogRef.componentInstance.addApps.subscribe(function (data) {
            _this.selAppList = data;
            if (_this.pageAppList.length > 0) {
                _this.pageAppList = [];
            }
            _this.pageAppList = _this.selAppList;
            _this.getAppList(_this.pageAppList);
        });
        dialogRef.afterClosed().subscribe(function () {
            apps.unsubscribe();
        });
    };
    VmEditComponent.prototype.buildVirtualMachine = function (id, vmName, vmOs, vmSecurityTag) {
        var body = {
            'name': vmName,
            'os': vmOs,
            'loginUser': 'system',
            'enabled': this.vmEnabled,
            'applicationIds': this.pageAppList,
            'securityTag': vmSecurityTag
        };
        this.vmService.updateVM(this.baseUrl, id, JSON.stringify(body));
        this.resetRouter();
        this.router.navigate(['/vm']);
    };
    VmEditComponent.prototype.cancel = function () {
        this.router.navigate(['/vm']);
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", _shared_models_vm_model__WEBPACK_IMPORTED_MODULE_3__["VirtualMachine"])
    ], VmEditComponent.prototype, "vm", void 0);
    VmEditComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-vm-edit',
            template: __webpack_require__(/*! ./vm-edit.component.html */ "./src/app/virtual-machines/vm-edit/vm-edit.component.html"),
            providers: [_shared_services_applications_service__WEBPACK_IMPORTED_MODULE_5__["ApplicationsService"], _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_4__["BaseUrlService"], _shared_services_vm_service__WEBPACK_IMPORTED_MODULE_6__["VirtualMachineService"]]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"],
            _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_5__["ApplicationsService"],
            _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_4__["BaseUrlService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _shared_services_vm_service__WEBPACK_IMPORTED_MODULE_6__["VirtualMachineService"],
            _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatDialog"]])
    ], VmEditComponent);
    return VmEditComponent;
}());



/***/ }),

/***/ "./src/app/virtual-machines/vm-list/vm-list.component.html":
/*!*****************************************************************!*\
  !*** ./src/app/virtual-machines/vm-list/vm-list.component.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"content-container\">\n  <div id=\"content-header\" class=\"titlebar\">\n    <h1 class=\"titlebar-title\">Virtual Machines</h1>\n    <button class=\"titlebar-button\" routerLink=\"/virtual-machines/vm-build\">Build VM Template</button>\n    <button class=\"titlebar-button\" [disabled]=\"true\">Import VM</button>\n  </div>\n\n  <div id=\"content-main\">\n    <div id=\"content\">\n      <div *ngIf=\"vms.length < 1\" class=\"mui-container-fluid\">\n        <!-- if there are no virtues, show this message -->\n        <div class=\"mui-row margin-top-10\">\n          <div class=\"mui-col-md-12 padding-left-0\">\n            <p class=\"no-data-message\">\n              No virtual machines have been built at this time. To build a virtual machine, click on the button \"Build VM\" above.\n            </p>\n          </div>\n        </div>\n      </div>\n\n      <!-- if there are virtues, show this list -->\n      <div *ngIf=\"vms.length > 0\" class=\"mui-container-fluid\">\n        <div class=\"mui-row virtues-filters\">\n          <div class=\"mui-col-md-12 padding-left-0 filters\">\n            <span *ngIf=\"sortValue === '*'\">All VMs</span>\n            <a *ngIf=\"sortValue !== '*'\"  (click)=\"enabledVmList('enabled','*', sortType)\">All VMs</a> |\n            <span *ngIf=\"sortValue === true\">Enabled VMs</span>\n            <a *ngIf=\"sortValue !== true\" (click)=\"enabledVmList('enabled', true, sortType)\">Enabled VMs</a> |\n            <span *ngIf=\"sortValue === false\">Disabled VMs</span>\n            <a *ngIf=\"sortValue !== false\" (click)=\"enabledVmList('enabled', false, sortType)\">Disabled VMs</a>\n          </div>\n        </div>\n      </div>\n      <div class=\"mui-container-fluid data-list\">\n        <div class=\"mui-row table-header-group\">\n          <div class=\"table-header mui-col-md-3\">\n            <a (click)=\"sortVmColumns('name',sortBy)\">Virtual Machine Name</a>\n            <span class=\"list-sorter\">\n              <span *ngIf=\"sortColumn === 'name' && sortBy === 'asc'\" class=\"fa fa-sort-up\"></span>\n              <span *ngIf=\"sortColumn === 'name' && sortBy === 'desc'\" class=\"fa fa-sort-down\"></span>\n              <span class=\"fa fa-sort font-color-gray\"></span>\n            </span>\n          </div>\n          <div class=\"table-header mui-col-md-2\">OS</div>\n          <div class=\"table-header mui-col-md-2\">Applications</div>\n          <div class=\"table-header mui-col-md-2\">Last Modified By</div>\n          <div class=\"table-header mui-col-md-1\">Security</div>\n          <div class=\"table-header mui-col-md-2\">\n            <a (click)=\"sortVmColumns('date',sortBy)\">Modified Date</a>\n            <span class=\"list-sorter\">\n              <span *ngIf=\"sortColumn === 'date' && sortBy === 'asc'\" class=\"fa fa-sort-up\"></span>\n              <span *ngIf=\"sortColumn === 'date' && sortBy === 'desc'\" class=\"fa fa-sort-down\"></span>\n              <span class=\"fa fa-sort font-color-gray\"></span>\n            </span>\n          </div>\n        </div>\n        <div *ngFor=\"let vm of vms | listFilter : sortColumn : sortType : sortValue : sortBy\" class=\"mui-row table-row\" appActiveClass>\n          <div class=\"table-data mui-col-md-3\">\n            <div class=\"mini-menu\">\n              <a class=\"edit\" routerLink=\"/virtual-machines/edit/{{vm.id}}\">{{ vm.name }}</a>\n\n              <!-- if this virtue is enabled show this menu -->\n              <span *ngIf=\"vm.enabled === true\" class=\"menu-options\">\n                <a (click)=\"vmStatus(vm.id)\">Disable</a> |\n                <a class=\"edit\" routerLink=\"/virtual-machines/duplicate/{{vm.id}}\">Duplicate</a>\n              </span>\n\n              <!-- if this virtue is disabled show this menu -->\n              <span *ngIf=\"vm.enabled === false\" class=\"menu-options\">\n                <a (click)=\"vmStatus(vm.id)\">Enable</a> |\n                <a (click)=\"openDialog(vm.id, 'delete', 'delete', vm.name)\">Delete</a>\n              </span>\n          </div>\n          </div>\n          <div class=\"table-data mui-col-md-2\">{{ vm.os }}</div>\n          <div class=\"table-data mui-col-md-2\">\n            <ul>\n              <ng-container *ngFor=\"let app of vm.applicationIds\">\n              <li>{{ getAppName(app)}}</li>\n              </ng-container>\n            </ul>\n          </div>\n          <div class=\"table-data mui-col-md-2\">{{ vm.lastEditor }}</div>\n          <div class=\"table-data mui-col-md-1\">{{ vm.securityTag }}</div>\n          <div class=\"table-data mui-col-md-2\">\n            {{vm.enabled ? 'Enabled' : 'Disabled'}}<br />\n            {{vm.lastModification | date:'short' }}\n          </div>\n          <div class=\"clearfix\"></div>\n        </div>\n      </div>\n      <div class=\"paging\">\n        <div class=\"page-number mui-col-md-4\">Page # of #</div>\n        <div class=\"page-controls mui-col-md-4\"><span><< First | < Previous | Next > | Last >></span></div>\n        <div class=\"page-item-total mui-col-md-4\">{{ totalVms }} Virtual Machines</div>\n        <div class=\"clearfix\"></div>\n      </div>\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/virtual-machines/vm-list/vm-list.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/virtual-machines/vm-list/vm-list.component.ts ***!
  \***************************************************************/
/*! exports provided: VmListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VmListComponent", function() { return VmListComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/services/applications.service */ "./src/app/shared/services/applications.service.ts");
/* harmony import */ var _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/services/baseUrl.service */ "./src/app/shared/services/baseUrl.service.ts");
/* harmony import */ var _shared_services_vm_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../shared/services/vm.service */ "./src/app/shared/services/vm.service.ts");
/* harmony import */ var _dialogs_dialogs_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../dialogs/dialogs.component */ "./src/app/dialogs/dialogs.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var VmListComponent = /** @class */ (function () {
    function VmListComponent(vmService, appsService, baseUrlService, router, dialog) {
        this.vmService = vmService;
        this.appsService = appsService;
        this.baseUrlService = baseUrlService;
        this.router = router;
        this.dialog = dialog;
        this.vms = [];
        this.apps = [];
        // these are the default properties the list sorts by
        this.sortColumn = 'name';
        this.sortType = 'enabled';
        this.sortValue = '*';
        this.sortBy = 'asc';
        this.totalVms = 0;
        // override the route reuse strategy
        this.router.routeReuseStrategy.shouldReuseRoute = function () {
            return false;
        };
    }
    VmListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.baseUrlService.getBaseUrl().subscribe(function (res) {
            var awsServer = res[0].aws_server;
            _this.getBaseUrl(awsServer);
            _this.getVmList(awsServer);
            _this.getAppsList(awsServer);
        });
        this.resetRouter();
    };
    VmListComponent.prototype.getBaseUrl = function (url) {
        this.baseUrl = url;
    };
    VmListComponent.prototype.resetRouter = function () {
        var _this = this;
        setTimeout(function () {
            _this.router.navigated = false;
            _this.getVmList(_this.baseUrl);
        }, 1000);
    };
    VmListComponent.prototype.getVmList = function (baseUrl) {
        var _this = this;
        this.vmService.getVmList(baseUrl).subscribe(function (vmlist) {
            _this.vms = vmlist;
            _this.totalVms = vmlist.length;
            _this.sortVms(vmlist);
        });
    };
    VmListComponent.prototype.sortVms = function (sortDirection) {
        if (sortDirection === 'asc') {
            this.vms.sort(function (leftSide, rightSide) {
                if (leftSide['name'] < rightSide['name']) {
                    return -1;
                }
                if (leftSide['name'] > rightSide['name']) {
                    return 1;
                }
                return 0;
            });
        }
        else {
            this.vms.sort(function (leftSide, rightSide) {
                if (leftSide['name'] < rightSide['name']) {
                    return 1;
                }
                if (leftSide['name'] > rightSide['name']) {
                    return -1;
                }
                return 0;
            });
        }
    };
    VmListComponent.prototype.enabledVmList = function (sortType, enabledValue, sortBy) {
        console.log('enabledVirtueList() => ' + enabledValue);
        if (this.sortValue !== enabledValue) {
            this.sortBy = 'asc';
        }
        else {
            this.sortListBy(sortBy);
        }
        this.sortValue = enabledValue;
        this.sortType = sortType;
    };
    VmListComponent.prototype.sortVmColumns = function (sortColumn, sortBy) {
        if (this.sortColumn === sortColumn) {
            this.sortListBy(sortBy);
        }
        else {
            if (sortColumn === 'name') {
                this.sortBy = 'asc';
                this.sortColumn = sortColumn;
            }
            else if (sortColumn === 'date') {
                this.sortColumn = sortColumn;
                this.sortBy = 'desc';
            }
        }
    };
    VmListComponent.prototype.sortListBy = function (sortDirection) {
        if (sortDirection === 'asc') {
            this.sortBy = 'desc';
        }
        else {
            this.sortBy = 'asc';
        }
    };
    VmListComponent.prototype.getAppsList = function (baseUrl) {
        var _this = this;
        this.appsService.getAppsList(baseUrl)
            .subscribe(function (appList) {
            _this.apps = appList;
        });
    };
    VmListComponent.prototype.getAppName = function (id) {
        if (id) {
            var selApp = this.apps.filter(function (app) { return id === app.id; })
                .map(function (appName) {
                return appName.name;
            });
            return selApp;
        }
    };
    VmListComponent.prototype.vmStatus = function (id) {
        var _this = this;
        this.vmService.toggleVmStatus(this.baseUrl, id).subscribe(function (data) {
            _this.vm = data;
        });
        this.resetRouter();
        this.router.navigate(['/vm']);
    };
    VmListComponent.prototype.deleteVM = function (id) {
        this.vmService.deleteVM(this.baseUrl, id);
        this.resetRouter();
    };
    VmListComponent.prototype.openDialog = function (id, type, category, description) {
        var _this = this;
        var dialogRef = this.dialog.open(_dialogs_dialogs_component__WEBPACK_IMPORTED_MODULE_6__["DialogsComponent"], {
            width: '450px',
            data: {
                dialogType: type,
                dialogCategory: category,
                dialogId: id,
                dialogDescription: description
            }
        });
        dialogRef.updatePosition({ top: '15%', left: '36%' });
        var dialogResults = dialogRef.componentInstance.dialogEmitter.subscribe(function (data) {
            // console.log('Dialog Emitter: ' + data);
            if (type === 'delete') {
                _this.deleteVM(data);
            }
        });
    };
    VmListComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-vm-list',
            providers: [_shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_4__["BaseUrlService"], _shared_services_vm_service__WEBPACK_IMPORTED_MODULE_5__["VirtualMachineService"], _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_3__["ApplicationsService"]],
            template: __webpack_require__(/*! ./vm-list.component.html */ "./src/app/virtual-machines/vm-list/vm-list.component.html")
        }),
        __metadata("design:paramtypes", [_shared_services_vm_service__WEBPACK_IMPORTED_MODULE_5__["VirtualMachineService"],
            _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_3__["ApplicationsService"],
            _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_4__["BaseUrlService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _angular_material__WEBPACK_IMPORTED_MODULE_1__["MatDialog"]])
    ], VmListComponent);
    return VmListComponent;
}());



/***/ }),

/***/ "./src/app/virtues/create-virtue/create-virtue.component.css":
/*!*******************************************************************!*\
  !*** ./src/app/virtues/create-virtue/create-virtue.component.css ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n.virtue-form {\n  margin-top: 1.5rem;\n  padding: 1.5rem 0 1rem;\n}\n.virtue-form p {\n  display: block;\n  margin: 1rem 0;\n}\n.virtue-options {\n  cursor: pointer;\n  display: block;\n  font-size: 0.88rem;\n  clear: both;\n}\nvertical-split-pane {\n  border-top: 1px solid #b2b2b2;\n  border-right: 1px solid #b2b2b2;\n  display: flex;\n  flex-direction: column;\n  align-content: stretch;\n}\nvertical-split-pane:after {\n  clear: bloth;\n  content: ' ';\n  display: block;\n  height: 0;\n}\n.v-outer {\n  border-bottom: 1px solid #B2B2B2;\n  display: flex;\n  flex-direction: column;\n  align-items: stretch;\n  height: 100%;\n}\n.split-pane-content-primary {\n  max-height: 700px;\n  min-height: 480px;\n  overflow-y: scroll;\n  padding-top: 1rem;\n  padding-bottom: 1rem;\n  padding-right: 1.2rem;\n}\n.split-pane-content-secondary {\n  background-color: rgba(233,227,230,0.5);\n  height: 100%;\n  min-height: 480px;\n  overflow-y: scroll;\n}\n.icon-upload {\n  display: block;\n  min-width: 300px;\n}\n.virtue-list .mui-row {\n  border-bottom: 1px solid #B2B2B2;\n}\n.virtue-settings {\n  box-sizing: content-box;\n}\n.virtue-settings .virtue-titlebar {\n  padding-left: 2rem;\n}\n"

/***/ }),

/***/ "./src/app/virtues/create-virtue/create-virtue.component.html":
/*!********************************************************************!*\
  !*** ./src/app/virtues/create-virtue/create-virtue.component.html ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"content-container\">\n  <div id=\"content-header\" class=\"virtue-titlebar\">\n    <h2 class=\"virtue-title\">Create Virtue</h2>\n  </div>\n\n  <div id=\"content-main\" class=\"border-top\">\n      <div id=\"content\" class=\"virtue-content\">\n        <vertical-split-pane\n          primary-component-minsize=\"60\"\n          secondary-component-minsize=\"40\"\n          [primary-component-toggled-off]=\"false\"\n          local-storage-key=\"split-pane\"\n          primary-component-initialratio=\"0.8\">\n\n          <div class=\"split-pane-content-primary\">\n\n            <div class=\"mui-row form-item margin-top-15\">\n              <div class=\"mui-col-md-12\">\n                <input type=\"text\" #virtueName placeholder=\"Virtue Name\" matInput />\n              </div>\n            </div>\n            <div class=\"mui-row titlebar\">\n              <div class=\"mui-col-md-12\">\n                <h3 class=\"titlebar-title\">Virtual Machines</h3>\n                <button mat-button class=\"titlebar-button\" (click)=\"activateModal()\">Add VM</button>\n              </div>\n            </div>\n            <div class=\"mui-container-fluid data-list\">\n              <div class=\"mui-row table-header-group\">\n                <div class=\"table-header mui-col-md-5\">Virtual Machine</div>\n                <div class=\"table-header mui-col-md-2\">OS</div>\n                <div class=\"table-header mui-col-md-5\">Applications</div>\n              </div>\n              <!-- if there are no virtue, show this message -->\n              <div *ngIf=\"vmList.length < 1\" class=\"mui-row margin-top-10\">\n                <div class=\"mui-col-md-12 padding-left-0\">\n                  <p class=\"no-data-message\">\n                    No virtual machines are attached to this virtue. To add VM(s), click on the button \"Add VM\".\n                  </p>\n                </div>\n              </div>\n              <div *ngFor=\"let vm of vmList; let i = index\" class=\"mui-row table-row\" appActiveClass>\n                <div class=\"table-data mui-col-md-5\">\n                  <a class=\"edit\" (click)=\"activateModal(vm.id)\">{{ vm.name }}</a>\n                  <!-- if this virtue is enabled show this menu -->\n                  <span class=\"menu-options\" *ngIf=\"vm.enabled\">\n                    <button>Disable</button> | <button mat-button (click)=\"removeVm(vm.id, i)\">Remove</button>\n                  </span>\n                  <!-- if this virtue is disabled show this menu -->\n                  <span class=\"menu-options\" *ngIf=\"vm.enabled===false\">\n                    <a href=\"#\">Enable</a> | <a (click)=\"removeVm(vm.id)\">Remove</a>\n                  </span>\n                </div>\n                <div class=\"table-data mui-col-md-2\">{{ vm.os }}</div>\n                <div class=\"table-data mui-col-md-5\">\n                  <ul>\n                    <li *ngFor=\"let app of vm.applicationIds\">{{ getAppName(app) }}</li>\n                  </ul>\n                </div>\n                <div class=\"clearfix\"></div>\n              </div>\n            </div>\n            <div class=\"mui-container-fluid\">\n              <div class=\"mui-row paging\">\n                <div class=\"mui-col-md-4 page-number padding-left-0\">&nbsp;</div>\n                <div class=\"mui-col-md-4 page-controls\">&nbsp;</div>\n                <div class=\"mui-col-md-4 page-item-total padding-right-0\"># Virtual Machine(s)</div>\n                <div class=\"clearfix\"></div>\n              </div>\n            </div>\n          </div>\n\n          <div class=\"split-pane-content-secondary\">\n            <div id=\"settings\" class=\"virtue-settings\">\n              <div class=\"virtue-titlebar\">\n                <h3> Virtue Settings</h3>\n              </div>\n              <app-virtue-settings></app-virtue-settings>\n            </div>\n          </div>\n        </vertical-split-pane>\n        <div class=\"mui-row border-top\">\n          <div class=\"mui-col-md-4\">\n            <input #editor type=\"hidden\" value=\"system\" />\n          </div>\n          <div class=\"mui-col-md-4 form-item text-align-center\">\n            <span class=\"margin-right-10\">\n              <input name=\"create-another\" type=\"checkbox\" value=\"1\" /> Create Another Virtue\n            </span>\n            <button class=\"button-submit\" type=\"submit\" (click)=\"createVirtue(virtueName.value); virtueName.value=''\">Create Virtue</button>\n            <button class=\"button-cancel\" type=\"cancel\">Cancel</button>\n          </div>\n          <div class=\"mui-col-md-4\"></div>\n        </div>\n      </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/virtues/create-virtue/create-virtue.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/virtues/create-virtue/create-virtue.component.ts ***!
  \******************************************************************/
/*! exports provided: CreateVirtueComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateVirtueComponent", function() { return CreateVirtueComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _vm_modal_vm_modal_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../vm-modal/vm-modal.component */ "./src/app/virtues/vm-modal/vm-modal.component.ts");
/* harmony import */ var _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../shared/services/applications.service */ "./src/app/shared/services/applications.service.ts");
/* harmony import */ var _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../shared/services/baseUrl.service */ "./src/app/shared/services/baseUrl.service.ts");
/* harmony import */ var _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../shared/services/virtues.service */ "./src/app/shared/services/virtues.service.ts");
/* harmony import */ var _shared_services_vm_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../shared/services/vm.service */ "./src/app/shared/services/vm.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









// import { VirtualMachine } from '../../shared/models/vm.model';
var CreateVirtueComponent = /** @class */ (function () {
    function CreateVirtueComponent(baseUrlService, router, appsService, virtuesService, vmService, dialog) {
        this.baseUrlService = baseUrlService;
        this.router = router;
        this.appsService = appsService;
        this.virtuesService = virtuesService;
        this.vmService = vmService;
        this.dialog = dialog;
        this.vmList = [];
        this.appsList = [];
        this.selVmsList = [];
        this.pageVmList = [];
        this.virtueForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]();
        // override the route reuse strategy
        this.router.routeReuseStrategy.shouldReuseRoute = function () {
            return false;
        };
    }
    CreateVirtueComponent.prototype.intercept = function (req, next) {
        console.log(req);
        return next.handle(req);
    };
    CreateVirtueComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.baseUrlService.getBaseUrl().subscribe(function (res) {
            var awsServer = res[0].aws_server;
            _this.getBaseUrl(awsServer);
            _this.getAppsList(awsServer);
        });
        if (this.pageVmList.length > 0) {
            this.getVmList();
        }
    };
    CreateVirtueComponent.prototype.getBaseUrl = function (url) {
        this.baseUrl = url;
    };
    CreateVirtueComponent.prototype.resetRouter = function () {
        var _this = this;
        setTimeout(function () {
            _this.router.navigated = false;
        }, 1000);
    };
    CreateVirtueComponent.prototype.getVmList = function () {
        var _this = this;
        var selectedVm = this.pageVmList;
        this.vmService.getVmList(this.baseUrl)
            .subscribe(function (data) {
            if (_this.vmList.length < 1) {
                for (var _i = 0, selectedVm_1 = selectedVm; _i < selectedVm_1.length; _i++) {
                    var sel = selectedVm_1[_i];
                    for (var _a = 0, data_1 = data; _a < data_1.length; _a++) {
                        var vm = data_1[_a];
                        if (sel === vm.id) {
                            _this.vmList.push(vm);
                            break;
                        }
                    }
                }
            }
            else {
                _this.getUpdatedVmList(_this.baseUrl);
            }
        });
    };
    CreateVirtueComponent.prototype.getAppsList = function (baseUrl) {
        var _this = this;
        this.appsService.getAppsList(baseUrl).subscribe(function (data) {
            _this.appsList = data;
        });
    };
    CreateVirtueComponent.prototype.getAppName = function (id) {
        var app = this.appsList.filter(function (data) { return id === data.id; });
        if (id !== null) {
            return app[0].name;
        }
    };
    CreateVirtueComponent.prototype.getUpdatedVmList = function (baseUrl) {
        var _this = this;
        this.vmList = [];
        this.vmService.getVmList(baseUrl)
            .subscribe(function (data) {
            for (var _i = 0, _a = _this.pageVmList; _i < _a.length; _i++) {
                var sel = _a[_i];
                for (var _b = 0, data_2 = data; _b < data_2.length; _b++) {
                    var vm = data_2[_b];
                    if (sel === vm.id) {
                        _this.vmList.push(vm.id);
                        break;
                    }
                }
            }
        });
    };
    CreateVirtueComponent.prototype.createVirtue = function (virtueName) {
        console.log(virtueName);
        var virtueVms = [];
        for (var _i = 0, _a = this.pageVmList; _i < _a.length; _i++) {
            var vm = _a[_i];
            virtueVms.push(vm);
        }
        console.log(virtueVms);
        var body = {
            'name': virtueName,
            'version': '1.0',
            'enabled': true,
            'virtualMachineTemplateIds': virtueVms
        };
        // console.log('New Virtue: ');
        console.log(body);
        this.virtuesService.createVirtue(this.baseUrl, JSON.stringify(body)).subscribe(function (data) {
            return data;
        }, function (error) {
            console.log(error.message);
        });
        this.resetRouter();
        this.router.navigate(['/virtues']);
    };
    CreateVirtueComponent.prototype.removeVm = function (id, index) {
        this.vmList = this.vmList.filter(function (data) {
            return data.id !== id;
        });
        this.pageVmList.splice(index, 1);
    };
    CreateVirtueComponent.prototype.activateModal = function () {
        var _this = this;
        var dialogRef = this.dialog.open(_vm_modal_vm_modal_component__WEBPACK_IMPORTED_MODULE_4__["VmModalComponent"], {
            width: '800px',
            data: {
                selectedVms: this.pageVmList
            }
        });
        // console.log('VMs sent to dialog: ' + this.pageVmList);
        dialogRef.updatePosition({ top: '5%', left: '20%' });
        var vms = dialogRef.componentInstance.addVms.subscribe(function (data) {
            _this.selVmsList = data;
            // console.log('VMs from dialog: ' + this.selVmsList);
            if (_this.pageVmList.length > 0) {
                _this.pageVmList = [];
            }
            _this.pageVmList = _this.selVmsList;
            _this.getVmList();
        });
        dialogRef.afterClosed().subscribe(function () {
            vms.unsubscribe();
        });
    };
    CreateVirtueComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-create-virtue',
            template: __webpack_require__(/*! ./create-virtue.component.html */ "./src/app/virtues/create-virtue/create-virtue.component.html"),
            styles: [__webpack_require__(/*! ./create-virtue.component.css */ "./src/app/virtues/create-virtue/create-virtue.component.css")],
            providers: [_shared_services_applications_service__WEBPACK_IMPORTED_MODULE_5__["ApplicationsService"], _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_6__["BaseUrlService"], _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_7__["VirtuesService"], _shared_services_vm_service__WEBPACK_IMPORTED_MODULE_8__["VirtualMachineService"]]
        }),
        __metadata("design:paramtypes", [_shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_6__["BaseUrlService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_5__["ApplicationsService"],
            _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_7__["VirtuesService"],
            _shared_services_vm_service__WEBPACK_IMPORTED_MODULE_8__["VirtualMachineService"],
            _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatDialog"]])
    ], CreateVirtueComponent);
    return CreateVirtueComponent;
}());



/***/ }),

/***/ "./src/app/virtues/duplicate-virtue/duplicate-virtue.component.html":
/*!**************************************************************************!*\
  !*** ./src/app/virtues/duplicate-virtue/duplicate-virtue.component.html ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"content-container\">\n  <div id=\"content-header\" class=\"titlebar\">\n    <h1 class=\"titlebar-title\">Duplicate Virtue</h1>\n  </div>\n  <div id=\"content-main\">\n    <div id=\"content\" class=\"border-top virtue-content\">\n      <vertical-split-pane\n        primary-component-minsize=\"60\"\n        secondary-component-minsize=\"40\"\n        [primary-component-toggled-off]=\"false\"\n        local-storage-key=\"split-pane\"\n        primary-component-initialratio=\"0.8\">\n\n        <div class=\"split-pane-content-primary\">\n\n          <div class=\"mui-row form-item margin-top-15\">\n            <div class=\"mui-col-md-12\">\n              <input type=\"text\" #virtueName [(value)]=\"virtueData.name\" placeholder=\"Virtue Name\" matInput />\n              <br />\n              <span style=\"clear: both;color: #ccc; font-size:10px;margin-top:5px;\">ID: {{ virtueId.id }}</span>\n            </div>\n          </div>\n          <div class=\"mui-row form-item margin-top-15\">\n            <div class=\"mui-col-md-1\">\n              <label>Version: </label>\n            </div>\n            <div class=\"mui-col-md-2\">\n              <input type=\"text\" #virtueVersion [(value)]=\"virtueData.version\"  matInput />\n            </div>\n          </div>\n          <div class=\"mui-row titlebar\">\n            <div class=\"mui-col-md-12\">\n              <h2 class=\"titlebar-title\">Virtual Machines</h2>\n              <button mat-button class=\"titlebar-button\" (click)=\"activateModal(virtueData.id)\">Add VM</button>\n            </div>\n          </div>\n          <!-- if there are virtual machines, show this list -->\n          <div class=\"mui-container-fluid data-list\">\n            <div class=\"mui-row table-header-group\">\n              <div class=\"table-header mui-col-md-4\">VM</div>\n              <div class=\"table-header mui-col-md-2\">OS</div>\n              <div class=\"table-header mui-col-md-5\">Applications</div>\n              <div class=\"table-header mui-col-md-1\">Enabled</div>\n            </div>\n            <!-- if there are no virtue, show this message -->\n            <div *ngIf=\"vmList.length < 1\" class=\"mui-row margin-top-10\">\n              <div class=\"mui-col-md-12\">\n                <p class=\"no-data-message\">\n                  No virtual machines are attached this virtue. To add VM(s), click on the button \"Add VM\".\n                </p>\n              </div>\n            </div>\n            <div class=\"mui-row table-row\" *ngFor=\"let vm of vmList\" appActiveClass>\n              <div class=\"table-data mui-col-md-4\">\n                <a mat-button (click)=\"activateModal(vm)\">{{ vm.name }}</a>\n                <span class=\"menu-options\" *ngIf=\"vm.enabled\">\n                    <button>Disable</button> | <button mat-button (click)=\"removeVm(vm.id, i)\">Remove</button>\n                  </span>\n                <span class=\"menu-options\" *ngIf=\"vm.enabled===false\">\n                    <button>Enable</button> | <button mat-button (click)=\"removeVm(vm.id, i)\">Remove</button>\n                  </span>\n              </div>\n              <div class=\"table-data mui-col-md-2\">{{ vm.os }}</div>\n              <div class=\"table-data mui-col-md-5\">\n                <ul class=\"padding-left-5\">\n                  <li *ngFor=\"let id of vm.applicationIds\">{{ getAppName(id) }}</li>\n                </ul>\n              </div>\n              <div class=\"table-data mui-col-md-1\">{{ vm.enabled ? 'Enabled':'Disabled' }} </div>\n              <div class=\"clearfix\"></div>\n            </div>\n          </div>\n          <div class=\"mui-container-fluid\">\n            <div class=\"mui-row paging\">\n              <div class=\"mui-col-md-4 page-number padding-left-0\">&nbsp;</div>\n              <div class=\"mui-col-md-4 page-controls\">&nbsp;</div>\n              <div class=\"mui-col-md-4 page-item-total padding-right-0\"># Virtual Machine(s)</div>\n              <div class=\"clearfix\"></div>\n            </div>\n          </div>\n        </div>\n\n        <div class=\"split-pane-content-secondary\">\n          <div id=\"settings\" class=\"virtue-settings\">\n            <div class=\"virtue-titlebar\">\n              <h3> Virtue Settings</h3>\n            </div>\n            <app-virtue-settings></app-virtue-settings>\n          </div>\n        </div>\n      </vertical-split-pane>\n      <div class=\"mui-row border-top\">\n        <div class=\"mui-col-md-4\">&nbsp;</div>\n        <div class=\"mui-col-md-4 form-item text-align-center\">\n          <button class=\"button-submit\" type=\"submit\" (click)=\"duplicateThisVirtue(virtueData.id, virtueName.value, virtueVersion.value)\">Duplicate and Save</button>\n          <button class=\"button-cancel\" type=\"cancel\">Cancel</button>\n        </div>\n        <div class=\"mui-col-md-4\"></div>\n      </div>\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/virtues/duplicate-virtue/duplicate-virtue.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/virtues/duplicate-virtue/duplicate-virtue.component.ts ***!
  \************************************************************************/
/*! exports provided: DuplicateVirtueComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DuplicateVirtueComponent", function() { return DuplicateVirtueComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _vm_modal_vm_modal_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../vm-modal/vm-modal.component */ "./src/app/virtues/vm-modal/vm-modal.component.ts");
/* harmony import */ var _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../shared/services/baseUrl.service */ "./src/app/shared/services/baseUrl.service.ts");
/* harmony import */ var _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../shared/services/applications.service */ "./src/app/shared/services/applications.service.ts");
/* harmony import */ var _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../shared/services/virtues.service */ "./src/app/shared/services/virtues.service.ts");
/* harmony import */ var _shared_services_vm_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../shared/services/vm.service */ "./src/app/shared/services/vm.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









var DuplicateVirtueComponent = /** @class */ (function () {
    function DuplicateVirtueComponent(activatedRoute, router, appsService, baseUrlService, virtuesService, vmService, dialog) {
        this.activatedRoute = activatedRoute;
        this.router = router;
        this.appsService = appsService;
        this.baseUrlService = baseUrlService;
        this.virtuesService = virtuesService;
        this.vmService = vmService;
        this.dialog = dialog;
        this.virtueData = [];
        this.vmList = [];
        this.appsList = [];
        this.selVmsList = [];
        this.pageVmList = [];
        this.virtueForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]();
    }
    DuplicateVirtueComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.virtueId = {
            id: this.activatedRoute.snapshot.params['id']
        };
        this.router.routeReuseStrategy.shouldReuseRoute = function () {
            return false;
        };
        this.baseUrlService.getBaseUrl().subscribe(function (res) {
            var awsServer = res[0].aws_server;
            _this.getBaseUrl(awsServer);
            _this.getThisVirtue(awsServer, _this.virtueId.id);
            _this.getAppsList(awsServer);
            if (_this.pageVmList.length > 0) {
                _this.getVirtueVmList(_this.pageVmList);
            }
        });
        this.refreshData();
    };
    DuplicateVirtueComponent.prototype.intercept = function (req, next) {
        return next.handle(req);
    };
    DuplicateVirtueComponent.prototype.getBaseUrl = function (url) {
        this.baseUrl = url;
    };
    DuplicateVirtueComponent.prototype.refreshData = function () {
        var _this = this;
        setTimeout(function () {
            _this.router.navigated = false;
            _this.getThisVirtue(_this.baseUrl, _this.virtueId.id);
        }, 1000);
    };
    DuplicateVirtueComponent.prototype.getThisVirtue = function (baseUrl, id) {
        var _this = this;
        this.virtuesService.getVirtue(baseUrl, id).subscribe(function (data) {
            _this.virtueData = data;
            _this.pageVmList = data.virtualMachineTemplateIds;
            _this.virtueEnabled = data.enabled;
            _this.getVirtueVmList(data.virtualMachineTemplateIds);
            _this.virtueData['name'] = 'Copy of ' + _this.virtueData['name'];
        });
    };
    DuplicateVirtueComponent.prototype.getVirtueVmList = function (virtueVms) {
        var _this = this;
        // loop through the selected VM list
        var selectedVm = this.pageVmList;
        for (var _i = 0, selectedVm_1 = selectedVm; _i < selectedVm_1.length; _i++) {
            var id = selectedVm_1[_i];
            this.vmService.getVM(this.baseUrl, id).subscribe(function (data) {
                _this.vmList.push(data);
            }, function (error) {
                console.log(error.message);
            });
        }
    };
    DuplicateVirtueComponent.prototype.getAppsList = function (baseUrl) {
        var _this = this;
        this.appsService.getAppsList(baseUrl).subscribe(function (data) {
            _this.appsList = data;
        });
    };
    DuplicateVirtueComponent.prototype.getAppName = function (id) {
        var app = this.appsList.filter(function (data) { return id === data.id; });
        if (id !== null) {
            return app[0].name;
        }
    };
    DuplicateVirtueComponent.prototype.getUpdatedVmList = function (baseUrl) {
        var _this = this;
        this.vmList = [];
        this.vmService.getVmList(baseUrl).subscribe(function (data) {
            for (var _i = 0, _a = _this.pageVmList; _i < _a.length; _i++) {
                var sel = _a[_i];
                for (var _b = 0, data_1 = data; _b < data_1.length; _b++) {
                    var vm = data_1[_b];
                    if (sel === vm.id) {
                        _this.vmList.push(vm);
                        break;
                    }
                }
            }
        });
    };
    DuplicateVirtueComponent.prototype.removeVm = function (id, index) {
        this.vmList = this.vmList.filter(function (data) {
            return data.id !== id;
        });
        this.pageVmList.splice(index, 1);
    };
    DuplicateVirtueComponent.prototype.duplicateThisVirtue = function (id, virtueName, virtueVersion) {
        var body = {
            'name': virtueName,
            'version': virtueVersion,
            'enabled': this.virtueEnabled,
            'lastEditor': 'admin',
            'virtualMachineTemplateIds': this.pageVmList
        };
        this.virtuesService.createVirtue(this.baseUrl, JSON.stringify(body)).subscribe(function (data) {
            return true;
        }, function (error) {
            console.log(error);
        });
        this.router.navigate(['/virtues']);
    };
    DuplicateVirtueComponent.prototype.virtueStatus = function (id, isEnabled) {
        if (isEnabled) {
            this.virtueEnabled = false;
        }
        else {
            this.virtueEnabled = true;
        }
        // let body = {
        //   'enabled': this.virtueEnabled,
        // };
        this.virtuesService.toggleVirtueStatus(this.baseUrl, id);
        this.refreshData();
    };
    DuplicateVirtueComponent.prototype.activateModal = function () {
        var _this = this;
        var dialogRef = this.dialog.open(_vm_modal_vm_modal_component__WEBPACK_IMPORTED_MODULE_4__["VmModalComponent"], {
            width: '750px',
            data: {
                selectedVms: this.pageVmList
            }
        });
        dialogRef.updatePosition({ top: '5%', left: '20%' });
        var vms = dialogRef.componentInstance.addVms.subscribe(function (data) {
            _this.selVmsList = data;
            if (_this.pageVmList.length > 0) {
                _this.pageVmList = [];
            }
            _this.pageVmList = _this.selVmsList;
            _this.getVirtueVmList(_this.pageVmList);
        });
    };
    DuplicateVirtueComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-duplicate-virtue',
            template: __webpack_require__(/*! ./duplicate-virtue.component.html */ "./src/app/virtues/duplicate-virtue/duplicate-virtue.component.html"),
            providers: [_shared_services_applications_service__WEBPACK_IMPORTED_MODULE_6__["ApplicationsService"], _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_5__["BaseUrlService"], _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_7__["VirtuesService"], _shared_services_vm_service__WEBPACK_IMPORTED_MODULE_8__["VirtualMachineService"]]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_6__["ApplicationsService"],
            _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_5__["BaseUrlService"],
            _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_7__["VirtuesService"],
            _shared_services_vm_service__WEBPACK_IMPORTED_MODULE_8__["VirtualMachineService"],
            _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatDialog"]])
    ], DuplicateVirtueComponent);
    return DuplicateVirtueComponent;
}());



/***/ }),

/***/ "./src/app/virtues/edit-virtue/edit-virtue.component.css":
/*!***************************************************************!*\
  !*** ./src/app/virtues/edit-virtue/edit-virtue.component.css ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n.virtue-form {\n  margin-top: 1.5rem;\n  padding: 1.5rem 0 1rem;\n}\n.virtue-form p {\n  display: block;\n  margin: 1rem 0;\n}\n.virtue-options {\n  cursor: pointer;\n  display: block;\n  font-size: 0.88rem;\n  clear: both;\n}\nvertical-split-pane {\n  border-top: 1px solid #b2b2b2;\n  border-right: 1px solid #b2b2b2;\n  display: flex;\n  flex-direction: column;\n  align-content: stretch;\n}\nvertical-split-pane:after {\n  clear: bloth;\n  content: ' ';\n  display: block;\n  height: 0;\n}\n.v-outer {\n  border-bottom: 1px solid #B2B2B2;\n  display: flex;\n  flex-direction: column;\n  align-items: stretch;\n  height: 100%;\n}\n.split-pane-content-primary {\n  max-height: 700px;\n  min-height: 480px;\n  overflow-y: scroll;\n  padding-top: 1rem;\n  padding-bottom: 1rem;\n  padding-right: 1.2rem;\n}\n.split-pane-content-secondary {\n  background-color: rgba(233,227,230,0.5);\n  height: 100%;\n  min-height: 480px;\n  overflow-y: scroll;\n}\n.icon-upload {\n  display: block;\n  min-width: 300px;\n}\n.virtue-list .mui-row {\n  border-bottom: 1px solid #B2B2B2;\n}\n.virtue-settings {\n  box-sizing: content-box;\n}\n.virtue-settings .virtue-titlebar {\n  padding-left: 2rem;\n}\n"

/***/ }),

/***/ "./src/app/virtues/edit-virtue/edit-virtue.component.html":
/*!****************************************************************!*\
  !*** ./src/app/virtues/edit-virtue/edit-virtue.component.html ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"content-container\">\n  <div id=\"content-header\" class=\"titlebar\">\n    <h1 class=\"titlebar-title\">Edit Virtue</h1>\n    <button (click)=\"virtueStatus(virtueData.id, virtueEnabled)\" class=\"titlebar-button\">{{ virtueEnabled ? 'Disable Virtue' : 'Enable Virtue' }}</button>\n  </div>\n  <div id=\"content-main\">\n      <div id=\"content\" class=\"border-top virtue-content\">\n        <vertical-split-pane\n          primary-component-minsize=\"60\"\n          secondary-component-minsize=\"40\"\n          [primary-component-toggled-off]=\"false\"\n          local-storage-key=\"split-pane\"\n          primary-component-initialratio=\"0.8\">\n\n          <div class=\"split-pane-content-primary\">\n\n            <div class=\"mui-row form-item margin-top-15\">\n              <div class=\"mui-col-md-12\">\n                <input type=\"text\" #virtueName [(value)]=\"virtueData.name\" placeholder=\"Virtue Name\" matInput />\n                <br />\n                <span style=\"clear: both;color: #ccc; font-size:10px;margin-top:5px;\">ID: {{ virtueId.id }}</span>\n              </div>\n            </div>\n            <div class=\"mui-row form-item margin-top-15\">\n              <div class=\"mui-col-md-1\">\n                <label>Version: </label>\n              </div>\n              <div class=\"mui-col-md-2\">\n                <input type=\"text\" #virtueVersion [(value)]=\"virtueData.version\"  matInput />\n              </div>\n            </div>\n            <div class=\"mui-row titlebar\">\n              <div class=\"mui-col-md-12\">\n                <h2 class=\"titlebar-title\">Virtual Machines</h2>\n                <button mat-button class=\"titlebar-button\" (click)=\"activateModal(virtueData.id)\">Add VM</button>\n              </div>\n            </div>\n            <!-- if there are virtual machines, show this list -->\n            <div class=\"mui-container-fluid data-list\">\n              <div class=\"mui-row table-header-group\">\n                <div class=\"table-header mui-col-md-4\">VM</div>\n                <div class=\"table-header mui-col-md-2\">OS</div>\n                <div class=\"table-header mui-col-md-5\">Applications</div>\n                <div class=\"table-header mui-col-md-1\">Enabled</div>\n              </div>\n              <!-- if there are no virtue, show this message -->\n              <div *ngIf=\"vmList.length < 1\" class=\"mui-row margin-top-10\">\n                <div class=\"mui-col-md-12\">\n                  <p class=\"no-data-message\">\n                    No virtual machines are attached this virtue. To add VM(s), click on the button \"Add VM\".\n                  </p>\n                </div>\n              </div>\n              <div class=\"mui-row table-row\" *ngFor=\"let vm of vmList\" appActiveClass>\n                <div class=\"table-data mui-col-md-4\">\n                  <a mat-button (click)=\"activateModal(vm)\">{{ vm.name }}</a>\n                  <span class=\"menu-options\" *ngIf=\"vm.enabled\">\n                    <button>Disable</button> | <button mat-button (click)=\"removeVm(vm.id, i)\">Remove</button>\n                  </span>\n                  <span class=\"menu-options\" *ngIf=\"vm.enabled===false\">\n                    <button>Enable</button> | <button mat-button (click)=\"removeVm(vm.id, i)\">Remove</button>\n                  </span>\n                </div>\n                <div class=\"table-data mui-col-md-2\">{{ vm.os }}</div>\n                <div class=\"table-data mui-col-md-5\">\n                  <ul class=\"padding-left-5\">\n                    <li *ngFor=\"let id of vm.applicationIds\">{{ getAppName(id) }}</li>\n                  </ul>\n                </div>\n                <div class=\"table-data mui-col-md-1\">{{ vm.enabled ? 'Enabled':'Disabled' }} </div>\n                <div class=\"clearfix\"></div>\n              </div>\n            </div>\n            <div class=\"mui-container-fluid\">\n              <div class=\"mui-row paging\">\n                <div class=\"mui-col-md-4 page-number padding-left-0\">&nbsp;</div>\n                <div class=\"mui-col-md-4 page-controls\">&nbsp;</div>\n                <div class=\"mui-col-md-4 page-item-total padding-right-0\"># Virtual Machine(s)</div>\n                <div class=\"clearfix\"></div>\n              </div>\n            </div>\n          </div>\n\n          <div class=\"split-pane-content-secondary\">\n            <div id=\"settings\" class=\"virtue-settings\">\n              <div class=\"virtue-titlebar\">\n                <h3> Virtue Settings</h3>\n              </div>\n              <app-virtue-settings></app-virtue-settings>\n            </div>\n          </div>\n        </vertical-split-pane>\n        <div class=\"mui-row border-top\">\n          <div class=\"mui-col-md-4\">&nbsp;</div>\n          <div class=\"mui-col-md-4 form-item text-align-center\">\n            <button class=\"button-submit\" type=\"submit\" (click)=\"updateThisVirtue(virtueData.id, virtueName.value, virtueVersion.value)\">Save</button>\n            <button class=\"button-cancel\" type=\"cancel\">Cancel</button>\n          </div>\n          <div class=\"mui-col-md-4\"></div>\n        </div>\n      </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/virtues/edit-virtue/edit-virtue.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/virtues/edit-virtue/edit-virtue.component.ts ***!
  \**************************************************************/
/*! exports provided: EditVirtueComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditVirtueComponent", function() { return EditVirtueComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../shared/services/applications.service */ "./src/app/shared/services/applications.service.ts");
/* harmony import */ var _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../shared/services/baseUrl.service */ "./src/app/shared/services/baseUrl.service.ts");
/* harmony import */ var _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../shared/services/virtues.service */ "./src/app/shared/services/virtues.service.ts");
/* harmony import */ var _shared_services_vm_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../shared/services/vm.service */ "./src/app/shared/services/vm.service.ts");
/* harmony import */ var _vm_modal_vm_modal_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../vm-modal/vm-modal.component */ "./src/app/virtues/vm-modal/vm-modal.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};










var EditVirtueComponent = /** @class */ (function () {
    function EditVirtueComponent(activatedRoute, router, appsService, baseUrlService, virtuesService, vmService, location, dialog) {
        this.activatedRoute = activatedRoute;
        this.router = router;
        this.appsService = appsService;
        this.baseUrlService = baseUrlService;
        this.virtuesService = virtuesService;
        this.vmService = vmService;
        this.location = location;
        this.dialog = dialog;
        this.virtueData = [];
        this.vmInfo = [];
        this.vmList = [];
        this.appsList = [];
        this.selVmsList = [];
        this.pageVmList = [];
        this.virtueForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]();
    }
    EditVirtueComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.virtueId = {
            id: this.activatedRoute.snapshot.params['id']
        };
        this.router.routeReuseStrategy.shouldReuseRoute = function () {
            return false;
        };
        this.baseUrlService.getBaseUrl().subscribe(function (res) {
            var awsServer = res[0].aws_server;
            _this.getBaseUrl(awsServer);
            _this.getThisVirtue(awsServer, _this.virtueId.id);
            _this.getAppsList(awsServer);
            if (_this.pageVmList.length > 0) {
                _this.getVirtueVmList(_this.pageVmList);
            }
        });
    };
    EditVirtueComponent.prototype.intercept = function (req, next) {
        return next.handle(req);
    };
    EditVirtueComponent.prototype.getBaseUrl = function (url) {
        this.baseUrl = url;
    };
    EditVirtueComponent.prototype.resetRouter = function () {
        var _this = this;
        setTimeout(function () {
            _this.router.navigated = false;
        }, 1000);
    };
    EditVirtueComponent.prototype.getThisVirtue = function (baseUrl, id) {
        var _this = this;
        this.virtuesService.getVirtue(baseUrl, id).subscribe(function (data) {
            _this.virtueData = data;
            _this.pageVmList = data.virtualMachineTemplateIds;
            _this.virtueEnabled = data.enabled;
            _this.getVirtueVmList(data.virtualMachineTemplateIds);
        });
    };
    EditVirtueComponent.prototype.getVirtueVmList = function (virtueVms) {
        var _this = this;
        // loop through the selected VM list
        var selectedVm = this.pageVmList;
        for (var _i = 0, selectedVm_1 = selectedVm; _i < selectedVm_1.length; _i++) {
            var id = selectedVm_1[_i];
            this.vmService.getVM(this.baseUrl, id).subscribe(function (data) {
                _this.vmList.push(data);
            }, function (error) {
                console.log(error.message);
            });
        }
    };
    EditVirtueComponent.prototype.getVmInfo = function (id, prop) {
        var vm = this.vmList.filter(function (data) { return id === data.id; });
        if (id !== null) {
            if (prop === 'name') {
                return vm[0].name;
            }
            else if (prop === 'os') {
                return vm[0].os;
            }
        }
    };
    EditVirtueComponent.prototype.getAppsList = function (baseUrl) {
        var _this = this;
        this.appsService.getAppsList(baseUrl).subscribe(function (data) {
            _this.appsList = data;
        });
    };
    EditVirtueComponent.prototype.getAppName = function (id) {
        var app = this.appsList.filter(function (data) { return id === data.id; });
        if (id !== null) {
            return app[0].name;
        }
    };
    EditVirtueComponent.prototype.getUpdatedVmList = function (baseUrl) {
        var _this = this;
        this.vmList = [];
        this.vmService.getVmList(baseUrl)
            .subscribe(function (data) {
            for (var _i = 0, _a = _this.pageVmList; _i < _a.length; _i++) {
                var sel = _a[_i];
                for (var _b = 0, data_1 = data; _b < data_1.length; _b++) {
                    var vm = data_1[_b];
                    if (sel === vm.id) {
                        _this.vmList.push(vm);
                        break;
                    }
                }
            }
        });
    };
    EditVirtueComponent.prototype.removeVm = function (id, index) {
        this.vmList = this.vmList.filter(function (data) {
            return data.id !== id;
        });
        // console.log(this.vmList);
        this.pageVmList.splice(index, 1);
    };
    EditVirtueComponent.prototype.activateModal = function () {
        var _this = this;
        var dialogRef = this.dialog.open(_vm_modal_vm_modal_component__WEBPACK_IMPORTED_MODULE_9__["VmModalComponent"], {
            width: '750px',
            data: {
                selectedVms: this.pageVmList
            }
        });
        dialogRef.updatePosition({ top: '5%', left: '20%' });
        var vms = dialogRef.componentInstance.addVms.subscribe(function (data) {
            _this.selVmsList = data;
            if (_this.pageVmList.length > 0) {
                _this.pageVmList = [];
            }
            _this.pageVmList = _this.selVmsList;
            _this.getVirtueVmList(_this.pageVmList);
        });
        // dialogRef.afterClosed().subscribe(() => {
        //   vms.unsubscribe();
        // });
    };
    EditVirtueComponent.prototype.updateThisVirtue = function (id, virtueName, virtueVersion) {
        var body = {
            'name': virtueName,
            'version': virtueVersion,
            'enabled': this.virtueEnabled,
            'virtualMachineTemplateIds': this.pageVmList
        };
        this.virtuesService.updateVirtue(this.baseUrl, id, JSON.stringify(body)).subscribe(function (data) {
            // console.log('Updating ' + data.name + '(' + data.id + ')');
            return true;
        }, function (error) {
            console.log(error);
        });
        this.resetRouter();
        this.router.navigate(['/virtues']);
    };
    EditVirtueComponent.prototype.virtueStatus = function (id, isEnabled) {
        if (isEnabled) {
            this.virtueEnabled = false;
        }
        else {
            this.virtueEnabled = true;
        }
    };
    EditVirtueComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-edit-virtue',
            template: __webpack_require__(/*! ./edit-virtue.component.html */ "./src/app/virtues/edit-virtue/edit-virtue.component.html"),
            styles: [__webpack_require__(/*! ./edit-virtue.component.css */ "./src/app/virtues/edit-virtue/edit-virtue.component.css")],
            providers: [_shared_services_applications_service__WEBPACK_IMPORTED_MODULE_5__["ApplicationsService"], _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_6__["BaseUrlService"], _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_7__["VirtuesService"], _shared_services_vm_service__WEBPACK_IMPORTED_MODULE_8__["VirtualMachineService"]]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_5__["ApplicationsService"],
            _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_6__["BaseUrlService"],
            _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_7__["VirtuesService"],
            _shared_services_vm_service__WEBPACK_IMPORTED_MODULE_8__["VirtualMachineService"],
            _angular_common__WEBPACK_IMPORTED_MODULE_1__["Location"],
            _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatDialog"]])
    ], EditVirtueComponent);
    return EditVirtueComponent;
}());



/***/ }),

/***/ "./src/app/virtues/virtue-list/virtue-list.component.css":
/*!***************************************************************!*\
  !*** ./src/app/virtues/virtue-list/virtue-list.component.css ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".virtues-filter {\n  padding: 0 0 0.75rem;\n}\n\n.virtue-options {\n  cursor: pointer;\n  display: block;\n  font-family: 'Raleway-medium', Arial, sans-serif;\n  font-size: 0.88rem;\n  clear: both;\n}\n"

/***/ }),

/***/ "./src/app/virtues/virtue-list/virtue-list.component.html":
/*!****************************************************************!*\
  !*** ./src/app/virtues/virtue-list/virtue-list.component.html ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"content-container\">\n  <div id=\"content-header\" class=\"titlebar\">\n    <h1 class=\"titlebar-title\">Virtues</h1>\n    <button mat-button class=\"titlebar-button\" routerLink=\"/virtues/create-virtue\">Create New</button>\n    <button mat-button class=\"titlebar-button\" disabled>Import Virtue</button>\n  </div>\n\n  <div id=\"content-main\">\n    <div id=\"content\">\n      <!-- if there are virtues, show this list -->\n      <div class=\"mui-container-fluid\" *ngIf=\"virtues.length > 0\">\n        <div class=\"mui-row virtues-filters\">\n          <div class=\"virtues-filter mui-col-md-12 padding-left-0\">\n            <a *ngIf=\"sortValue !== '*'\" (click)=\"enabledVirtueList('enabled', '*', sortBy)\">All Virtues</a>\n            <span *ngIf=\"sortValue === '*'\">All Virtues</span> |\n            <a *ngIf=\"sortValue !== true\" (click)=\"enabledVirtueList('enabled', true, sortBy)\">Enabled Virtues</a>\n            <span *ngIf=\"sortValue === true\">Enabled Virtues</span> |\n            <a *ngIf=\"sortValue !== false\" (click)=\"enabledVirtueList('enabled', false, sortBy)\">Disabled Virtues</a>\n            <span *ngIf=\"sortValue === false\">Disabled Virtues</span>\n          </div>\n        </div>\n      </div>\n      <div class=\"mui-container-fluid data-list\">\n        <div class=\"mui-row table-header-group\">\n          <div class=\"table-header mui-col-md-2\">\n            <a class=\"sortName\" (click)=\"sortVirtueColumns('name',sortBy)\">Virtue Name</a>\n            <span class=\"list-sorter\">\n              <span *ngIf=\"sortColumn === 'name' && sortBy === 'asc'\" class=\"fa fa-sort-up\"></span>\n              <span *ngIf=\"sortColumn === 'name' && sortBy === 'desc'\" class=\"fa fa-sort-down\"></span>\n              <span class=\"fa fa-sort font-color-gray\"></span>\n            </span>\n          </div>\n          <div class=\"table-header mui-col-md-3\">Virtual Machines</div>\n          <div class=\"table-header mui-col-md-3\">Apps</div>\n          <div class=\"table-header mui-col-md-2\">Created By</div>\n          <div class=\"table-header mui-col-md-2\">\n            <a class=\"sortDate\" (click)=\"sortVirtueColumns('date',sortBy)\">Date</a>\n            <span class=\"list-sorter\">\n              <span *ngIf=\"sortColumn === 'date' && sortBy === 'asc'\" class=\"fa fa-sort-up\"></span>\n              <span *ngIf=\"sortColumn === 'date' && sortBy === 'desc'\" class=\"fa fa-sort-down\"></span>\n              <span class=\"fa fa-sort font-color-gray\"></span>\n            </span>\n          </div>\n        </div>\n        <!-- if there are no virtues, show this message -->\n        <div class=\"mui-row margin-top-10\" *ngIf=\"virtues.length < 1\">\n          <div class=\"mui-col-md-12 padding-left-0\">\n            <p class=\"no-data-message\">\n              No virtues have been created at this time. To create a virtue, click on the button \"Create New\" above.\n            </p>\n          </div>\n        </div>\n        <div *ngFor=\"let virtue of virtues | listFilter : sortColumn : sortType : sortValue : sortBy\" class=\"mui-row table-row\" appActiveClass>\n          <div class=\"table-data mui-col-md-2\">\n            <a class=\"edit\" routerLink=\"/virtues/edit/{{virtue.id}}\">{{ virtue.name }}</a>\n\n            <!-- if this virtue is enabled show this menu -->\n            <span *ngIf=\"virtue.enabled\" class=\"menu-options\">\n              <a mat-button (click)=\"virtueStatus(virtue.id, virtue.enabled)\">Disable</a> |\n               <a mat-button routerLink=\"/virtues/duplicate/{{virtue.id}}\">Duplicate</a>\n            </span>\n\n            <!-- if this virtue is disabled show this menu -->\n            <span *ngIf=\"virtue.enabled==false\" class=\"menu-options\">\n              <a mat-button (click)=\"virtueStatus(virtue.id)\">Enable</a> |\n              <a mat-button (click)=\"openDialog(virtue.id,'delete','virtue',virtue.name)\">Delete</a>\n            </span>\n          </div>\n          <div class=\"table-data mui-col-md-3\"><!-- virtue.vmTemplates[0].os -->\n            <ul>\n              <li *ngFor=\"let vm of virtue.virtualMachineTemplateIds\">{{ getVmName(vm) }}</li>\n            </ul>\n          </div>\n          <div class=\"table-data mui-col-md-3\">\n            <ul>\n              <li *ngFor=\"let app of virtue.applicationIds\">{{ getAppName(app) }}</li>\n            </ul>\n          </div>\n          <div class=\"table-data mui-col-md-2\">{{virtue.lastEditor}}</div>\n          <div class=\"table-data mui-col-md-2\">\n            {{virtue.enabled ? 'Enabled' : 'Disabled'}}<br />\n            {{virtue.lastModification | date:'short' }}\n          </div>\n          <div class=\"clearfix\"></div>\n        </div>\n      </div>\n      <!-- <div class=\"paging\">\n        <div class=\"page-number mui-col-md-4\">Page # of #</div>\n        <div class=\"page-controls mui-col-md-4\"><< First | < Previous | Next > | Last >></div>\n        <div class=\"page-item-total mui-col-md-4\"># Virtues</div>\n        <div class=\"clearfix\"></div>\n      </div> -->\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/virtues/virtue-list/virtue-list.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/virtues/virtue-list/virtue-list.component.ts ***!
  \**************************************************************/
/*! exports provided: VirtueListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VirtueListComponent", function() { return VirtueListComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _dialogs_dialogs_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../dialogs/dialogs.component */ "./src/app/dialogs/dialogs.component.ts");
/* harmony import */ var _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/services/baseUrl.service */ "./src/app/shared/services/baseUrl.service.ts");
/* harmony import */ var _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../shared/services/virtues.service */ "./src/app/shared/services/virtues.service.ts");
/* harmony import */ var _shared_services_vm_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../shared/services/vm.service */ "./src/app/shared/services/vm.service.ts");
/* harmony import */ var _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../shared/services/applications.service */ "./src/app/shared/services/applications.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};








var VirtueListComponent = /** @class */ (function () {
    function VirtueListComponent(router, appsService, baseUrlService, virtuesService, vmService, dialog) {
        this.router = router;
        this.appsService = appsService;
        this.baseUrlService = baseUrlService;
        this.virtuesService = virtuesService;
        this.vmService = vmService;
        this.dialog = dialog;
        this.title = 'Virtues';
        this.virtues = [];
        this.vmList = [];
        this.appsList = [];
        // these are the default properties the list sorts by
        this.sortColumn = 'name';
        this.sortType = 'enabled';
        this.sortValue = '*';
        this.sortBy = 'asc';
        this.router.routeReuseStrategy.shouldReuseRoute = function () {
            return false;
        };
    }
    VirtueListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.baseUrlService.getBaseUrl().subscribe(function (res) {
            var awsServer = res[0].aws_server;
            _this.getBaseUrl(awsServer);
            _this.getVirtues(awsServer);
            _this.getApplications(awsServer);
            _this.getVmList(awsServer);
        });
        this.refreshData();
    };
    VirtueListComponent.prototype.intercept = function (req, next) {
        return next.handle(req);
    };
    VirtueListComponent.prototype.resetRouter = function () {
        var _this = this;
        setTimeout(function () {
            _this.router.navigated = false;
        }, 1000);
    };
    VirtueListComponent.prototype.getBaseUrl = function (url) {
        this.baseUrl = url;
    };
    VirtueListComponent.prototype.refreshData = function () {
        var _this = this;
        setTimeout(function () {
            _this.router.navigated = false;
            _this.getVirtues(_this.baseUrl);
        }, 1000);
    };
    VirtueListComponent.prototype.getVirtues = function (baseUrl) {
        var _this = this;
        this.virtuesService.getVirtues(baseUrl).subscribe(function (data) {
            _this.virtues = data;
        });
        this.sortVirtues(this.sortBy);
    };
    VirtueListComponent.prototype.sortVirtues = function (sortDirection) {
        if (sortDirection === 'asc') {
            this.virtues.sort(function (leftSide, rightSide) {
                if (leftSide['name'] < rightSide['name']) {
                    return -1;
                }
                if (leftSide['name'] > rightSide['name']) {
                    return 1;
                }
                return 0;
            });
        }
        else {
            this.virtues.sort(function (leftSide, rightSide) {
                if (leftSide['name'] < rightSide['name']) {
                    return 1;
                }
                if (leftSide['name'] > rightSide['name']) {
                    return -1;
                }
                return 0;
            });
        }
    };
    VirtueListComponent.prototype.enabledVirtueList = function (sortType, enabledValue, sortBy) {
        console.log('enabledVirtueList() => ' + enabledValue);
        if (this.sortValue !== enabledValue) {
            this.sortBy = 'asc';
        }
        else {
            this.sortListBy(sortBy);
        }
        this.sortValue = enabledValue;
        this.sortType = sortType;
    };
    VirtueListComponent.prototype.sortVirtueColumns = function (sortColumn, sortBy) {
        if (this.sortColumn === sortColumn) {
            this.sortListBy(sortBy);
        }
        else {
            if (sortColumn === 'name') {
                this.sortBy = 'asc';
                this.sortColumn = sortColumn;
            }
            else if (sortColumn === 'date') {
                this.sortColumn = sortColumn;
                this.sortBy = 'desc';
            }
        }
    };
    VirtueListComponent.prototype.sortListBy = function (sortDirection) {
        if (sortDirection === 'asc') {
            this.sortBy = 'desc';
        }
        else {
            this.sortBy = 'asc';
        }
    };
    VirtueListComponent.prototype.getApplications = function (baseUrl) {
        var _this = this;
        this.appsService.getAppsList(baseUrl).subscribe(function (apps) {
            _this.appsList = apps;
            // this.getAppsList(data);
        });
    };
    VirtueListComponent.prototype.getVmList = function (baseUrl) {
        var _this = this;
        this.vmService.getVmList(baseUrl).subscribe(function (vms) {
            _this.vmList = vms;
        });
    };
    VirtueListComponent.prototype.getAppName = function (id) {
        for (var _i = 0, _a = this.appsList; _i < _a.length; _i++) {
            var app = _a[_i];
            if (id === app.id) {
                return app.name;
            }
        }
    };
    VirtueListComponent.prototype.getVmName = function (id) {
        for (var _i = 0, _a = this.vmList; _i < _a.length; _i++) {
            var vm = _a[_i];
            if (id === vm.id) {
                return vm.name;
            }
        }
    };
    VirtueListComponent.prototype.virtueStatus = function (id) {
        var _this = this;
        this.virtuesService.toggleVirtueStatus(this.baseUrl, id).subscribe(function (data) {
            _this.virtue = data;
        });
        this.resetRouter();
        this.router.navigate(['/virtues']);
    };
    VirtueListComponent.prototype.deleteVirtue = function (id) {
        // console.log('deleting ' + id);
        this.virtuesService.deleteVirtue(this.baseUrl, id);
        this.refreshData();
    };
    VirtueListComponent.prototype.openDialog = function (id, type, category, description) {
        var _this = this;
        var dialogRef = this.dialog.open(_dialogs_dialogs_component__WEBPACK_IMPORTED_MODULE_3__["DialogsComponent"], {
            width: '450px',
            data: {
                dialogType: type,
                dialogCategory: category,
                dialogId: id,
                dialogDescription: description
            }
        });
        dialogRef.updatePosition({ top: '15%', left: '36%' });
        var dialogResults = dialogRef.componentInstance.dialogEmitter.subscribe(function (data) {
            console.log('Dialog Emitter: ' + data);
            if (type === 'delete') {
                _this.deleteVirtue(data);
            }
        });
    };
    VirtueListComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-virtue-list',
            providers: [_shared_services_applications_service__WEBPACK_IMPORTED_MODULE_7__["ApplicationsService"], _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_4__["BaseUrlService"], _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_5__["VirtuesService"], _shared_services_vm_service__WEBPACK_IMPORTED_MODULE_6__["VirtualMachineService"]],
            template: __webpack_require__(/*! ./virtue-list.component.html */ "./src/app/virtues/virtue-list/virtue-list.component.html"),
            styles: [__webpack_require__(/*! ./virtue-list.component.css */ "./src/app/virtues/virtue-list/virtue-list.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_7__["ApplicationsService"],
            _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_4__["BaseUrlService"],
            _shared_services_virtues_service__WEBPACK_IMPORTED_MODULE_5__["VirtuesService"],
            _shared_services_vm_service__WEBPACK_IMPORTED_MODULE_6__["VirtualMachineService"],
            _angular_material__WEBPACK_IMPORTED_MODULE_1__["MatDialog"]])
    ], VirtueListComponent);
    return VirtueListComponent;
}());



/***/ }),

/***/ "./src/app/virtues/virtue-settings/virtue-settings.component.css":
/*!***********************************************************************!*\
  !*** ./src/app/virtues/virtue-settings/virtue-settings.component.css ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n.mui-tabs__bar {\n  background: transparent;\n  box-sizing: border-box;\n  padding: 0;\n}\n.mui-tabs__bar > li {\n  background: #BFBFBF;;\n  border: none;\n  border-top-left-radius: 3px;\n  border-top-right-radius: 3px;\n}\n.mui-tabs__bar > li.mui--is-active {\n  background: #FFF;\n  border-left: 1px solid #BFBFBF;\n  border-top: 1px solid #BFBFBF;\n  border-right: 1px solid #BFBFBF;\n  border-bottom: 1px solid #FFF;\n}\n.mui-tabs__bar > li > a {\n  color: #3E3F4E;\n  cursor: pointer;\n  height: 32px;\n  line-height: 32px;\n  text-transform: capitalize;\n}\n.mui-tabs__bar li a:hover {\n  text-decoration: underline;\n}\n.mui-tabs__pane {\n  background: #FFF;\n  border-top:1px solid #BFBFBF;\n  border-left:1px solid #BFBFBF;\n  margin-top: -2px;\n}\n.tab-pane-content {\n  overflow-y: scroll;\n}\n.tab-pane-content h3, .tab-pane-content h4, .tab-pane-content h5  {\n  margin-top: 0;\n}\n.tab-pane-content .table-header,\n.tab-pane-content .table-data {\n  font-size: 12px;\n}\ninput[type='color'] {\n  width: 20px;\n}\n.icon-upload  mat-form-field {\n  width: 100%;\n}\n.upload-file-input {\n  display: block;\n  float: left;\n  width: 14rem;\n}\n.upload-button {\n  background-color: #E9E3E6;\n  border: 1px solid #B2B2B2;\n  border-radius: 0;\n  display: block;\n  float:left;\n  margin: 0 0 0 -1px;\n  padding: 0.45rem 0.7rem;\n  text-align: center;\n  width: auto;\n}\na .fa {\n  color: #736F72;\n}\n.fa {\n   font-size: 1.2rem;\n }\n.table-header-group {\n  border: 1px solid #B2B2B2;\n  display: flex;\n  flex-direction: row;\n  align-items: stretch;\n}\n.table-header:first-child span {\n  margin-left: 0;\n  margin-right: 0;\n}\n"

/***/ }),

/***/ "./src/app/virtues/virtue-settings/virtue-settings.component.html":
/*!************************************************************************!*\
  !*** ./src/app/virtues/virtue-settings/virtue-settings.component.html ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ul class=\"mui-tabs__bar\">\n  <li class=\"mui--is-active\"><a data-mui-toggle=\"tab\" data-mui-controls=\"general\">General</a></li>\n  <li><a data-mui-toggle=\"tab\" data-mui-controls=\"network\">Network</a></li>\n  <li><a data-mui-toggle=\"tab\" data-mui-controls=\"resources\">Resources</a></li>\n  <li><a data-mui-toggle=\"tab\" data-mui-controls=\"sensors\">Sensors</a></li>\n</ul>\n<div class=\"mui-tabs__pane mui--is-active\" id=\"general\">\n  <div class=\"tab-pane-content\">\n    <h4>General Settings</h4>\n    <div class=\"mui-row form-item\">\n      <div class=\"mui-col-md-4 padding-left-0\"><label>Select Virtue Color</label></div>\n      <div class=\"mui-col-md-6 float-right\">\n        <input id=\"virtue-color\" type=\"color\" value=\"#4B3F72\" />\n      </div>\n    </div>\n    <div class=\"mui-row form-item\">\n      <div class=\"mui-col-md-4 padding-left-0\"><label>Customize Icon</label></div>\n      <div class=\"mui-col-md-8 icon-upload\">\n        <mat-form-field>\n          <input matInput type=\"text\" id=\"icon-file\" class=\"upload-file-input\" name=\"icon\" />\n          <button mat-button class=\"upload-button\">upload</button>\n        </mat-form-field>\n      </div>\n    </div>\n    <div class=\"mui-row form-item\">\n      <h5>Inter-Virtue Settings</h5>\n      <div class=\"mui-col-md-12\">\n        <div class=\"mui-row table-header-group\">\n          <div class=\"table-header mui-col-md-6\"><span>Virtue</span></div>\n          <div class=\"table-header mui-col-md-2 text-align-center\"><span>Read</span></div>\n          <div class=\"table-header mui-col-md-2 text-align-center\"><span>Write</span></div>\n          <div class=\"table-header mui-col-md-2 text-align-center\"><span>Open Browser</span></div>\n        </div>\n        <div class=\"mui-row\">\n          <div class=\"table-data mui-col-md-6\">Virtue Name</div>\n          <div class=\"table-data mui-col-md-2 text-align-center\">\n            <mat-checkbox name=\"read-[id]\"></mat-checkbox>\n          </div>\n          <div class=\"table-data mui-col-md-2 text-align-center\">\n            <mat-checkbox name=\"read-[id]\"></mat-checkbox>\n          </div>\n          <div class=\"table-data mui-col-md-2 text-align-center\">\n            <mat-checkbox name=\"read-[id]\"></mat-checkbox>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n<div class=\"mui-tabs__pane\" id=\"network\">\n  <div class=\"tab-pane-content\">\n    <h4>Network Settings </h4>\n    <div class=\"mui-row form-item\">\n      <span class=\"mui-col-md-5 label\">Remote IP Settings:</span>\n      <span class=\"mui-col-md-7 text-align-right\">\n         <mat-form-field>\n           <input matInput type=\"text\" name=\"remote_ip_settings\" value=\"\" />\n         </mat-form-field>\n       </span>\n    </div>\n    <div class=\"mui-row form-item\">\n      <span class=\"mui-col-md-5 label\">Protocol:</span>\n      <span class=\"mui-col-md-7 text-align-right\">\n         <mat-form-field>\n           <input matInput type=\"text\" name=\"remote_protocol\" value=\"\" />\n         </mat-form-field>\n       </span>\n    </div>\n    <div class=\"mui-row form-item\">\n      <span class=\"mui-col-md-5 label\">Local Protocol:</span>\n      <span class=\"mui-col-md-7 text-align-right\">\n         <mat-form-field>\n           <input matInput type=\"text\" name=\"local_protocol\" value=\"\" />\n         </mat-form-field>\n       </span>\n    </div>\n    <hr />\n    <div class=\"mui-row\">\n      <div class=\"mui-col-md-8\"><h5 class=\"virtue-title\">Access Control List</h5></div>\n      <div class=\"mui-col-md-4 text-align-right\"><button mat-button class=\"virtue-button\">Add</button></div>\n    </div>\n    <div class=\"mui-container-fluid\">\n      <div class=\"mui-row\">\n        <div class=\"mui-col-md-12\">\n          <div class=\"mui-row table-header-group\">\n            <div class=\"mui-col-md-1 table-header\"><span>#</span></div>\n            <div class=\"mui-col-md-7 table-header\">Address</div>\n            <div class=\"mui-col-md-2 table-header text-align-center\"><span>Enable</span></div>\n            <div class=\"mui-col-md-2 table-header text-align-center\"><span>Options</span></div>\n          </div>\n          <div class=\"mui-row table-row\">\n            <div class=\"mui-col-md-1 table-data\">[id]</div>\n            <div class=\"mui-col-md-7 table-data\">[address]</div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <mat-checkbox name=\"access-enable-[id]\"></mat-checkbox>\n            </div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <a href=\"#\"><span class=\"fa fa-trash\" aria-hidden=\"true\"></span></a>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n<div class=\"mui-tabs__pane\" id=\"resources\">\n  <div class=\"tab-pane-content\">\n    <h4>Resources</h4>\n    <p><mat-checkbox name=\"resources-global\"> Use Global Settings</mat-checkbox></p>\n    <div class=\"mui-row form-item\">\n\n      <div class=\"mui-row form-item\">\n        <h5>File System Permissions</h5>\n        <div class=\"mui-col-md-12\">\n          <div class=\"mui-row table-header-group\">\n            <div class=\"mui-col-md-4 table-header\">Description</div>\n            <div class=\"mui-col-md-2 table-header text-align-center\"><span>Read</span></div>\n            <div class=\"mui-col-md-2 table-header text-align-center\"><span>Write</span></div>\n            <div class=\"mui-col-md-2 table-header text-align-center\"><span>Execute</span></div>\n            <div class=\"mui-col-md-2 table-header text-align-center\"><span>Enable</span></div>\n          </div>\n          <div class=\"mui-row\">\n            <div class=\"mui-col-md-4 table-data\">[description]</div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <mat-checkbox name=\"filesys-read-[id]\"></mat-checkbox>\n            </div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <mat-checkbox name=\"filesys-write-[id]\"></mat-checkbox>\n            </div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <mat-checkbox name=\"filesys-execute-[id]\"></mat-checkbox>\n            </div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <mat-checkbox name=\"filesys-enable-[id]\"></mat-checkbox>\n            </div>\n          </div>\n        </div>\n      </div>\n      <div class=\"mui-row form-item\">\n        <h5>Printers</h5>\n        <div class=\"mui-col-md-12\">\n          <div class=\"mui-row table-header-group\">\n            <div class=\"mui-col-md-8 table-header\">Description</div>\n            <div class=\"mui-col-md-2 table-header text-align-center\"><span>Status</span></div>\n            <div class=\"mui-col-md-2 table-header text-align-center\"><span>Enable</span></div>\n          </div>\n          <div class=\"mui-row\">\n            <div class=\"mui-col-md-8 table-data\">[printer info]</div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">[status]]</div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <mat-checkbox name=\"printer-enable-[id]\"></mat-checkbox>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n<div class=\"mui-tabs__pane\" id=\"sensors\">\n  <div class=\"tab-pane-content\">\n    <h4>Sensor Settings</h4>\n    <p><mat-checkbox name=\"resources-global\"> Use Global Settings</mat-checkbox></p>\n    <div class=\"mui-row form-item\">\n      <h5>Network Tools</h5>\n      <div class=\"mui-col-md-12\">\n        <div class=\"mui-row table-header-group\">\n          <div class=\"mui-col-md-4 table-header\">Sensor Control</div>\n          <div class=\"mui-col-md-2 table-header text-align-center\"><span>Default</span></div>\n          <div class=\"mui-col-md-2 table-header text-align-center\"><span>Low</span></div>\n          <div class=\"mui-col-md-2 table-header text-align-center\"><span>High</span></div>\n          <div class=\"mui-col-md-2 table-header text-align-center\"><span>Highest</span></div>\n        </div>\n        <div class=\"mui-row\">\n          <mat-radio-group>\n            <div class=\"mui-col-md-4 table-data\">[network-controller]</div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <mat-radio-button name=\"network-controller-[id]\" value=\"default\"></mat-radio-button>\n            </div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <mat-radio-button name=\"network-controller-[id]\" value=\"low\"></mat-radio-button>\n            </div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <mat-radio-button name=\"network-controller-[id]\" value=\"high\"></mat-radio-button>\n            </div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <mat-radio-button name=\"network-controller-[id]\" value=\"adversarial\"></mat-radio-button>\n            </div>\n          </mat-radio-group>\n        </div>\n      </div>\n    </div>\n    <div class=\"mui-row form-item\">\n      <h5>Virtue Sensor Settings</h5>\n      <div class=\"mui-col-md-12\">\n        <div class=\"mui-row table-header-group\">\n          <div class=\"mui-col-md-4 table-header\">Sensor Context</div>\n          <div class=\"mui-col-md-2 table-header text-align-center\"><span>Default</span></div>\n          <div class=\"mui-col-md-2 table-header text-align-center\"><span>Low</span></div>\n          <div class=\"mui-col-md-2 table-header text-align-center\"><span>High</span></div>\n          <div class=\"mui-col-md-2 table-header text-align-center\"><span>Highest</span></div>\n        </div>\n        <div class=\"mui-row\">\n          <mat-radio-group>\n            <div class=\"mui-col-md-4 table-data\">In-Resource (Unikernel)</div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <mat-radio-button name=\"unikernel-[id]\" value=\"default\"></mat-radio-button>\n            </div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <mat-radio-button name=\"unikernel-[id]\" value=\"low\"></mat-radio-button>\n            </div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <mat-radio-button name=\"unikernel-[id]\" value=\"high\"></mat-radio-button>\n            </div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <mat-radio-button name=\"unikernel-[id]\" value=\"adversarial\"></mat-radio-button>\n            </div>\n          </mat-radio-group>\n        </div>\n        <div class=\"mui-row\">\n          <mat-radio-group>\n            <div class=\"mui-col-md-4 table-data\">In-Virtue Controller</div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <mat-radio-button name=\"in-virtue-controller-[id]\" value=\"default\"></mat-radio-button>\n            </div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <mat-radio-button name=\"in-virtue-controller-[id]\" value=\"low\"></mat-radio-button>\n            </div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <mat-radio-button name=\"in-virtue-controller-[id]\" value=\"high\"></mat-radio-button>\n            </div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <mat-radio-button name=\"in-virtue-controller-[id]\" value=\"adversarial\"></mat-radio-button>\n            </div>\n          </mat-radio-group>\n        </div>\n      </div>\n    </div>\n    <div class=\"mui-row form-item\">\n      <h5>Logging</h5>\n      <div class=\"mui-col-md-12\">\n        <div class=\"mui-row table-header-group\">\n          <div class=\"mui-col-md-4 table-header\">Sensor Context</div>\n          <div class=\"mui-col-md-2 table-header text-align-center\">Default</div>\n          <div class=\"mui-col-md-2 table-header text-align-center\">Low</div>\n          <div class=\"mui-col-md-2 table-header text-align-center\">High</div>\n          <div class=\"mui-col-md-2 table-header text-align-center\">Highest</div>\n        </div>\n        <div class=\"mui-row\">\n          <mat-radio-group>\n            <div class=\"mui-col-md-4 table-data\">Aggregator</div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <mat-radio-button name=\"aggregator-[id]\" value=\"default\"></mat-radio-button>\n            </div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <mat-radio-button name=\"aggregator-[id]\" value=\"low\"></mat-radio-button>\n            </div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <mat-radio-button name=\"aggregator-[id]\" value=\"high\"></mat-radio-button>\n            </div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <mat-radio-button name=\"aggregator-[id]\" value=\"adversarial\"></mat-radio-button>\n            </div>\n          </mat-radio-group>\n        </div>\n        <div class=\"mui-row\">\n          <mat-radio-group>\n            <div class=\"mui-col-md-4 table-data\">Archive</div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <mat-radio-button name=\"archive-[id]\" value=\"default\"></mat-radio-button>\n            </div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <mat-radio-button name=\"archive-[id]\" value=\"low\"></mat-radio-button>\n            </div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <mat-radio-button name=\"archive-[id]\" value=\"high\"></mat-radio-button>\n            </div>\n            <div class=\"mui-col-md-2 table-data text-align-center\">\n              <mat-radio-button name=\"archive-[id]\" value=\"adversarial\"></mat-radio-button>\n            </div>\n          </mat-radio-group>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n\n\n<script>\n  var paneIds = ['general', 'network', 'resources', 'sensors'],\n    currPos = 0;\n\n  function activateNext() {\n    // increment id\n    currPos = (currPos + 1) % paneIds.length;\n    // activate tab\n    mui.tabs.activate(paneIds[currPos]);\n  }\n</script>\n"

/***/ }),

/***/ "./src/app/virtues/virtue-settings/virtue-settings.component.ts":
/*!**********************************************************************!*\
  !*** ./src/app/virtues/virtue-settings/virtue-settings.component.ts ***!
  \**********************************************************************/
/*! exports provided: VirtueSettingsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VirtueSettingsComponent", function() { return VirtueSettingsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var VirtueSettingsComponent = /** @class */ (function () {
    function VirtueSettingsComponent() {
    }
    VirtueSettingsComponent.prototype.ngOnInit = function () {
    };
    VirtueSettingsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-virtue-settings',
            template: __webpack_require__(/*! ./virtue-settings.component.html */ "./src/app/virtues/virtue-settings/virtue-settings.component.html"),
            styles: [__webpack_require__(/*! ./virtue-settings.component.css */ "./src/app/virtues/virtue-settings/virtue-settings.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], VirtueSettingsComponent);
    return VirtueSettingsComponent;
}());



/***/ }),

/***/ "./src/app/virtues/virtues.component.html":
/*!************************************************!*\
  !*** ./src/app/virtues/virtues.component.html ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<router-outlet></router-outlet>\n"

/***/ }),

/***/ "./src/app/virtues/virtues.component.ts":
/*!**********************************************!*\
  !*** ./src/app/virtues/virtues.component.ts ***!
  \**********************************************/
/*! exports provided: VirtuesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VirtuesComponent", function() { return VirtuesComponent; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var VirtuesComponent = /** @class */ (function () {
    function VirtuesComponent(location, router) {
        this.router = router;
        this.location = location;
    }
    VirtuesComponent.prototype.ngOnInit = function () { };
    VirtuesComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-virtues',
            template: __webpack_require__(/*! ./virtues.component.html */ "./src/app/virtues/virtues.component.html"),
            providers: [
                _angular_common__WEBPACK_IMPORTED_MODULE_0__["Location"],
                { provide: _angular_common__WEBPACK_IMPORTED_MODULE_0__["LocationStrategy"], useClass: _angular_common__WEBPACK_IMPORTED_MODULE_0__["HashLocationStrategy"] }
            ]
        }),
        __metadata("design:paramtypes", [_angular_common__WEBPACK_IMPORTED_MODULE_0__["Location"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]])
    ], VirtuesComponent);
    return VirtuesComponent;
}());



/***/ }),

/***/ "./src/app/virtues/vm-modal/vm-modal.component.html":
/*!**********************************************************!*\
  !*** ./src/app/virtues/vm-modal/vm-modal.component.html ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<form name=\"vm-list\">\n<h2 mat-dialog-title>Manage Virtual Machines</h2>\n<div mat-dialog-content>\n  <p>Select virtual machines to include in the virtue.</p>\n  <div class=\"mui-container-fluid mui-col-md-12 table-container\">\n    <div class=\"mui-row table-header-group\">\n      <div class=\"mui-col-md-5 table-header\">\n        <span class=\"float-left\">\n          <mat-checkbox\n            name=\"selectAll\"\n            (change)=\"selectAll($event.checked)\"\n            [disabled]=\"disabled\" ></mat-checkbox>\n        </span>\n        <span class=\"float-left text-align-left\">Virtual Machine</span>\n      </div>\n      <div class=\"mui-col-md-2 table-header\">\n        OS\n      </div>\n      <div class=\"mui-col-md-5 table-header\">\n        Applications\n      </div>\n    </div>\n    <div class=\"scrolling-list\">\n      <div *ngFor=\"let vm of vmList; let i = index \" class=\"mui-row table-row\">\n        <div class=\"mui-col-md-5 table-data\">\n          <span class=\"float-left\">\n            <mat-checkbox\n              name=\"cbVm\"\n              [checked]=\"selectVm(vm.id)\"\n              (change)=\"cbVmList($event.checked, vm.id, i)\"\n              value=\"{{vm.id}}\" ></mat-checkbox>\n          </span>\n          <span class=\"float-left\">{{ vm.name }}</span>\n        </div>\n        <div class=\"mui-col-md-2 table-data\">\n          {{ vm.os }}\n        </div>\n        <div class=\"mui-col-md-5 table-data\">\n          <ul>\n            <li *ngFor=\"let app of vm.applicationIds\">{{ app.name }}</li>\n          </ul>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n\n<div mat-dialog-actions>\n  <button mat-button class=\"button\" type=\"submit\" (click)=\"onAddVms();\">\n  Add VMs\n  </button>\n  <button mat-button type=\"button\" (click)=\"cancelModal();\" mat-dialog-close>\n    Cancel\n  </button>\n</div>\n</form>\n"

/***/ }),

/***/ "./src/app/virtues/vm-modal/vm-modal.component.ts":
/*!********************************************************!*\
  !*** ./src/app/virtues/vm-modal/vm-modal.component.ts ***!
  \********************************************************/
/*! exports provided: VmModalComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VmModalComponent", function() { return VmModalComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../shared/services/baseUrl.service */ "./src/app/shared/services/baseUrl.service.ts");
/* harmony import */ var _shared_services_vm_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/services/vm.service */ "./src/app/shared/services/vm.service.ts");
/* harmony import */ var _shared_models_application_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/models/application.model */ "./src/app/shared/models/application.model.ts");
/* harmony import */ var _shared_models_vm_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../shared/models/vm.model */ "./src/app/shared/models/vm.model.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};







var VmModalComponent = /** @class */ (function () {
    function VmModalComponent(route, baseUrlService, vmService, dialogRef, data) {
        this.route = route;
        this.baseUrlService = baseUrlService;
        this.vmService = vmService;
        this.dialogRef = dialogRef;
        this.data = data;
        this.checked = false;
        this.addVms = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.vmList = [];
        this.selVmsList = [];
        this.pageVmList = [];
        this.pageVmList = data['selectedVms'];
    }
    VmModalComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.baseUrlService.getBaseUrl().subscribe(function (res) {
            var awsServer = res[0].aws_server;
            _this.getVmList(awsServer);
        });
        if (this.pageVmList.length > 0) {
            this.selVmsList = this.pageVmList;
        }
    };
    VmModalComponent.prototype.getVmList = function (baseUrl) {
        var _this = this;
        this.vmService.getVmList(baseUrl)
            .subscribe(function (vms) {
            _this.vmList = vms;
        });
    };
    VmModalComponent.prototype.selectVm = function (id) {
        if (this.pageVmList.length > 0) {
            for (var _i = 0, _a = this.pageVmList; _i < _a.length; _i++) {
                var sel = _a[_i];
                if (sel === id) {
                    return true;
                }
            }
        }
        else {
            return false;
        }
    };
    VmModalComponent.prototype.selectAll = function (event) {
        if (event) {
            this.checked = true;
            for (var _i = 0, _a = this.vmList; _i < _a.length; _i++) {
                var vm = _a[_i];
                this.selVmsList.push(vm.id);
            }
        }
        else {
            this.checked = false;
            this.clearVmList();
        }
    };
    VmModalComponent.prototype.cbVmList = function (event, id, index) {
        if (event === true) {
            this.selVmsList.push(id);
        }
        else {
            this.removeVm(id, index);
        }
    };
    VmModalComponent.prototype.removeVm = function (id, index) {
        this.selVmsList.splice(this.selVmsList.indexOf(id), 1);
    };
    VmModalComponent.prototype.clearVmList = function () {
        this.selVmsList = [];
        this.pageVmList = [];
    };
    VmModalComponent.prototype.onAddVms = function () {
        // if (this.pageVmList.length > 0) {
        //   this.selVmsList = this.pageVmList;
        // }
        this.addVms.emit(this.selVmsList);
        this.clearVmList();
        this.dialogRef.close();
    };
    VmModalComponent.prototype.cancelModal = function () {
        this.clearVmList();
        this.dialogRef.close();
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", _shared_models_vm_model__WEBPACK_IMPORTED_MODULE_5__["VirtualMachine"])
    ], VmModalComponent.prototype, "vmInput", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", _shared_models_application_model__WEBPACK_IMPORTED_MODULE_4__["Application"])
    ], VmModalComponent.prototype, "appInput", void 0);
    VmModalComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-vm-modal',
            template: __webpack_require__(/*! ./vm-modal.component.html */ "./src/app/virtues/vm-modal/vm-modal.component.html"),
            providers: [_shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_2__["BaseUrlService"], _shared_services_vm_service__WEBPACK_IMPORTED_MODULE_3__["VirtualMachineService"]]
        }),
        __param(4, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(_angular_material__WEBPACK_IMPORTED_MODULE_6__["MAT_DIALOG_DATA"])),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"],
            _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_2__["BaseUrlService"],
            _shared_services_vm_service__WEBPACK_IMPORTED_MODULE_3__["VirtualMachineService"],
            _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatDialogRef"], Object])
    ], VmModalComponent);
    return VmModalComponent;
}());



/***/ }),

/***/ "./src/app/vm-apps/add-vm-app/add-vm-app.component.html":
/*!**************************************************************!*\
  !*** ./src/app/vm-apps/add-vm-app/add-vm-app.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<h3>Install Application Package</h3>\n<form>\n  <mat-form-field *ngIf=\"selectedOs == null\">\n    <mat-select placeholder=\"Select OS\" [(ngModel)]=\"selectedOs\" name=\"os\">\n      <mat-option *ngFor=\"let os of osList\" [value]=\"os\">\n        {{ os }}\n      </mat-option>\n    </mat-select>\n  </mat-form-field>\n  <p [ngClass]=\"{\n    'hide':selectedOs == null,\n    'selected-value':selectedOs != null\n  }\">{{ selectedOs }}</p>\n\n  <mat-form-field *ngIf=\"selectedOs === 'LINUX'\">\n    <mat-select placeholder=\"Select Distribution\" [(ngModel)]=\"selectedDist\" name=\"os\">\n      <mat-option *ngFor=\"let d of distroList\" [value]=\"d\">\n        {{ d }}\n      </mat-option>\n    </mat-select>\n  </mat-form-field>\n\n  <p *ngIf=\"selectedOs === 'Windows'\">\n    <label for=\"file\">Upload Package:</label><br />\n    <input type=\"file\" id=\"file\" (change)=\"handleFIleInput($event.target.files)\" />\n  </p>\n  <p *ngIf=\"selectedOs === 'LINUX' && selectedDist != null\">\n    <label for=\"url\">Package Name:</label>\n    <input type=\"text\" id=\"url\" (change)=\"handleFIleInput($event.target.files)\" />\n  </p>\n  <hr />\n  <div class=\"mui-row border-top\">\n    <div class=\"mui-col-md-4\">\n      <input #editor type=\"hidden\" value=\"system\" />\n    </div>\n    <div class=\"mui-col-md-4 form-item text-align-center\">\n      <!-- <span class=\"margin-right-10\"><input name=\"create-another\" type=\"checkbox\" value=\"1\" /> Install Another Application</span> -->\n      <button class=\"button-submit\" type=\"submit\">Install</button>\n      <button (click)=\"onCancel()\" class=\"button-cancel\" type=\"cancel\">Cancel</button>\n    </div>\n    <div class=\"mui-col-md-4\"></div>\n  </div>\n</form>\n"

/***/ }),

/***/ "./src/app/vm-apps/add-vm-app/add-vm-app.component.ts":
/*!************************************************************!*\
  !*** ./src/app/vm-apps/add-vm-app/add-vm-app.component.ts ***!
  \************************************************************/
/*! exports provided: AddVmAppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddVmAppComponent", function() { return AddVmAppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};


var AddVmAppComponent = /** @class */ (function () {
    function AddVmAppComponent(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.data = data;
        this.osList = ['LINUX', 'Windows'];
        this.distroList = ['Debian'];
    }
    AddVmAppComponent.prototype.ngOnInit = function () {
    };
    AddVmAppComponent.prototype.onCancel = function () {
        this.dialogRef.close();
        this.selectedOs = null;
        this.selectedDist = null;
    };
    AddVmAppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-add-vm-app',
            template: __webpack_require__(/*! ./add-vm-app.component.html */ "./src/app/vm-apps/add-vm-app/add-vm-app.component.html")
        }),
        __param(1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(_angular_material__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"])),
        __metadata("design:paramtypes", [_angular_material__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"], Object])
    ], AddVmAppComponent);
    return AddVmAppComponent;
}());



/***/ }),

/***/ "./src/app/vm-apps/vm-apps-list/vm-apps-list.component.html":
/*!******************************************************************!*\
  !*** ./src/app/vm-apps/vm-apps-list/vm-apps-list.component.html ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"content-container\">\n  <div id=\"content-header\" class=\"titlebar\">\n    <h1 class=\"titlebar-title\">Applications</h1>\n    <button class=\"titlebar-button\" (click)=\"openAppsDialog()\">Install New App</button>\n  </div>\n\n  <div id=\"content-main\">\n    <div id=\"content\">\n\n      <div class=\"mui-container-fluid\">\n        <!-- if there are no virtues, show this message -->\n        <div class=\"mui-row margin-top-10\" *ngIf=\"apps.length < 1\">\n          <div class=\"mui-col-md-12 padding-left-0\">\n            <p class=\"no-data-message\">\n              No applications can be found at this time. To add an application, click on the button \"Add New App\" above.\n            </p>\n          </div>\n        </div>\n      </div>\n\n      <!-- if there are virtues, show this list -->\n      <div class=\"mui-container-fluid\">\n        <div class=\"mui-row\">\n          <div class=\"mui-col-md-12 padding-left-0 filters\">\n            <a mat-button (click)=\"listFilter('*')\">All Apps</a> |\n            <a mat-button (click)=\"listFilter(true)\">Enabled Apps</a> |\n            <a mat-button (click)=\"listFilter(false)\">Disabled Apps</a>\n          </div>\n        </div>\n      </div>\n      <div class=\"mui-container-fluid data-list\">\n        <div class=\"mui-row table-header-group\">\n          <div class=\"table-header mui-col-md-6\">Application Name</div>\n          <div class=\"table-header mui-col-md-2\">Version</div>\n          <div class=\"table-header mui-col-md-2\">OS</div>\n          <div class=\"table-header mui-col-md-2\">Status</div>\n        </div>\n        <div *ngFor=\"let app of apps | listFilter:filterValue:'enabled'\" class=\"mui-row table-row\" appActiveClass>\n          <div class=\"table-data mui-col-md-6\">\n            <!-- <a mat-button (click)=\"updateStatus(app.id, app.enabled)\"></a> -->\n            {{ app.name }}\n            <!-- if this virtue is enabled show this menu -->\n            <span *ngIf=\"app.enabled\" class=\"menu-options\">\n              <a mat-button (click)=\"updateStatus(app.id)\">Disable</a>\n            </span>\n\n            <!-- if this virtue is disabled show this menu -->\n            <span class=\"menu-options\">\n              <a mat-button (click)=\"updateStatus(app.id)\">Enable</a> |\n              <a mat-button (click)=\"openDialogPrompt(app.id, 'uninstall', app.name)\">Uninstall</a>\n            </span>\n          </div>\n\n          <div class=\"table-data mui-col-md-2\">{{ app.version }}</div>\n          <div class=\"table-data mui-col-md-2\">{{ app.os }}</div>\n          <div class=\"table-data mui-col-md-2\">\n            {{ app.enabled ? 'Enabled' : 'Disabled' }}\n          </div>\n          <div class=\"clearfix\"></div>\n        </div>\n      </div>\n      <div class=\"paging\">\n        <div class=\"page-number mui-col-md-4\">&nbsp;</div>\n        <div class=\"page-controls mui-col-md-4\">&nbsp;</div>\n        <div class=\"page-item-total mui-col-md-4\">{{ totalApps }} Installed Applications</div>\n        <div class=\"clearfix\"></div>\n      </div>\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/vm-apps/vm-apps-list/vm-apps-list.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/vm-apps/vm-apps-list/vm-apps-list.component.ts ***!
  \****************************************************************/
/*! exports provided: VmAppsListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VmAppsListComponent", function() { return VmAppsListComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _add_vm_app_add_vm_app_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../add-vm-app/add-vm-app.component */ "./src/app/vm-apps/add-vm-app/add-vm-app.component.ts");
/* harmony import */ var _dialogs_dialogs_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../dialogs/dialogs.component */ "./src/app/dialogs/dialogs.component.ts");
/* harmony import */ var _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../shared/services/applications.service */ "./src/app/shared/services/applications.service.ts");
/* harmony import */ var _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../shared/services/baseUrl.service */ "./src/app/shared/services/baseUrl.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var VmAppsListComponent = /** @class */ (function () {
    function VmAppsListComponent(route, appsService, baseUrlService, dialog) {
        this.route = route;
        this.appsService = appsService;
        this.baseUrlService = baseUrlService;
        this.dialog = dialog;
        this.title = 'Applications';
        this.filterValue = '*';
        this.apps = [];
    }
    VmAppsListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.baseUrlService.getBaseUrl().subscribe(function (res) {
            var awsServer = res[0].aws_server;
            _this.getApplications(awsServer);
        });
    };
    VmAppsListComponent.prototype.getApplications = function (baseUrl) {
        var _this = this;
        this.appsService.getAppsList(baseUrl)
            .subscribe(function (appsList) {
            _this.apps = appsList;
            _this.totalApps = appsList.length;
        });
    };
    VmAppsListComponent.prototype.updateStatus = function (id) {
        var app = this.apps.filter(function (data) { return data['id'] === id; });
        app.map(function (_, i) {
            app[i].enabled ? app[i].enabled = false : app[i].enabled = true;
            console.log(app);
        });
    };
    VmAppsListComponent.prototype.listFilter = function (status) {
        console.log('filterValue = ' + status);
        this.filterValue = status;
        this.totalApps = this.apps.length;
    };
    VmAppsListComponent.prototype.openDialogPrompt = function (id, type, text) {
        var dialogRef = this.dialog.open(_dialogs_dialogs_component__WEBPACK_IMPORTED_MODULE_4__["DialogsComponent"], {
            width: '450px',
            data: {
                dialogText: text,
                dialogType: type
            }
        });
        dialogRef.updatePosition({ top: '15%', left: '36%' });
        dialogRef.afterClosed().subscribe(function (result) {
            console.log('The dialog was closed');
        });
    };
    VmAppsListComponent.prototype.openAppsDialog = function () {
        var dialogRef = this.dialog.open(_add_vm_app_add_vm_app_component__WEBPACK_IMPORTED_MODULE_3__["AddVmAppComponent"], {
            width: '480px',
            data: { file: this.file, url: this.url }
        });
        dialogRef.afterClosed().subscribe(function (result) {
            console.log('The dialog was closed');
        });
    };
    VmAppsListComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-vm-apps-list',
            providers: [_shared_services_applications_service__WEBPACK_IMPORTED_MODULE_5__["ApplicationsService"], _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_6__["BaseUrlService"]],
            template: __webpack_require__(/*! ./vm-apps-list.component.html */ "./src/app/vm-apps/vm-apps-list/vm-apps-list.component.html")
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            _shared_services_applications_service__WEBPACK_IMPORTED_MODULE_5__["ApplicationsService"],
            _shared_services_baseUrl_service__WEBPACK_IMPORTED_MODULE_6__["BaseUrlService"],
            _angular_material__WEBPACK_IMPORTED_MODULE_1__["MatDialog"]])
    ], VmAppsListComponent);
    return VmAppsListComponent;
}());



/***/ }),

/***/ "./src/app/vm-apps/vm-apps.component.html":
/*!************************************************!*\
  !*** ./src/app/vm-apps/vm-apps.component.html ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<router-outlet></router-outlet>\n"

/***/ }),

/***/ "./src/app/vm-apps/vm-apps.component.ts":
/*!**********************************************!*\
  !*** ./src/app/vm-apps/vm-apps.component.ts ***!
  \**********************************************/
/*! exports provided: VmAppsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VmAppsComponent", function() { return VmAppsComponent; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var VmAppsComponent = /** @class */ (function () {
    function VmAppsComponent(location, router) {
        this.router = router;
        this.location = location;
    }
    VmAppsComponent.prototype.ngOnInit = function () {
    };
    VmAppsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-vm-apps',
            template: __webpack_require__(/*! ./vm-apps.component.html */ "./src/app/vm-apps/vm-apps.component.html"),
            providers: [
                _angular_common__WEBPACK_IMPORTED_MODULE_0__["Location"],
                { provide: _angular_common__WEBPACK_IMPORTED_MODULE_0__["LocationStrategy"], useClass: _angular_common__WEBPACK_IMPORTED_MODULE_0__["HashLocationStrategy"] }
            ]
        }),
        __metadata("design:paramtypes", [_angular_common__WEBPACK_IMPORTED_MODULE_0__["Location"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]])
    ], VmAppsComponent);
    return VmAppsComponent;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.
var environment = {
    production: false
};


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /var/lib/jenkins/workspace/VirtueFrontEnd-BuildTest/modules/admin/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map