# Roboto @font-face kit

I split the SASS file, so the developer can decide which fonts and styles he really needs.

## Demo
__Our repository:__ [http://fontfacekit.github.com/roboto](http://fontfacekit.github.com/roboto)

__Google Web Fonts:__ [http://www.google.com/fonts/specimen/Roboto](http://www.google.com/fonts/specimen/Roboto)


## Maintain your own font-face in FontFaceKit
Contact @gustavohenke if you want to maintain your own font-face in this repository.
